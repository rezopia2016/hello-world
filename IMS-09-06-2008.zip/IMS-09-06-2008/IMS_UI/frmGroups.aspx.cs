using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

#region "--Class Description--"
///<classname>Groups Main class</classname>
///<author>Santhosh Kumar</author>
///<date created>18/5/2008</datecreated>
///<datemodified>18/5/2008</datemodified>
///<modified by>Santhosh Kumar</modified by>
///<no. of classes>1</no. of classes>
///<no. of methods></no. of methods>
/// <summary>
/// Class to list groups in the grid and platform for CRUD operation
/// </summary>
/// 
#endregion

public partial class frmGroups : System.Web.UI.Page
{

    protected void Page_Load(object sender, EventArgs e)
    {

        // *** Check whether the user is the administrator or a normal user.
        if (Session["UserId"] != null && Session["UserType"] != null && Session["UserType"].ToString().Trim().ToLower() == "admin")
        {

            // *** Calling function to FillGroupList method
            FillGroupsList();

        }
        else
        {

            // *** Redirect to login page if session expires
            Response.Redirect("frmLogin.aspx");

        }
   
    }

    /// <summary>
    /// Function to fill the grid
    /// </summary>
    private void FillGroupsList()
    {
        
        // *** Create an object of type data_Operations
        data_Operations objData = new data_Operations();

        // *** Open the atabase conection
        string strSucess = objData.openConnection();
        
        // *** Check if connection is successfull
        if (strSucess == "success")
        {

            // *** Execute the stored procedure
            DataSet ds = objData.getDataSet("ui_Groups_List", true);
            grdDetails.DataSource = ds;
            
            // *** Bind the datagrid
            grdDetails.DataBind();
        
        }
        
        // *** Close the data connection
        objData.closeConnection();

    }

    /// <summary>
    /// Function to bind the grid rows
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void grdDetails_RowDataBound(object sender, GridViewRowEventArgs e)
    {

        if (e.Row.RowType == DataControlRowType.DataRow)
        {
        
            // *** Assign values to row attributes
            e.Row.Attributes.Add("onclick", "setSelectedRow('" + grdDetails.ClientID + "'," + e.Row.RowIndex + "); document.getElementById('" + hid_Val.ClientID + "').value = '" + e.Row.Cells[0].Text + "';selRow = " + (e.Row.RowIndex + 1) + ";");
            e.Row.Attributes.Add("onmouseover", "ShowMouseOver(this);");
            e.Row.Attributes.Add("onmouseout", "ShowMouseOut(this);");
        
        }

    }
    
}
