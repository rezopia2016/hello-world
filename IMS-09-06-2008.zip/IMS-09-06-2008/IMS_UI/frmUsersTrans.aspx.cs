using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

#region "--Class Description--"
///<classname>Users Transaction class</classname>
///<author>Santhosh Kumar</author>
///<date created>22/5/2008</datecreated>
///<datemodified>22/5/2008</datemodified>
///<modified by>Santhosh Kumar</modified by>
///<no. of classes>1</no. of classes>
///<no. of methods></no. of methods>
/// <summary>
/// Class used to call CRUD methods
/// </summary>
/// 
#endregion


public partial class frmUsersTrans : System.Web.UI.Page
{

    // *** Declare the local variables
    int id = 0;
    int oprType = 0;

    protected void Page_Load(object sender, EventArgs e)
    {

        // ***  Check if the user is an administrator
        if (Session["UserId"] != null && Session["UserType"] != null && Session["UserType"].ToString().Trim().ToLower() == "admin")
        {
            
            // *** Retrieve the query string and initialize the parameters
            if (Request.QueryString["Id"] != null)
            {

                id = Convert.ToInt32(Request.QueryString["Id"]);

            }

            if (Request.QueryString["Oper"] != null)
            {

                oprType = Convert.ToInt32(Request.QueryString["Oper"]);

            }

            // *** Check if post back 
            if (Page.IsPostBack == false)
            {

                // *** Calling function to set control state
                setControlState();

                if (oprType != 0)
                {

                    // *** Calling function to Set Details 
                    SetDetails();

                }

            }

            // *** Calling function to FillAccessTable method
            FillAccessTable();

        }
        else
        {

            // *** Execute the javascript
            Page.ClientScript.RegisterStartupScript(this.GetType(), "relo", "window.opener.location.href=window.opener.location;window.close();", true);
        
        }

    }


    /// <summary>
    /// Function to set control state
    /// </summary>
    private void setControlState()
    {

        // *** Check if operation to be performed is create
        if (oprType == 0)
        {

            btnCreate.Text = "Create";
            lblTitle.Text = "Users - Create";
        
        }
        else if (oprType == 1) // *** Check if operation to be performed is update
        {
        
            btnCreate.Text = "Update";
            lblTitle.Text = "Users - Modify";
        
        }
        else  // *** Check if operation to be performed is delete
        {
           
            btnCreate.Text = "Delete";
            lblTitle.Text = "Users - Delete";

            txtUserName.Enabled = false;
            txtSqlName.Enabled = false;
            txtEmail.Enabled = false;
            txtPhone.Enabled = false;
            chkAdmin.Enabled = false;

            btnCreate.Attributes.Add("onclick", "return confirmation();");

        }

    }

    /// <summary>
    /// Function to fill Access Table
    /// </summary>
    private void FillAccessTable()
    {
        
        // *** Declare the local variables and objects
        DataSet ds = new DataSet();
        data_Operations objData = new data_Operations();

        // *** Open a data connection
        string strSucess = objData.openConnection();
        
        // *** Check if connection is successfull
        if (strSucess == "success")
        {

            // *** Check if operation to be performed is create
            if (oprType == 0)
            {

                // *** Execute the stored procedure
                ds = objData.getDataSet("ui_Groups_List", false);
            
            }
            else // *** Check if operation to be performed is update or delete
            {
            
                // *** Initialize the parameters and execute the stored procedure
                Hashtable hsh = new Hashtable();
                hsh.Add("@Id", id);
                ds = objData.getDataSet("ui_users_GetUserGroupsList", true,hsh);

            }

        }

        // *** Close the data connection
        objData.closeConnection();

        // *** Check the dataset
        if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
        {

            // *** Iterate through the dataset
            for (int count = 0; count < ds.Tables[0].Rows.Count; count++)
            {

                // *** Create a table row and assign its property values
                TableRow tr = new TableRow();
                tr.Height = Unit.Pixel(20);
                tr.CssClass = "GridRowStyle";

                // *** Create a table cell and initialize its value and properties
                TableCell tc_Hid = new TableCell();
                HiddenField hid_Id = new HiddenField();
                hid_Id.ID = "hid_" + (count + 1).ToString();
                hid_Id.Value = ds.Tables[0].Rows[count]["id"].ToString();
                tc_Hid.Style.Add("display", "none");
                // *** Add the hidden control to the cell
                tc_Hid.Controls.Add(hid_Id);
                // *** Add the cell to the row
                tr.Cells.Add(tc_Hid);

                // *** Create a table cell and initialize its value and properties
                TableCell tc = new TableCell();
                tc.CssClass = "CellBorderRightBottom";
                tc.Text = ds.Tables[0].Rows[count]["groupName"].ToString();
                // *** Add the cell to the row
                tr.Cells.Add(tc);

                // *** Create a table cell and initialize its value and properties
                TableCell tc_Read = new TableCell();
                tc_Read.CssClass = "CellBorderRightBottom";
                CheckBox chk_Read = new CheckBox();
                chk_Read.ID = "chkRead" + (count + 1).ToString();
                if (oprType == 2)
                {

                    chk_Read.Enabled = false;

                }
                tc_Read.HorizontalAlign = HorizontalAlign.Center;
                // *** Add the check box control to the cell
                tc_Read.Controls.Add(chk_Read);
                // *** Add the cell to the row
                tr.Cells.Add(tc_Read);

                // *** Create a table cell and initialize its value and properties
                TableCell tc_Write = new TableCell();
                tc_Write.CssClass = "CellBorderRightBottom";
                CheckBox chk_Write = new CheckBox();
                if (oprType == 2)
                {

                    chk_Write.Enabled = false;

                }
                chk_Write.ID = "chkWrite" + (count + 1).ToString();
                tc_Write.HorizontalAlign = HorizontalAlign.Center;
                // *** Add the check box control to the cell
                tc_Write.Controls.Add(chk_Write);
                // *** Add the cell to the row
                tr.Cells.Add(tc_Write);

                // *** Create a table cell and initialize its value and properties
                TableCell tc_Mail = new TableCell();
                tc_Mail.CssClass = "CellBorderRightBottom";
                CheckBox chk_Mail = new CheckBox();
                if (oprType == 2)
                {

                    chk_Mail.Enabled = false;

                }
                chk_Mail.ID = "chkMail" + (count + 1).ToString();
                tc_Mail.HorizontalAlign = HorizontalAlign.Center;
                // *** Add the check box control to the cell
                tc_Mail.Controls.Add(chk_Mail);
                // *** Add the cell to the row
                tr.Cells.Add(tc_Mail);

                // *** Create a table cell and initialize its value and properties
                TableCell tc_SMS = new TableCell();
                tc_SMS.CssClass = "CellBoderBottom";
                CheckBox chk_SMS = new CheckBox();
                if (oprType == 2)
                {

                    chk_SMS.Enabled = false;

                }
                chk_SMS.ID = "chkSMS" + (count + 1).ToString();
                tc_SMS.HorizontalAlign = HorizontalAlign.Center;
                // *** Add the check box control to the cell
                tc_SMS.Controls.Add(chk_SMS);
                // *** Add the cell to the row
                tr.Cells.Add(tc_SMS);

                // *** Add the row to the table
                tblAccess.Rows.Add(tr);

                if (Page.IsPostBack == false)
                {

                    if (oprType != 0)
                    {

                        // *** Initialize the check box for each row
                        chk_Read.Checked = Convert.ToBoolean(ds.Tables[0].Rows[count]["accessRead"]);
                        chk_Write.Checked = Convert.ToBoolean(ds.Tables[0].Rows[count]["accessWrite"]);
                        chk_Mail.Checked = Convert.ToBoolean(ds.Tables[0].Rows[count]["notifyEmail"]);
                        chk_SMS.Checked = Convert.ToBoolean(ds.Tables[0].Rows[count]["notifySMS"]);
                    
                    }

               
                }
           
            }

            // *** Dispose the dataset
            ds.Dispose();
        }

        objData = null;
    
    }

    /// <summary>
    /// Function to Set Details
    /// </summary>
    private void SetDetails()
    {

        // *** Declare an object of type clsUsers
        clsUsers obj = new clsUsers();
        DataSet dsDetails = new DataSet();

        // *** Calling function to GetUserDetails method
        dsDetails = obj.GetUserDetails(id);

        // *** Initialize the controls
        if (dsDetails != null && dsDetails.Tables.Count > 0 && dsDetails.Tables[0].Rows.Count > 0)
        {
          
           txtUserName.Text = dsDetails.Tables[0].Rows[0]["userName"].ToString();
           txtSqlName.Text = dsDetails.Tables[0].Rows[0]["sqlUserName"].ToString();
           txtEmail.Text = dsDetails.Tables[0].Rows[0]["emailAddress"].ToString();
           txtPhone.Text = dsDetails.Tables[0].Rows[0]["phoneNumer"].ToString();
           chkAdmin.Checked = Convert.ToBoolean(dsDetails.Tables[0].Rows[0]["isAdmin"]);
           hidPass.Value = dsDetails.Tables[0].Rows[0]["password"].ToString(); 

        }

        // *** Dispose the objects
        dsDetails.Dispose();
        obj = null;
   
    }

    /// <summary>
    /// Function call on button press
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnCreate_Click(object sender, EventArgs e)
    {

        // *** Check if operation to be performed is Create
        if (oprType == 0)
        {

            // *** Calling function to Create method
            Create();

        }
        else if (oprType == 1)// *** Check if operation to be performed is Update
        {

            // *** Calling function to Update method
            Update();

        }
        else// *** Check if operation to be performed is Delete
        {

            Delete();

        }

        // *** Execute the javascript
        Page.ClientScript.RegisterStartupScript(this.GetType(), "relo", "window.opener.location.href=window.opener.location;window.close();", true);
    
    }

    /// <summary>
    /// Function to create the new row
    /// </summary>
    private void Create()
    {
        
        // *** Declare an object of type clsUsers
        clsUsers obj = new clsUsers();
        int UserId = 0;

        if (txtPass.Text.Trim() != "")
        {

            // *** Calling function to InsertUsers
            UserId = obj.InsertUsers(txtUserName.Text, txtSqlName.Text, txtEmail.Text, txtPhone.Text, chkAdmin.Checked, txtPass.Text.Trim());

            if (UserId > 0)
            {

                // *** Iterate for each User group
                for (int i = 1; i < tblAccess.Rows.Count; i++)
                {

                    // *** Retrieve the table ids
                    HiddenField hidId = (HiddenField)this.FindControl("hid_" + i.ToString());
                    CheckBox chkRead = (CheckBox)tblAccess.Rows[i].Cells[0].FindControl("chkRead" + i.ToString());
                    CheckBox chkwrite = (CheckBox)tblAccess.Rows[i].Cells[0].FindControl("chkWrite" + i.ToString());
                    CheckBox chkemail = (CheckBox)tblAccess.Rows[i].Cells[0].FindControl("chkMail" + i.ToString());
                    CheckBox chksms = (CheckBox)tblAccess.Rows[i].Cells[0].FindControl("chkSMS" + i.ToString());

                    if (hidId != null && chkRead != null && chkwrite != null && chkemail != null && chksms != null)
                    {

                        // *** Calling function to insertUserAccess
                        obj.insertUserAccess(UserId, Convert.ToInt32(hidId.Value), chkRead.Checked, chkwrite.Checked, chkemail.Checked, chksms.Checked);

                    }

                }

            }

            Page.ClientScript.RegisterStartupScript(this.GetType(), "relo", "window.opener.location.href=window.opener.location;window.close();", true);

        }
        else
        {

            Page.ClientScript.RegisterStartupScript(this.GetType(), "aler", "alert('Please enter Password');", true);

        }

        // *** Dispose the objects
        obj = null;

    }

    /// <summary>
    /// Function to update the rows
    /// </summary>
    private void Update()
    {

        // *** Create an object of type clsUsers
        clsUsers obj = new clsUsers();
        int noOfRecs = 0;

        if (txtPass.Text.Trim() != "" || hidPass.Value.Trim() != "")
        {
                string strPass = txtPass.Text.Trim() != "" ? txtPass.Text : hidPass.Value;

                // *** Calling function to UpdateUsers method
                noOfRecs = obj.UpdateUsers(id, txtUserName.Text, txtSqlName.Text, txtEmail.Text, txtPhone.Text, chkAdmin.Checked, strPass);
                
                if (noOfRecs > 0)
                {
                
                    // *** Calling function to deleteUserAccess method
                    obj.deleteUserAccess(id);

                    for (int i = 1; i < tblAccess.Rows.Count; i++)
                    {
                    
                        // *** Initialize the controls
                        HiddenField hidId = (HiddenField)this.FindControl("hid_" + i.ToString());
                        CheckBox chkRead = (CheckBox)tblAccess.Rows[i].Cells[0].FindControl("chkRead" + i.ToString());
                        CheckBox chkwrite = (CheckBox)tblAccess.Rows[i].Cells[0].FindControl("chkWrite" + i.ToString());
                        CheckBox chkemail = (CheckBox)tblAccess.Rows[i].Cells[0].FindControl("chkMail" + i.ToString());
                        CheckBox chksms = (CheckBox)tblAccess.Rows[i].Cells[0].FindControl("chkSMS" + i.ToString());

                        if (hidId != null && chkRead != null && chkwrite != null && chkemail != null && chksms != null)
                        {

                            // *** Calling function to insertUserAccess
                            obj.insertUserAccess(id, Convert.ToInt32(hidId.Value), chkRead.Checked, chkwrite.Checked, chkemail.Checked, chksms.Checked);
                       
                        }

                    }

                }

             Page.ClientScript.RegisterStartupScript(this.GetType(), "relo", "window.opener.location.href=window.opener.location;window.close();", true);
        }
        else
        {

            Page.ClientScript.RegisterStartupScript(this.GetType(), "aler", "alert('Please enter Password');", true);
       
        }
        // *** Dispose objects
        obj = null;

    }

    /// <summary>
    /// Function to delete a row
    /// </summary>
    private void Delete()
    {

        // *** Create an object of type clsUsers
        clsUsers obj = new clsUsers();

        // *** Calling function to DeleteUsers
        obj.DeleteUsers(id);
        obj = null;

    }

}
