using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

#region "--Class Description--"
///<classname>Master page class</classname>
///<author>Santhosh Kumar</author>
///<date created>04/06/2008</datecreated>
///<datemodified>04/06/2008</datemodified>
///<modified by>Santhosh Kumar</modified by>
///<no. of classes>1</no. of classes>
///<no. of methods></no. of methods>
/// <summary>
/// Class used for logging into the concerned pages
/// </summary>
/// 
#endregion

public partial class frmMainMaster : System.Web.UI.MasterPage
{
   
    
    protected void Page_Load(object sender, EventArgs e)
    {

        // *** Check if Session Exists
        if (Session["UserId"] != null && Session["UserType"] != null)
        {

            // *** Retrieve the session varaible
            string strUserType = Session["UserType"].ToString();

            // *** Check if it is normal user
            if (strUserType.ToLower() == "user")
            {

                // *** If normal user Master inputs are removed
                treeExplorer.Nodes.RemoveAt(0);

            }

        }
        else
        {

            // *** Redirect the page to login screen
            Response.Redirect("frmLogin.aspx");

        }

    }

    /// <summary>
    /// Function to logout of the Application
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void lnkLogout_Click(object sender, EventArgs e)
    {

        // *** Disposes all the session variable
        Session.Abandon();

        // *** Redirects the page to the login page
        Response.Redirect("frmLogin.aspx");

    }

}
