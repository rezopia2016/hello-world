using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Net;
using System.Net.Mail;

#region "--Class Description--"
///<classname>Forgot Password class</classname>
///<author>Santhosh Kumar</author>
///<date created>09/06/2008</datecreated>
///<datemodified>09/06/2008</datemodified>
///<modified by>Santhosh Kumar</modified by>
///<no. of classes>1</no. of classes>
///<no. of methods></no. of methods>
/// <summary>
/// Class used to retrieve forgotten password
/// </summary>
/// 
#endregion


public partial class ForgotPassword : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnCreate_Click(object sender, EventArgs e)
    {
        // *** Declare the local variables
        data_Operations db = new data_Operations();
        DataSet ds = new DataSet();
        string emailid = "";
        string cmd = "";

        // *** Open the database connection
        string conn = db.openConnection();

        // *** Check if connection is successfull
        if (conn == "success")
        {

            // *** Declare and initialize the hash table and parameters
            cmd = "ui_ForgotPassword";

            Hashtable param = new Hashtable();
            param.Add("@type", "1".ToString());
            param.Add("@emailid",txtEmail.Text.Trim().ToString());

            // *** Execute the stored procedure
            ds = db.getDataSet(cmd, true, param);

           

        }

        // *** Close the database connection
        db.closeConnection();

        // *** Check if dataset is empty
        if (ds.Tables[0].Rows.Count > 0 && ds != null)
        {

            // ***  Retrive the old password
            emailid = ds.Tables[0].Rows[0][0].ToString();

            // *** Compare if password matches with the old password
            if (emailid.Trim().ToString() == txtEmail.Text.Trim().ToString())
            {

                string password = "";

                password = RandomPassword.Generate(8, 10);

                // *** Open the database connection
                conn = db.openConnection();

                // *** Check if connection is successfull
                if (conn == "success")
                {

                    // *** Declare and initialize the hash table and parameters
                    cmd = "ui_ForgotPassword";

                    Hashtable param = new Hashtable();
                    param.Add("@type", "2".ToString());
                    param.Add("@emailid", txtEmail.Text.Trim().ToString());
                    param.Add("@password", password);

                    // *** Execute the stored procedure
                    int i = db.executeQuery(cmd, true, param);

                    if (i != 0)
                    {

                        // *** Calling function to send the password
                        SendEmail(txtEmail.Text.Trim().ToString(), "IMS - New Password", "Your Password is :", password);

                    }

                }

                // *** Close the database connection
                db.closeConnection();

                // *** Disable the change password if old password is not right
                Page.ClientScript.RegisterStartupScript(this.GetType(), "relo", "alert('Message Send Successfully');", true);
                // *** Calling function to close the popup window and return to the main page
                Page.ClientScript.RegisterStartupScript(this.GetType(), "reelo", "window.opener.location.href=window.opener.location;window.close();", true);
    

            }
            
        }
        else
        {

            // *** Enable the change password buttin if old passowrd is right
            Page.ClientScript.RegisterStartupScript(this.GetType(), "relo", "alert('Type a Valid Email Id');", true);

        }

    }

    /// <summary>
    /// Function to Send New Password
    /// </summary>
    /// <param name="mailTo"></param>
    /// <param name="subject"></param>
    /// <param name="body"></param>
    private void SendEmail(string mailTo, string subject, string body,string password)
    {

        try
        {
            //create the mail message
            MailMessage mail = new MailMessage();
            

            //mail.From = new MailAddress("admin@infomeda.com", "Santhosh Kumar");
            // *** set the addresses to which Email has to be send
            mail.To.Add(mailTo);

            // *** set the content like subject and body 
            mail.Subject = subject;
            mail.Body = body + "" + password;
            mail.IsBodyHtml = true;

            // *** send the message - Create an Smtp Client object
            //SmtpClient smtp = new SmtpClient(mMailSettings.Smtp.Network.Host, mMailSettings.Smtp.Network.Port);
            SmtpClient smtp = new SmtpClient();

            // *** To authenticate we set the username and password properites on the SmtpClient
            smtp.Credentials = new NetworkCredential(ConfigurationManager.AppSettings["smtpUsername"].ToString(), ConfigurationManager.AppSettings["smtpPassword"].ToString());

            // *** Send an email
            smtp.Send(mail);

        }

        // *** Exception Handler
        catch (Exception ex)
        {
            Exception ex2 = ex;
            string errorMessage = string.Empty;

            while (ex2 != null)
            {

                errorMessage += ex2.ToString();
                ex2 = ex2.InnerException;

            }


        }

    }


}
