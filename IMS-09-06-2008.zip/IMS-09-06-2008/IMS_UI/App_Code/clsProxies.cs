using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Collections;
using System.Data.SqlClient;

#region "--Class Description--"
///<classname>Proxies Transaction class</classname>
///<author>Santhosh Kumar</author>
///<date created>19/5/2008</datecreated>
///<datemodified>19/5/2008</datemodified>
///<modified by>Santhosh Kumar</modified by>
///<no. of classes>1</no. of classes>
///<no. of methods></no. of methods>
/// <summary>
/// Class used to insert, update and delete the proxies information from the databse
/// </summary>
/// 
#endregion

public class clsProxies
{

    // *** Declare the global variables
    data_Operations objData;

    // *** Initialize the constructor
    public clsProxies()
	{
		//
		// TODO: Add constructor logic here
		//
        objData = new data_Operations();
	}

    /// <summary>
    /// Function to retrieve proxy details from the database
    /// </summary>
    /// <param name="proxyId">proxy id</param>
    /// <returns>dataset containing details pertaining to the proxy id</returns>
    public DataSet GetProxyDetails(int proxyId)
    {

        try
        {
        
            // *** Open the database connection
            string strSuccess = objData.openConnection();
            DataSet ds = new DataSet();

            // *** Check if connection is successfull
            if (strSuccess == "success")
            {

                // *** Declare the hash table
                Hashtable hsh = new Hashtable();
                hsh.Add("@Id", proxyId);

                // *** Execute the stored procedure
                ds = objData.getDataSet("ui_porxies_GetDetails", true, hsh);

            }

            // *** Close the database connection
            objData.closeConnection();
            return ds;

        }
        catch
        {

            // *** Close the database connection
            objData.closeConnection();
            return null;

        }

    }

    /// <summary>
    /// Function to insert the proxy data into the database
    /// </summary>
    /// <param name="strName">proxy name</param>
    /// <param name="strHost">proxy host</param>
    /// <param name="port">proxy port</param>
    /// <param name="UserName">username</param>
    /// <param name="strPassword">password</param>
    /// <param name="iSlow">slow threshold</param>
    public void InsertProxies(string strName, string strHost, string port, string UserName, string strPassword, int iSlow)
    {

        try
        {
        
            // *** Open the database connection
            string strSuccess = objData.openConnection();
            

            // *** Check if connection is successfull
            if (strSuccess == "success")
            {

                // *** Declare the hashtable and initialize the parameters
                Hashtable hsh = new Hashtable();
                hsh.Add("@Name", strName);
                if (strHost != "")
                {
                    hsh.Add("@Host", strHost);
                }
                if (port != "")
                {
                    hsh.Add("@Port", port);
                }
                if (UserName != "")
                {
                    hsh.Add("@UserId", UserName);
                }
                if (strPassword != "")
                {
                    hsh.Add("@PassWord", strPassword);
                }
                hsh.Add("@Slow", iSlow);
                
                // *** Execute the stored procedure
               objData.executeQuery("ui_porxies_Create", true, hsh);

            }

            // *** Close the database connection
            objData.closeConnection();

        }
        catch
        {

            // *** Close the database connection
            objData.closeConnection();

        }

    }

    /// <summary>
    /// Fuction to update proxy data into the database
    /// </summary>
    /// <param name="strName">proxy name</param>
    /// <param name="strHost">proxy host</param>
    /// <param name="port">proxy port</param>
    /// <param name="UserName">username</param>
    /// <param name="strPassword">password</param>
    /// <param name="iSlow">slow threshold</param>
    public void UpdateProxies(int proxyId, string strName, string strHost, string port, string UserName, string strPassword, int iSlow)
    {
        
        try
        {

            // *** Open the database connection
            string strSuccess = objData.openConnection();

            // *** Check if connection is successfull
            if (strSuccess == "success")
            {

                // *** Declare the hash table and initialize the parameters
                Hashtable hsh = new Hashtable();
                hsh.Add("@Id", proxyId);
                hsh.Add("@Name", strName);
                if (strHost != "")
                {
                    hsh.Add("@Host", strHost);
                }
                if (port != "")
                {
                    hsh.Add("@Port", port);
                }
                if (UserName != "")
                {
                    hsh.Add("@UserId", UserName);
                }
                if (strPassword != "")
                {
                    hsh.Add("@PassWord", strPassword);
                }
                hsh.Add("@Slow", iSlow);

                // *** Execute the stored procedure
                objData.executeQuery("ui_porxies_Update", true, hsh);

            }

            // *** Close the database connection
            objData.closeConnection();

        }
        catch
        {

            // *** Close the database connection
            objData.closeConnection();

        }

    }

    /// <summary>
    /// Function to delte the proxy data from the database
    /// </summary>
    /// <param name="ProxyId">proxy id</param>
    public void DeleteProxies(int ProxyId)
    {

        try
        {

            // *** Open the database connection
            string strSuccess = objData.openConnection();

            // *** Check if connection is successfull
            if (strSuccess == "success")
            {

                // *** Declare the hash table
                Hashtable hsh = new Hashtable();
                hsh.Add("@Id", ProxyId);

                // *** Execute the stored procedure
                objData.executeQuery("ui_porxies_Delete", true, hsh);

            }

            // *** Close the datbase connection
            objData.closeConnection();

        }
        catch
        {

            // *** Close the database connection
            objData.closeConnection();

        }

    }

}
