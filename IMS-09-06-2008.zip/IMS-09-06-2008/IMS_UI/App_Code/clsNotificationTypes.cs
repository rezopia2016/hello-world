using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Collections;

#region "--Class Description--"
///<classname>Notificaiton Types Transaction class</classname>
///<author>Santhosh Kumar</author>
///<date created>18/5/2008</datecreated>
///<datemodified>18/5/2008</datemodified>
///<modified by>Santhosh Kumar</modified by>
///<no. of classes>1</no. of classes>
///<no. of methods></no. of methods>
/// <summary>
/// Class used to insert, update and delete the notification types information from the databse
/// </summary>
/// 
#endregion

public class clsNotificationTypes
{

    // *** Declare the global variables
    data_Operations objData;

    // *** Initialize the constructor
    public clsNotificationTypes()
	{
		//
		// TODO: Add constructor logic here
		//
        objData = new data_Operations();

	}

    /// <summary>
    /// Function to retrieve the notification type details from the database
    /// </summary>
    /// <param name="typeId">type id</param>
    /// <returns>dataset contains information about the details about the notification type</returns>
    public DataSet GetNotificationTypesDetails(int typeId)
    {

        try
        {

            // *** Open a database connection
            string strSuccess = objData.openConnection();
            DataSet ds = new DataSet();

            // *** Check if conection is successfull
            if (strSuccess == "success")
            {

                // *** Declare the hash table
                Hashtable hsh = new Hashtable();
                hsh.Add("@Id", typeId);

                // *** Execute the stored procedure
                ds = objData.getDataSet("ui_NotificationTypes_GetDetails", true, hsh);

            }

            // *** Close the database connection
            objData.closeConnection();
            return ds;

        }
        catch
        {

            // *** Close the database connection
            objData.closeConnection();
            return null;

        }

    }

    /// <summary>
    /// Function to insert the notification data into the database
    /// </summary>
    /// <param name="id">id</param>
    /// <param name="typeName">type name</param>
    /// <param name="icon">path for the image</param>
    /// <returns></returns>
    public int InsertNotificationType(int id, string typeName, string icon)
    {

        try
        {
        
            int retVal = 0;
            
            // *** Open the database connection
            string strSuccess = objData.openConnection();

            // *** Check if connection is successfull
            if (strSuccess == "success")
            {

                // *** Declare the hash table and initialize the parameters
                Hashtable hsh = new Hashtable();
                hsh.Add("@id", id);
                hsh.Add("@Name", typeName);
                hsh.Add("@icon", icon);

                // *** Execute the stored procedure
                retVal = objData.executeQuery("ui_NotificationTypes_Create", true, hsh);

            }

            // *** Close the database connection
            objData.closeConnection();
            return retVal;

        }
        catch
        {

            // *** Close the database connection
            objData.closeConnection();
            return 0;

        }

    }

    /// <summary>
    /// Function to update the notification type details in the database
    /// </summary>
    /// <param name="id">id</param>
    /// <param name="typeName">type name</param>
    /// <param name="icon">path of the image</param>
    /// <returns></returns>
    public int UpdateNotificationType(int id, string typeName, string icon)
    {

        try
        {
        
            int retVal = 0;
            
            // *** Open the database connection
            string strSuccess = objData.openConnection();

            // *** Check if connection is sucessfull
            if (strSuccess == "success")
            {

                // *** Declare the hashtable and initialize the parameter
                Hashtable hsh = new Hashtable();
                hsh.Add("@id", id);
                hsh.Add("@Name", typeName);
                hsh.Add("@icon", icon);

                // *** Execute the stored procedure
                retVal =  objData.executeQuery("ui_NotificationTypes_Update", true, hsh);
                
            }

            // *** Close the database connection
            objData.closeConnection();
            return retVal;

        }
        catch
        {

            // *** Close the database connection
            objData.closeConnection();
            return 0;

        }

    }

    /// <summary>
    /// Function to delete the notification type details
    /// </summary>
    /// <param name="typeId">type id</param>
    /// <returns></returns>
    public int DeleteNotificationTypes(int typeId)
    {
       
        try
        {

            int retVal = 0;

            // *** Open the database connection
            string strSuccess = objData.openConnection();

            // *** Check if connection is successful
            if (strSuccess == "success")
            {

                // *** Declare the hashtable
                Hashtable hsh = new Hashtable();
                hsh.Add("@Id", typeId);

                // *** Execute the stored procedure
                retVal = objData.executeQuery("ui_NotificationTypes_Delete", true, hsh);

            }

            // *** Close the database connection
            objData.closeConnection();
            return retVal;

        }
        catch
        {

            // *** Close the database connection
            objData.closeConnection();
            return 0;

        }

    }

}
