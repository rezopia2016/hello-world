using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Collections;

#region "--Class Description--"
///<classname>Groups Transaction class</classname>
///<author>Santhosh Kumar</author>
///<date created>18/5/2008</datecreated>
///<datemodified>18/5/2008</datemodified>
///<modified by>Santhosh Kumar</modified by>
///<no. of classes>1</no. of classes>
///<no. of methods></no. of methods>
/// <summary>
/// Class used to insert, update and delete the groups information from the databse
/// </summary>
/// 
#endregion
public class clsGroups
{

    // *** Declare the local variables
    data_Operations objData;

    // *** Initialize the constructor
    public clsGroups()
	{
		//
		// TODO: Add constructor logic here
		//
        objData = new data_Operations();

	}

    /// <summary>
    /// Function to get details about a perticular group
    /// </summary>
    /// <param name="grpId">group id</param>
    /// <returns>dataset containg details about the group id</returns>
    public DataSet GetGroupDetails(int grpId)
    {
      
        try
        {
            
            // *** Open the database connection
            string strSuccess = objData.openConnection();
            DataSet ds = new DataSet();

            // *** Check if connection is successful
            if (strSuccess == "success")
            {

                // *** Declare the hash table
                Hashtable hsh = new Hashtable();
                hsh.Add("@GroupId", grpId);

                // *** Execute the stored procedure
                ds = objData.getDataSet("ui_Groups_Details", true, hsh);

            }

            // *** Close the database connection
            objData.closeConnection();
            return ds;

        }
        catch
        {

            // *** Close the database connection
            objData.closeConnection();
            return null;

        }

    }

    /// <summary>
    /// Function to insert the group data into the database
    /// </summary>
    /// <param name="grpName">group name</param>
    public void InsertGroup(string grpName)
    {

        try
        {
        
            // *** Open the database connection
            string strSuccess = objData.openConnection();
            
            // *** Check if connection is successfull
            if (strSuccess == "success")
            {

                // *** Declare the hash table
                Hashtable hsh = new Hashtable();
                hsh.Add("@GroupName", grpName);

                // *** Execute the stored procedure
                objData.executeQuery("ui_Groups_Create", true, hsh);

            }

            // *** Close the database connection
            objData.closeConnection();

        }
        catch
        {

            // *** Close the database connection
            objData.closeConnection();

        }

    }

    /// <summary>
    /// Functin to update the group data in the database
    /// </summary>
    /// <param name="grpId">group id</param>
    /// <param name="grpName">group name</param>
    public void UpdateGroup(int grpId, string grpName)
    {

        try
        {
        
            // *** Open a database connection
            string strSuccess = objData.openConnection();

            // *** Check if connection is successfull
            if (strSuccess == "success")
            {

                // *** Declare the hash table and initialize the parameters
                Hashtable hsh = new Hashtable();
                hsh.Add("@Id", grpId);
                hsh.Add("@GroupName", grpName);

                // *** Execute the stored procedure
                objData.executeQuery("ui_Groups_Update", true, hsh);

            }

            // *** Close the database connection
            objData.closeConnection();

        }
        catch
        {

            // *** Close the database connection
            objData.closeConnection();

        }

    }

    /// <summary>
    /// Function to delate the group data from the database 
    /// </summary>
    /// <param name="grpId">group id</param>
    public void DeleteGroup(int grpId)
    {

        try
        {
        
            // *** Open the database connection
            string strSuccess = objData.openConnection();
            
            // *** Check if connection is successfull
            if (strSuccess == "success")
            {

                // *** Declare the hashtable and initialize the parameters
                Hashtable hsh = new Hashtable();
                hsh.Add("@Id", grpId);

                // *** Execute the stored procedure
                objData.executeQuery("ui_Groups_Delete", true, hsh);

            }

            // *** Close the database connection
            objData.closeConnection();

        }
        catch
        {
            
            // *** Close the database connection
            objData.closeConnection();

        }

    }

}
