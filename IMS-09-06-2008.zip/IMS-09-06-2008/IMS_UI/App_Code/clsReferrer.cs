using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Collections;

#region "--Class Description--"
///<classname>Referrer Transaction class</classname>
///<author>Santhosh Kumar</author>
///<date created>20/5/2008</datecreated>
///<datemodified>20/5/2008</datemodified>
///<modified by>Santhosh Kumar</modified by>
///<no. of classes>1</no. of classes>
///<no. of methods></no. of methods>
/// <summary>
/// Class used to insert, update and delete the referrer information from the databse
/// </summary>
/// 
#endregion

public class clsReferrer
{

    // *** Declare the global variables
    data_Operations objData;

    // *** Initialize the constructor
    public clsReferrer()
	{
		//
		// TODO: Add constructor logic here
		//
        objData = new data_Operations();

	}

    /// <summary>
    /// Function to retrieve the referrer details from the database
    /// </summary>
    /// <param name="referrerId">referrer id</param>
    /// <returns>dataset retrieves the referrer details from the database</returns>
    public DataSet GetReferrerDetails(int referrerId)
    {

        try
        {
        
            // *** Open the database connection
            string strSuccess = objData.openConnection();

            DataSet ds = new DataSet();

            // *** Check if connection is successful
            if (strSuccess == "success")
            {

                // *** Dedclare the hash table and initialize the parameters
                Hashtable hsh = new Hashtable();
                hsh.Add("@Id", referrerId);

                // *** Execute the stored procedure
                ds = objData.getDataSet("ui_Referrer_GetDetails", true, hsh);

            }

            // *** Close the database connection
            objData.closeConnection();
            return ds;

        }
        catch
        {
            
            // *** Close the database connection
            objData.closeConnection();
            return null;

        }

    }

    /// <summary>
    /// Function to insert the referrer data into the database
    /// </summary>
    /// <param name="strName">referrer name</param>
    /// <param name="strReferrer">referrer</param>
    public void InsertReferrer(string strName, string strReferrer)
    {

        try
        {
        
            // *** Open the dataase connection
            string strSuccess = objData.openConnection();
            
            // *** Check if connection is successfull
            if (strSuccess == "success")
            {

                // *** Declare the hashtable and initialize the parameters
                Hashtable hsh = new Hashtable();
                hsh.Add("@Name", strName);
                hsh.Add("@Referrer", strReferrer);

                // *** Execute the stored procedure
                objData.executeQuery("ui_Referrer_Create", true, hsh);

            }

            // *** Close the database connection
            objData.closeConnection();

        }
        catch
        {
            
            // *** Close the database connection
            objData.closeConnection();

        }

    }

    /// <summary>
    /// Function to update the referrer data into the database
    /// </summary>
    /// <param name="referrerId">referrer id</param>
    /// <param name="strName">referrer name</param>
    /// <param name="strReferrer">referrer</param>
    public void UpdateReferrer(int referrerId, string strName, string strReferrer)
    {

        try
        {
        
            // *** Open the database connection
            string strSuccess = objData.openConnection();

            // *** Check if connection is successfull
            if (strSuccess == "success")
            {

                // *** Declare the hashtable and initialize the parameters
                Hashtable hsh = new Hashtable();
                hsh.Add("@Id", referrerId);
                hsh.Add("@Name", strName);
                hsh.Add("@Referrer ", strReferrer);

                // *** Execute the stored procedure
                objData.executeQuery("ui_Referrer_Update", true, hsh);

            }

            // *** Close the database connection
            objData.closeConnection();

        }
        catch
        {
            
            // *** Close the database connection
            objData.closeConnection();

        }

    }

    /// <summary>
    /// Function to delete the referrer data from the referrer table in the database
    /// </summary>
    /// <param name="referrerId">referrer id</param>
    public void DeleteReferrer(int referrerId)
    {

        try
        {
        
            // *** Open the database connection
            string strSuccess = objData.openConnection();
            
            // *** Check if connection is successful
            if (strSuccess == "success")
            {

                // *** Declare the hash table and initialize the referrer id
                Hashtable hsh = new Hashtable();
                hsh.Add("@Id", referrerId);

                // *** Execute the stored procedure
                objData.executeQuery("ui_Referrer_Delete", true, hsh);

            }

            // *** Close the database connection
            objData.closeConnection();

        }
        catch
        {

            // *** Close the database connection
            objData.closeConnection();

        }

    }

}
