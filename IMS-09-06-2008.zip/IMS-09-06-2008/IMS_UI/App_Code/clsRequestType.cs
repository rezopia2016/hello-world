using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Collections;

#region "--Class Description--"
///<classname>Request Type class</classname>
///<author>Santhosh Kumar</author>
///<date created>20/5/2008</datecreated>
///<datemodified>20/5/2008</datemodified>
///<modified by>Santhosh Kumar</modified by>
///<no. of classes>1</no. of classes>
///<no. of methods></no. of methods>
/// <summary>
/// Class used to insert, update and delete the request type information from the database
/// </summary>
/// 
#endregion

public class clsRequestType
{

    // *** Declare the global variables
    data_Operations objData;

    // *** Initialize the constructor
    public clsRequestType()
	{
		//
		// TODO: Add constructor logic here
		//
        objData = new data_Operations();

	}

    /// <summary>
    /// Function to get request type details from the database
    /// </summary>
    /// <param name="typeId">type id</param>
    /// <returns>dataset that retrieves request type details for the id passed</returns>
    public DataSet GetRequestTypeDetails(int typeId)
    {

        try
        {

            // *** Open the database connection
            string strSuccess = objData.openConnection();
            DataSet ds = new DataSet();

            // *** Check if connection is successfull
            if (strSuccess == "success")
            {

                // *** Declare the hash table and initialize the parameters
                Hashtable hsh = new Hashtable();
                hsh.Add("@Id", typeId);

                // *** Execute the stored procedure
                ds = objData.getDataSet("ui_RequestType_GetDetails", true, hsh);

            }

            // *** Close the database connection
            objData.closeConnection();
            return ds;

        }
        catch
        {

            // *** Close the database connection
            objData.closeConnection();
            return null;

        }

    }

    /// <summary>
    /// Function to insert the request tye data into the data base
    /// </summary>
    /// <param name="typeName">type name</param>
    public void InsertRequestType(string typeName)
    {

        try
        {
        
            // *** Open the database connection
            string strSuccess = objData.openConnection();
            
            // *** Check if connection is successfull
            if (strSuccess == "success")
            {

                // *** Declare the hash table and init. the parameters
                Hashtable hsh = new Hashtable();
                hsh.Add("@Name", typeName);

                // *** Execute the stored procedure
                objData.executeQuery("ui_RequestType_Create", true, hsh);

            }

            // *** Close the database connections
            objData.closeConnection();

        }
        catch
        {

            // *** Close the database connections
            objData.closeConnection();

        }

    }

    /// <summary>
    /// Function to update request type data into the data base 
    /// </summary>
    /// <param name="typeId">type id </param>
    /// <param name="typeName">type name</param>
    public void UpdateRequestType(int typeId, string typeName)
    {
        
        try
        {

            // *** Open the database connection
            string strSuccess = objData.openConnection();

            // *** Check if connection is successfull
            if (strSuccess == "success")
            {

                // *** Declare the hash table and init. the parameters
                Hashtable hsh = new Hashtable();
                hsh.Add("@Id", typeId);
                hsh.Add("@Name", typeName);

                // *** Execute the stored procedure
                objData.executeQuery("ui_RequestType_Update", true, hsh);

            }

            // *** Close the database connection
            objData.closeConnection();

        }
        catch
        {
            
            // *** Close the database connection
            objData.closeConnection();

        }

    }

    /// <summary>
    /// Function to delete the request type data from the database
    /// </summary>
    /// <param name="typeId">type id</param>
    public void DeleteRequestType(int typeId)
    {

        try
        {
        
            // *** Open the database connection
            string strSuccess = objData.openConnection();
            
            // *** Check if connection is successful
            if (strSuccess == "success")
            {

                // *** Declare the hash table and init. the parameters
                Hashtable hsh = new Hashtable();
                hsh.Add("@Id", typeId);

                // *** Execute the stored procedure
                objData.executeQuery("ui_RequestType_Delete", true, hsh);

            }

            // *** Close the database connection
            objData.closeConnection();

        }
        catch
        {
            
            // *** Close the database connection
            objData.closeConnection();

        }

    }

}
