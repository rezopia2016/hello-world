using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Collections;

#region "--Class Description--"
///<classname>Queue Transaction class</classname>
///<author>Santhosh Kumar</author>
///<date created>19/5/2008</datecreated>
///<datemodified>19/5/2008</datemodified>
///<modified by>Santhosh Kumar</modified by>
///<no. of classes>1</no. of classes>
///<no. of methods></no. of methods>
/// <summary>
/// Class used to insert, update and delete the queue information from the databse
/// </summary>
/// 
#endregion

public class clsQueues
{

    // *** Declare the global variables
    data_Operations objData;

    // *** Initialize the constructors
    public clsQueues()
	{
		//
		// TODO: Add constructor logic here
		//
        objData = new data_Operations();

	}

    /// <summary>
    /// Function to retrieve the queue details from the database 
    /// </summary>
    /// <param name="QueueId">queue id</param>
    /// <returns>dataset that contains the queue details for the id passed</returns>
    public DataSet GetQueueDetails(int QueueId)
    {

        try
        {

            // *** Open the database connection
            string strSuccess = objData.openConnection();
            DataSet ds = new DataSet();

            // *** Check if connection is successfull
            if (strSuccess == "success")
            {

                // *** Declare the hashtable and initialize its parameters
                Hashtable hsh = new Hashtable();
                hsh.Add("@Id", QueueId);

                // *** Execute the stored procedure
                ds = objData.getDataSet("ui_queue_GetDetails", true, hsh);

            }

            // *** Close the database connection
            objData.closeConnection();
            return ds;

        }
        catch
        {

            // *** Close the database connection
            objData.closeConnection();
            return null;

        }

    }

    /// <summary>
    /// Function to inser Queue data into the database
    /// </summary>
    /// <param name="Name">queue name</param>
    /// <param name="success">success interval</param>
    /// <param name="fail">fail interval</param>
    /// <param name="max">maximum threads</param>
    /// <param name="isEnabled">check if enabled</param>
    public void InsertQueue(string Name, int success, int fail, int max, Boolean isEnabled)
    {
        
        try
        {

            // *** Open the database connection
            string strSuccess = objData.openConnection();

            // *** Check if connection is successful
            if (strSuccess == "success")
            {

                // *** Declare the hash table and initialize the parameters
                Hashtable hsh = new Hashtable();
                hsh.Add("@Name", Name);
                hsh.Add("@intervalSuccess", success);
                hsh.Add("@intervalFail", fail);
                hsh.Add("@MaxThreads", max);
                hsh.Add("@enabled", isEnabled);

                // *** Execute the stored procedure
                objData.executeQuery("ui_queue_Create", true, hsh);

            }

            // *** Close the database connection
            objData.closeConnection();

        }
        catch
        {

            // *** Close the database connection
            objData.closeConnection();

        }

    }

    /// <summary>
    /// Function to update queue data in the database
    /// </summary>
    /// <param name="QueueId">queue id</param>
    /// <param name="Name">name</param>
    /// <param name="success">success interval</param>
    /// <param name="fail">fail interval</param>
    /// <param name="max">maximum thread</param>
    /// <param name="isEnabled">enabled flag</param>
    public void UpdateQueue(int QueueId, string Name, int success, int fail, int max, Boolean isEnabled)
    {

        try
        {
        
            // *** Open the database connection
            string strSuccess = objData.openConnection();

            // *** Check if connection is successful
            if (strSuccess == "success")
            {

                // *** Declare the hash table
                Hashtable hsh = new Hashtable();
                hsh.Add("@Id", QueueId);
                hsh.Add("@Name", Name);
                hsh.Add("@intervalSuccess", success);
                hsh.Add("@intervalFail", fail);
                hsh.Add("@MaxThreads", max);
                hsh.Add("@enabled", isEnabled);

                // *** Execute the stored procedure
                objData.executeQuery("ui_queue_Update", true, hsh);

            }

            // *** Close the database connection
            objData.closeConnection();

        }
        catch
        {
            
            // *** Close the database connection
            objData.closeConnection();

        }

    }

    /// <summary>
    /// Function to delete the queue data from the database
    /// </summary>
    /// <param name="queueId">queue id</param>
    public void Deletequeue(int queueId)
    {

        try
        {
        
            // *** Open the database connection
            string strSuccess = objData.openConnection();
            
            // *** Check if connection is successful
            if (strSuccess == "success")
            {

                // *** Declare the hash table and initiaalize the parameter
                Hashtable hsh = new Hashtable();
                hsh.Add("@Id", queueId);

                // *** Execute the stored procedure
                objData.executeQuery("ui_queue_delete", true, hsh);

            }

            // *** Close the database connection
            objData.closeConnection();

        }
        catch
        {

            // *** Close the database connection
            objData.closeConnection();

        }

    }

}
