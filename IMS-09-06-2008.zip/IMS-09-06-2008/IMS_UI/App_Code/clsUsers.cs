using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Collections;
using System.Data.SqlClient;

#region "--Class Description--"
///<classname>Users Transaction class</classname>
///<author>Santhosh Kumar</author>
///<date created>22/5/2008</datecreated>
///<datemodified>22/5/2008</datemodified>
///<modified by>Santhosh Kumar</modified by>
///<no. of classes>1</no. of classes>
///<no. of methods></no. of methods>
/// <summary>
/// Class used to insert, update and delete the users information from the database
/// </summary>
/// 
#endregion

public class clsUsers
{

    // *** Declare the global variables
    data_Operations objData;

    // *** Initialize the constructors
    public clsUsers()
	{
		//
		// TODO: Add constructor logic here
		//
        objData = new data_Operations();

	}

    /// <summary>
    /// Function to retrive the user details from the database based on the user id
    /// </summary>
    /// <param name="UserId">user id</param>
    /// <returns>dataset retrieves the user details based on the user id</returns>
    public DataSet GetUserDetails(int UserId)
    {

        try
        {

            // *** Open the database connection
            string strSuccess = objData.openConnection();
            DataSet ds = new DataSet();

            // *** Check if connection is successfull
            if (strSuccess == "success")
            {

                // *** Declare the hash table and init. the parameters
                Hashtable hsh = new Hashtable();
                hsh.Add("@Id", UserId);

                // *** Execute the stored procedure
                ds = objData.getDataSet("ui_users_GetDetails", true, hsh);

            }

            // *** Close the database connection
            objData.closeConnection();
            return ds;

        }
        catch
        {

            // *** Close the database connection
            objData.closeConnection();
            return null;

        }
        
    }

    /// <summary>
    /// Function to insert the user data into the database
    /// </summary>
    /// <param name="UserName">user name </param>
    /// <param name="sqlName">sql name</param>
    /// <param name="email">email</param>
    /// <param name="phoneNo">phone no</param>
    /// <param name="isAdmin">is admin</param>
    /// <returns></returns>
    public int InsertUsers(string UserName, string sqlName, string email, string phoneNo, Boolean isAdmin,string password)
    {
       
        try
        {
        
            // *** Open the database connection
            string strSuccess = objData.openConnection();
            int UserId = 0;

            // *** Check if connection is sucessfull
            if (strSuccess == "success")
            {

                // *** Declare the hash table and init. the parameters
                Hashtable hsh = new Hashtable();
                hsh.Add("@Name", UserName);
                hsh.Add("@sqlName", sqlName);
                hsh.Add("@email", email);
                hsh.Add("@phone", phoneNo);
                hsh.Add("@isAdmin", isAdmin);
                hsh.Add("@password", password);

                // *** Execute the stored procedure
                SqlDataReader sqlDr = objData.getDataReader("ui_users_Create", true, hsh);
                
                // *** Check if datareader is null
                if (sqlDr != null && sqlDr.Read() == true)
                {

                    // *** Initialize the user id with the value returned from the stored procedure
                    UserId = Convert.ToInt32(sqlDr[0].ToString());

                }
            }

            // *** Close the database connection
            objData.closeConnection();
            return UserId;

        }
        catch
        {

            // *** Close the database connection
            objData.closeConnection();
            return 0;

        }

    }

    /// <summary>
    /// Function to insert user access details into the database
    /// </summary>
    /// <param name="UserId">user id</param>
    /// <param name="GroupId">group id</param>
    /// <param name="isRead">is read</param>
    /// <param name="isWrite">is write</param>
    /// <param name="isEmail">is email</param>
    /// <param name="isSMS">is sms</param>
    public void insertUserAccess(int UserId, int GroupId, Boolean isRead, Boolean isWrite, Boolean isEmail, Boolean isSMS)
    {

        try
        {
        
            // *** Open the database connection
            string strSuccess = objData.openConnection();
            
            // *** Check if connetion is successfull
            if (strSuccess == "success")
            {

                // *** Declare the hash table and init. the parameters
                Hashtable hsh = new Hashtable();
                hsh.Add("@UserId", UserId);
                hsh.Add("@GroupId", GroupId);
                hsh.Add("@Read", isRead);
                hsh.Add("@Write", isWrite);
                hsh.Add("@email", isEmail);
                hsh.Add("@SMS", isSMS);

                // *** Execute the stored procedure
                objData.executeQuery("ui_users_Access_Create", true, hsh);
            
            }
            
            // *** Close the database connection
            objData.closeConnection();

        }
        catch
        {
            
            // *** Close the database connection
            objData.closeConnection();

        }

    }

    /// <summary>
    /// Function to update the user details information in the database
    /// </summary>
    /// <param name="UserId">user id</param>
    /// <param name="UserName">user name</param>
    /// <param name="sqlName">sql name</param>
    /// <param name="email">email</param>
    /// <param name="phoneNo">phone no.</param>
    /// <param name="isAdmin">is admin</param>
    /// <returns></returns>
    public int UpdateUsers(int UserId, string UserName, string sqlName, string email, string phoneNo, Boolean isAdmin, string password)
    {

        try
        {
        
            // *** Open the database connection
            string strSuccess = objData.openConnection();
            int noOfRecs = 0;

            // *** Check if connection is sucessfull
            if (strSuccess == "success")
            {

                // *** Declare the hash table and init. the parameters
                Hashtable hsh = new Hashtable();
                hsh.Add("@Id", UserId);
                hsh.Add("@Name", UserName);
                hsh.Add("@sqlName", sqlName);
                hsh.Add("@email", email);
                hsh.Add("@phone", phoneNo);
                hsh.Add("@isAdmin", isAdmin);
                hsh.Add("@password", password);

                // *** Execute the stored procedure
                noOfRecs = objData.executeQuery("ui_users_update", true, hsh);

            }

            // *** Close the database connection
            objData.closeConnection();
            return noOfRecs;

        }
        catch
        {
            
            // *** Close the database connection
            objData.closeConnection();
            return 0;

        }

    }

    /// <summary>
    /// Function to delete the user access details from the database
    /// </summary>
    /// <param name="UserId">user id</param>
    public void deleteUserAccess(int UserId)
    {

        try
        {
        
            // *** Open the database connection
            string strSuccess = objData.openConnection();
            
            // *** Check if connection is successfull
            if (strSuccess == "success")
            {
                
                // *** Declare the hashtable and init. the parameters
                Hashtable hsh = new Hashtable();
                hsh.Add("@Id", UserId);

                // *** Execute the stored procedure
                objData.executeQuery("ui_users_Access_delete", true, hsh);

            }

            // *** Close the database connection
            objData.closeConnection();

        }
        catch
        {
            
            // *** Close the database connection
            objData.closeConnection();

        }

    }

    /// <summary>
    /// Function to delete the user details into the database
    /// </summary>
    /// <param name="UserId">user id</param>
    public void DeleteUsers(int UserId)
    {
       
        try
        {
            
            // *** Open the database connection
            string strSuccess = objData.openConnection();
            
            // *** Check if connection is successfull
            if (strSuccess == "success")
            {

                // *** Declare the hash table and init. the parameters
                Hashtable hsh = new Hashtable();
                hsh.Add("@Id", UserId);

                // *** Execute the stored procedure
                objData.executeQuery("ui_users_delete", true, hsh);

            }

            // *** Close the database connection
            objData.closeConnection();

        }
        catch
        {
            
            // *** Close the database connection
            objData.closeConnection();

        }

    }

}
