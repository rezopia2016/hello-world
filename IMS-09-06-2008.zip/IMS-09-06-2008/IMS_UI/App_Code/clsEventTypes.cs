using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Collections;

#region "--Class Description--"
///<classname>Event Types Transaction class</classname>
///<author>Santhosh Kumar</author>
///<date created>17/5/2008</datecreated>
///<datemodified>17/5/2008</datemodified>
///<modified by>Santhosh Kumar</modified by>
///<no. of classes>1</no. of classes>
///<no. of methods></no. of methods>
/// <summary>
/// Class used to insert, update and delete the event types levels information from the databse
/// </summary>
/// 
#endregion

public class clsEventTypes
{

    //Declafe the local variables
    data_Operations objData;

    // *** Initialize the constructor
    public clsEventTypes()
	{
		//
		// TODO: Add constructor logic here
		//
        objData = new data_Operations();
	}


    /// <summary>
    /// Funtion to retrieve event details
    /// </summary>
    /// <param name="typeId">event id</param>
    /// <returns>dataset containing the event information</returns>
    public DataSet GetEventTypesDetails(int typeId)
    {
       
        try
        {

            // *** Open a database connection
            string strSuccess = objData.openConnection();
            DataSet ds = new DataSet();

            // *** Check if connection is successful
            if (strSuccess == "success")
            {

                // *** Declare the hash table and intialize the values
                Hashtable hsh = new Hashtable();
                hsh.Add("@Id", typeId);

                // *** Execute the stored procedure and retrieve information in the dataset
                ds = objData.getDataSet("ui_EventTypes_GetDetails", true, hsh);

            }

            // *** Close the data connection
            objData.closeConnection();
            return ds;

        }
        catch
        {

            // *** Close the data connection
            objData.closeConnection();
            return null;

        }

    }

    /// <summary>
    /// Function to insert event details
    /// </summary>
    /// <param name="id">event id</param>
    /// <param name="typeName">event type name</param>
    /// <param name="icon">path of the image</param>
    /// <returns></returns>
    public int InsertEventType(int id, string typeName, string icon)
    {

        try
        {
        
            int retVal = 0;
            
            // *** Open a database connection
            string strSuccess = objData.openConnection();
            
            // *** Check if connection is successful
            if (strSuccess == "success")
            {

                // *** Declare an hash table and initialize the parameters
                Hashtable hsh = new Hashtable();
                hsh.Add("@id", id);
                hsh.Add("@Name", typeName);
                hsh.Add("@icon", icon);

                // *** Execute the query
                retVal = objData.executeQuery("ui_EventTypes_Create", true, hsh);

            }

            // *** Close the database connection
            objData.closeConnection();
            return retVal;

        }
        catch
        {
            
            // *** Close the database connection
            objData.closeConnection();
            return 0;

        }

    }

    /// <summary>
    /// Function to update Event Type
    /// </summary>
    /// <param name="id">event id</param>
    /// <param name="typeName">event type name</param>
    /// <param name="icon">path of the image</param>
    /// <returns></returns>
    public int UpdateEventType(int id, string typeName, string icon)
    {

        try
        {
        
            int retVal = 0;
            
            // *** Open a database connection
            string strSuccess = objData.openConnection();
            
            // *** Check if connection is successfull
            if (strSuccess == "success")
            {

                // *** Declare a hash table and initialize its parameters
                Hashtable hsh = new Hashtable();
                hsh.Add("@id", id);
                hsh.Add("@Name", typeName);
                hsh.Add("@icon", icon);

                // *** Execute the query
                retVal =  objData.executeQuery("ui_EventTypes_Update", true, hsh);

            }

            // *** Close the database connection
            objData.closeConnection();
            return retVal;

        }
        catch
        {
            
            // *** Close the database connection
            objData.closeConnection();
            return 0;

        }

    }

    /// <summary>
    /// Function to delete the event type
    /// </summary>
    /// <param name="typeId">event type id</param>
    /// <returns></returns>
    public int DeleteEventType(int typeId)
    {

        try
        {
        
            int retVal = 0;
            
            // *** Open adatabase connection
            string strSuccess = objData.openConnection();
            
            // *** Check if connection is successfull
            if (strSuccess == "success")
            {

                // *** Decalare a hash table and initialize its parameters
                Hashtable hsh = new Hashtable();
                hsh.Add("@Id", typeId);

                // *** Execute the stored procedure
                retVal = objData.executeQuery("ui_EventTypes_Delete", true, hsh);

            }

            // *** Close the database connection 
            objData.closeConnection();
            return retVal;

        }
        catch
        {
            
            // *** Close the database conection
            objData.closeConnection();
            return 0;

        }

    }

}
