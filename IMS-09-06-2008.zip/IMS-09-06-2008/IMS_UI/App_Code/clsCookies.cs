using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Collections;

#region "--Class Description--"
///<classname>Cookies Transaction class</classname>
///<author>Santhosh Kumar</author>
///<date created>16/5/2008</datecreated>
///<datemodified>16/5/2008</datemodified>
///<modified by>Santhosh Kumar</modified by>
///<no. of classes>1</no. of classes>
///<no. of methods></no. of methods>
/// <summary>
/// Class used to insert, update and delete the cookies information from the databse
/// </summary>
/// 
#endregion
public class clsCookies
{
    /// <summary>
    /// Declare the local variables
    /// </summary>
    data_Operations objData;

    /// <summary>
    /// Initialize the local variables using the constructor
    /// </summary>
    public clsCookies()
	{
		//
		// TODO: Add constructor logic here
		//
        objData = new data_Operations();
	}

    /// <summary>
    /// Retrieve the Cookie details from the database 
    /// </summary>
    /// <param name="cookieId">cookie id</param>
    /// <returns>dataset containing cookie information</returns>
    public DataSet GetCookieDetails(int cookieId)
    {

        try
        {

            // *** Open a database connection
            string strSuccess = objData.openConnection();

            // *** Check if connection is successfull
            DataSet ds = new DataSet();
            if (strSuccess == "success")
            {

                // *** Declare the hashtable and pass the cookie id
                Hashtable hsh = new Hashtable();
                hsh.Add("@Id", cookieId);

                // *** Execute the stored procedure and retrieve the information in the dataset
                ds = objData.getDataSet("ui_cookies_GetDetails", true, hsh);

            }

            // *** Close the database connection
            objData.closeConnection();

            // *** Return the dataset
            return ds;

        }
        catch
        {

            // *** Close the database connection
            objData.closeConnection();
            return null;

        }

    }

    /// <summary>
    /// Function to insert the cookie information into the database
    /// </summary>
    /// <param name="cookieName">cookie name</param>
    /// <param name="strCookie">cookie information</param>
    public void InsertCookie(string cookieName, string strCookie)
    {
        
        try
        {

            // *** Open a database connection
            string strSuccess = objData.openConnection();

            // *** Check if connection is successfull
            if (strSuccess == "success")
            {

                // *** Declare the hashtable and pass the parameters
                Hashtable hsh = new Hashtable();
                hsh.Add("@Name", cookieName);
                hsh.Add("@Cookie", strCookie);

                // *** Execute the stored procedure 
                objData.executeQuery("ui_cookies_create", true, hsh);

            }

            // *** Close the database connection
            objData.closeConnection();

        }
        catch
        {

            // *** Close the database connection
            objData.closeConnection();

        }

    }

    /// <summary>
    /// Function to update the cookie information in the database
    /// </summary>
    /// <param name="cookieId">cookie id</param>
    /// <param name="cookieName">cookie name</param>
    /// <param name="strCookie">cookie information</param>
    public void UpdateCookie(int cookieId, string cookieName, string strCookie)
    {

        try
        {

            // *** Open a database connection
            string strSuccess = objData.openConnection();

            // *** Check if connection is successfull
            if (strSuccess == "success")
            {

                // *** Declare the hashtable and pass the parameters
                Hashtable hsh = new Hashtable();
                hsh.Add("@Id", cookieId);
                hsh.Add("@Name", cookieName);
                hsh.Add("@Cookie", strCookie);

                // *** Execute the stored procedure 
                objData.executeQuery("ui_cookies_Update", true, hsh);

            }

            // *** Close the database connection
            objData.closeConnection();

        }
        catch
        {

            // *** Close the database connection
            objData.closeConnection();

        }
    }

    /// <summary>
    /// Function to delete the cookie
    /// </summary>
    /// <param name="cookieId">cookie id</param>
    public void DeleteCookie(int cookieId)
    {
        
        try
        {

            // *** Open a database connection
            string strSuccess = objData.openConnection();

            // *** Check if connection is successfull
            if (strSuccess == "success")
            {

                // *** Declare the hashtable and pass the parameters
                Hashtable hsh = new Hashtable();
                hsh.Add("@Id", cookieId);

                // *** Execute the stored procedure 
                objData.executeQuery("ui_cookies_delete", true, hsh);

            }

            objData.closeConnection();

        }
        catch
        {

            objData.closeConnection();

        }

    }

}
