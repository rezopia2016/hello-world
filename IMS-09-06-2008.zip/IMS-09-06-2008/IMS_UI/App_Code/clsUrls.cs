using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Collections;
using System.Data.SqlClient;

#region "--Class Description--"
///<classname>Urls class</classname>
///<author>Santhosh Kumar</author>
///<date created>21/5/2008</datecreated>
///<datemodified>21/5/2008</datemodified>
///<modified by>Santhosh Kumar</modified by>
///<no. of classes>1</no. of classes>
///<no. of methods></no. of methods>
/// <summary>
/// Class used to insert, update and delete the urls information from the database
/// </summary>
/// 
#endregion

public class clsUrls
{

    // *** Declare the global variables 
    data_Operations objData;

    // *** Initialize the constructors
    public clsUrls()
	{
		//
		// TODO: Add constructor logic here
		//
        objData = new data_Operations();
	
    }

    /// <summary>
    /// Function to retrieve urls details from the database
    /// </summary>
    /// <param name="URLId">url id</param>
    /// <returns></returns>
    public DataSet GetUrlsDetails(int URLId)
    {
        
        try
        {
           
            // *** Open the database connection
            string strSuccess = objData.openConnection();
            DataSet ds = new DataSet();

            // *** Check if connection is successfull
            if (strSuccess == "success")
            {

                // *** Declare the hash table and init. the parameters
                Hashtable hsh = new Hashtable();
                hsh.Add("@Id", URLId);

                // *** Execute the stored procedure
                ds = objData.getDataSet("ui_Url_GetDetails", true, hsh);

            }

            // *** Close the database connection
            objData.closeConnection();
            return ds;

        }
        catch
        {

            // *** Close the database connection
            objData.closeConnection();
            return null;

        }

    }


    /// <summary>
    /// Function to insert the url details into the database
    /// </summary>
    /// <param name="GroupdId">group id </param>
    /// <param name="QueueId">queue id</param>
    /// <param name="URL">url</param>
    /// <param name="UserAgentId">user agent id</param>
    /// <param name="ReferrerId">referrer id</param>
    /// <param name="CookieId">cookie id</param>
    /// <param name="RequestTypeId">request type id</param>
    /// <param name="ProxyId">proxy id</param>
    /// <param name="minErrorLevel">min error level</param>
    /// <param name="strExpectedText">expected text</param>
    /// <param name="currentErrorLevel">current error level</param>
    /// <param name="UnHandledErrorLevel">unhandled alert level</param>
    public void InsertUrls(int GroupdId, int QueueId, string URL, int UserAgentId, int ReferrerId, int CookieId, 
                           int RequestTypeId, int ProxyId, int minErrorLevel, string strExpectedText, int currentErrorLevel, int UnHandledErrorLevel)
    {

        try
        {

            // *** Open the database connection
            string strSuccess = objData.openConnection();
            
            // *** Check if connection is successfull
            if (strSuccess == "success")
            {

                // *** Declare the parameters and initialize the parameters
                Hashtable hsh = new Hashtable();
                hsh.Add("@GroupId", GroupdId);
                hsh.Add("@QueueId", QueueId);
                hsh.Add("@Url ", URL);
                hsh.Add("@UserAgentId", UserAgentId);
                hsh.Add("@ReferrerId", ReferrerId);
                hsh.Add("@CookieId", CookieId);
                hsh.Add("@RequestTypeId", RequestTypeId);
                hsh.Add("@ProxyId", ProxyId);
                hsh.Add("@ErrorLevel", minErrorLevel);
                hsh.Add("@ExpectedText", strExpectedText);
                hsh.Add("@CurrentAlertLevel", currentErrorLevel);
                hsh.Add("@UnHandledAlertLevel", UnHandledErrorLevel);

                // *** Execute the stored procedure
               objData.executeQuery("ui_Url_Create", true, hsh);
            
            }
            
            // *** Close the database connection
            objData.closeConnection();

        }
        catch
        {
            
            // *** Close the database connection
            objData.closeConnection();

        }

    }


    /// <summary>
    /// Function to update the urls data in the database
    /// </summary>
    /// <param name="GroupdId">group id </param>
    /// <param name="QueueId">queue id</param>
    /// <param name="URL">url</param>
    /// <param name="UserAgentId">user agent id</param>
    /// <param name="ReferrerId">referrer id</param>
    /// <param name="CookieId">cookie id</param>
    /// <param name="RequestTypeId">request type id</param>
    /// <param name="ProxyId">proxy id</param>
    /// <param name="minErrorLevel">min error level</param>
    /// <param name="strExpectedText">expected text</param>
    /// <param name="currentErrorLevel">current error level</param>
    /// <param name="UnHandledErrorLevel">unhandled alert level</param>
    public void UpdateUrls(int URLId, int GroupdId, int QueueId, string URL, int UserAgentId, int ReferrerId, int CookieId,
                           int RequestTypeId, int ProxyId, int minErrorLevel, string strExpectedText, int currentErrorLevel, int UnHandledErrorLevel)
    {
       
        try
        {

            // *** Open the database connection
            string strSuccess = objData.openConnection();

            // *** Check if connection is successfull
            if (strSuccess == "success")
            {

                // *** Declare the hash table and init. the parameters
                Hashtable hsh = new Hashtable();
                hsh.Add("@Id", URLId);
                hsh.Add("@GroupId", GroupdId);
                hsh.Add("@QueueId", QueueId);
                hsh.Add("@Url ", URL);
                hsh.Add("@UserAgentId", UserAgentId);
                hsh.Add("@ReferrerId", ReferrerId);
                hsh.Add("@CookieId", CookieId);
                hsh.Add("@RequestTypeId", RequestTypeId);
                hsh.Add("@ProxyId", ProxyId);
                hsh.Add("@ErrorLevel", minErrorLevel);
                hsh.Add("@ExpectedText", strExpectedText);
                hsh.Add("@CurrentAlertLevel", currentErrorLevel);
                hsh.Add("@UnHandledAlertLevel", UnHandledErrorLevel);

                // *** Executet the stored procedure
                objData.executeQuery("ui_Url_Update", true, hsh);

            }

            // *** Close the database connection
            objData.closeConnection();

        }
        catch
        {
            
            // *** Close the database connection
            objData.closeConnection();

        }

    }

    /// <summary>
    /// Function to delete the urls data from the database
    /// </summary>
    /// <param name="URLId">url id</param>
    public void DeleteUrls(int URLId)
    {

        try
        {
        
            // *** Open the database connection
            string strSuccess = objData.openConnection();
            
            // *** Check if connection is successfull
            if (strSuccess == "success")
            {

                // *** Declare the hash table and init. the parameters
                Hashtable hsh = new Hashtable();
                hsh.Add("@Id", URLId);

                // *** Execute the stored procedure
                objData.executeQuery("ui_Url_Delete", true, hsh);

            }

            // *** Close the database connection
            objData.closeConnection();

        }
        catch
        {

            // *** Close the database connection
            objData.closeConnection();

        }

    }

}
