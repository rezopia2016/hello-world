using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Collections;

#region "--Class Description--"
///<classname>User Agents Transaction class</classname>
///<author>Santhosh Kumar</author>
///<date created>22/5/2008</datecreated>
///<datemodified>22/5/2008</datemodified>
///<modified by>Santhosh Kumar</modified by>
///<no. of classes>1</no. of classes>
///<no. of methods></no. of methods>
/// <summary>
/// Class used to insert, update and delete the user agents information from the database
/// </summary>
/// 
#endregion

public class clsUserAgents
{

    // *** Declare the global variables
    data_Operations objData;

    // *** Initialize the constructor
    public clsUserAgents()
	{
		//
		// TODO: Add constructor logic here
		//
        objData = new data_Operations();

	}

    /// <summary>
    /// Function to retrieve the user agents details from the database
    /// </summary>
    /// <param name="userAgentId">user agent id</param>
    /// <returns>dataset contains the user agent details for the id passed</returns>
    public DataSet GetUserAgentDetails(int userAgentId)
    {

        try
        {
        
            // *** Open the database connection
            string strSuccess = objData.openConnection();
            
            DataSet ds = new DataSet();
            
            // *** Check if connection is successfull
            if (strSuccess == "success")
            {

                // *** Declare the hash table and init. the parameters
                Hashtable hsh = new Hashtable();
                hsh.Add("@Id", userAgentId);

                // *** Execute the stored procedure
                ds = objData.getDataSet("ui_UserAgents_GetDetails", true, hsh);

            }

            // *** Close the database connection
            objData.closeConnection();
            return ds;

        }
        catch
        {
            
            // *** Close the database connection
            objData.closeConnection();
            return null;

        }

    }
    
    /// <summary>
    /// Function to insert the user agent data into the database
    /// </summary>
    /// <param name="strName">user agent name</param>
    /// <param name="strUserAgent">user agent</param>
    public void InsertUserAgent(string strName, string strUserAgent)
    {
       
        try
        {

            // *** Open the database connection
            string strSuccess = objData.openConnection();

            // *** Check if connection is successfull
            if (strSuccess == "success")
            {

                // *** Declare the hash table and init. the parameters
                Hashtable hsh = new Hashtable();
                hsh.Add("@Name", strName);
                hsh.Add("@Agent", strUserAgent);

                // *** Execute the stored procedure
                objData.executeQuery("ui_UserAgents_create", true, hsh);

            }

            // *** Close the database connection
            objData.closeConnection();

        }
        catch
        {

            // *** Close the database connection
            objData.closeConnection();

        }

    }

    /// <summary>
    /// Function to update the user agent data in the data base
    /// </summary>
    /// <param name="UserAgentId">user agent id</param>
    /// <param name="strName">string name</param>
    /// <param name="UserAgentName">user agent</param>
    public void UpdateUserAgent(int UserAgentId, string strName, string UserAgentName)
    {

        try
        {

            // *** Opent the database connection
            string strSuccess = objData.openConnection();

            // *** Check if connection is sucessfull
            if (strSuccess == "success")
            {

                // *** Declare the hash table an init. the parameters
                Hashtable hsh = new Hashtable();
                hsh.Add("@Id", UserAgentId);
                hsh.Add("@Name", strName);
                hsh.Add("@Agent", UserAgentName);

                // *** Execute the stored procedure
                objData.executeQuery("ui_UserAgents_Update", true, hsh);

            }

            // *** Close the database connection
            objData.closeConnection();

        }
        catch
        {
            
            // *** Close the database connection
            objData.closeConnection();

        }

    }

    /// <summary>
    /// Function to delete the user agent from the database
    /// </summary>
    /// <param name="UserAgentId">user agent id</param>
    public void DeleteUserAgent(int UserAgentId)
    {

        try
        {
        
            // *** Open the database connection
            string strSuccess = objData.openConnection();
            
            // *** Check if connection is successfull
            if (strSuccess == "success")
            {

                // *** Declare the hash table and init. the parameters
                Hashtable hsh = new Hashtable();
                hsh.Add("@Id", UserAgentId);

                // *** Execute the stored procedure
                objData.executeQuery("ui_UserAgents_Delete", true, hsh);

            }

            // *** Close the database connection
            objData.closeConnection();

        }
        catch
        {
            
            // *** Close the database connection
            objData.closeConnection();

        }

    }

}
