using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Collections;

#region "--Class Description--"
///<classname>Error Levels Transaction class</classname>
///<author>Santhosh Kumar</author>
///<date created>16/5/2008</datecreated>
///<datemodified>16/5/2008</datemodified>
///<modified by>Santhosh Kumar</modified by>
///<no. of classes>1</no. of classes>
///<no. of methods></no. of methods>
/// <summary>
/// Class used to insert, update and delete the error levels information from the databse
/// </summary>
/// 
#endregion

public class clsErrorLevels
{

    // *** Declare the local variables
    data_Operations objData;

    // *** Initialize the constructor
    public clsErrorLevels()
	{
		//
		// TODO: Add constructor logic here
		//
        objData = new data_Operations();

	}

    /// <summary>
    /// Function to get error level details from the database
    /// </summary>
    /// <param name="typeId">type id </param>
    /// <returns>dataset</returns>
    public DataSet GetErrorLevelsDetails(int typeId)
    {
        
        try
        {

            // *** Open a database connection
            string strSuccess = objData.openConnection();

            DataSet ds = new DataSet();

            // *** Check if connection is successful
            if (strSuccess == "success")
            {

                // *** Declare the hashtable and initalize the parameters
                Hashtable hsh = new Hashtable();
                hsh.Add("@Id", typeId);

                // *** Execute the stored procedure and retrieve the informatio in the dataset
                ds = objData.getDataSet("ui_ErrorLevels_GetDetails", true, hsh);

            }

            // *** Close the database connection
            objData.closeConnection();
            return ds;

        }
        catch
        {

            // *** Close the database connection
            objData.closeConnection();
            return null;

        }

    }

    /// <summary>
    /// Function to insert error levels into the database
    /// </summary>
    /// <param name="id">error id</param>
    /// <param name="levelName">error level name</param>
    /// <param name="icon">icon path</param>
    /// <returns></returns>
    public int InsertErrorLevels(int id, string levelName, string icon)
    {
       
        try
        {

            int retVal = 0;

            // *** Open the database connection
            string strSuccess = objData.openConnection();

            // *** Check if connection is successful
            if (strSuccess == "success")
            {

                // *** Declare the hashtable and intialize the parameters
                Hashtable hsh = new Hashtable();
                hsh.Add("@id", id);
                hsh.Add("@Name", levelName);
                hsh.Add("@icon", icon);

                // *** Execute the stored procedure
                retVal = objData.executeQuery("ui_ErrorLevels_Create", true, hsh);

            }

            // *** Close the database connection
            objData.closeConnection();
            return retVal;

        }
        catch
        {

            // *** Close the database connection
            objData.closeConnection();
            return 0;

        }

    }

    /// <summary>
    /// Function to update the error level in the database
    /// </summary>
    /// <param name="id">error level id</param>
    /// <param name="levelName">error level name</param>
    /// <param name="icon">error level icon path</param>
    /// <returns></returns>
    public int UpdateErrorLevels(int id, string levelName, string icon)
    {
        
        try
        {

            int retVal = 0;

            // *** Open the database connection
            string strSuccess = objData.openConnection();

            // *** Check if connection is successful
            if (strSuccess == "success")
            {

                // *** Declare the hash table and pass the values as parameters
                Hashtable hsh = new Hashtable();
                hsh.Add("@id", id);
                hsh.Add("@Name", levelName);
                hsh.Add("@icon", icon);

                // *** Execute the stored procedure
                retVal = objData.executeQuery("ui_ErrorLevels_Update", true, hsh);

            }

            // *** Close the database connection
            objData.closeConnection();
            return retVal;

        }
        catch
        {

            // *** Close the database connection
            objData.closeConnection();
            return 0;

        }

    }

    /// <summary>
    /// Function to delete the error level
    /// </summary>
    /// <param name="levelId">error level id</param>
    /// <returns></returns>
    public int DeleteErrorLevel(int levelId)
    {

        try
        {

            int retVal = 0;

            // *** Open the database connection
            string strSuccess = objData.openConnection();

            // *** Check if connection is successful
            if (strSuccess == "success")
            {

                // *** Declare a hash table and pass the parameter
                Hashtable hsh = new Hashtable();
                hsh.Add("@Id", levelId);

                // *** Execute the stored procedure
                retVal = objData.executeQuery("ui_ErrorLevels_Delete", true, hsh);

            }

            // *** Close the database connection
            objData.closeConnection();
            return retVal;

        }
        catch
        {

            // *** Close the database connection
            objData.closeConnection();
            return 0;

        }

    }

}
