using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

#region "--Class Description--"
///<classname>Referrer Transaction class</classname>
///<author>Santhosh Kumar</author>
///<date created>20/5/2008</datecreated>
///<datemodified>20/5/2008</datemodified>
///<modified by>Santhosh Kumar</modified by>
///<no. of classes>1</no. of classes>
///<no. of methods></no. of methods>
/// <summary>
/// Class used to call CRUD methods
/// </summary>
/// 
#endregion

public partial class frmReferrersTrans : System.Web.UI.Page
{

    // *** Declare the local variables
    int id = 0;
    int oprType = 0;

    protected void Page_Load(object sender, EventArgs e)
    {


        if (Session["UserId"] != null && Session["UserType"] != null && Session["UserType"].ToString().Trim().ToLower() == "admin")
        {
          
            // *** Retrieve the query string and assign the parameters
            if (Request.QueryString["Id"] != null)
            {

                id = Convert.ToInt32(Request.QueryString["Id"]);

            }

            if (Request.QueryString["Oper"] != null)
            {

                oprType = Convert.ToInt32(Request.QueryString["Oper"]);

            }

            // *** Check if postback or not
            if (Page.IsPostBack == false)
            {

                // *** Calling function to setControlState method
                setControlState();

                if (oprType != 0)
                {

                    // *** Calling function to SetDetails method
                    SetDetails();

                }

            }

        }
        else
        {

            // *** Execute the javascript
            Page.ClientScript.RegisterStartupScript(this.GetType(), "relo", "window.opener.location.href=window.opener.location;window.close();", true);

        }
    
    }

    /// <summary>
    /// Function to set Control State 
    /// </summary>
    private void setControlState()
    {

        // *** Check if operation to be performed is create
        if (oprType == 0)
        {

            btnCreate.Text = "Create";
            lblTitle.Text = "Referrers - Create";
       
        }
        else if (oprType == 1)// *** Check if operation to be performed is update
        {

            btnCreate.Text = "Update";
            lblTitle.Text = "Referrers - Modify";
        
        }
        else// *** Check if operation to be performed is delete
        {

            btnCreate.Text = "Delete";
            lblTitle.Text = "Referrers - Delete";
            txtName.Enabled = false;
            txtReferrer.Enabled = false;
            btnCreate.Attributes.Add("onclick", "return confirmation();");
       
        }
  
    }

    /// <summary>
    /// Function to Set Details information
    /// </summary>
    private void SetDetails()
    {

        // *** Declare the objects
        clsReferrer obj = new clsReferrer();
        DataSet dsDetails = new DataSet();

        // *** Calling function to GetReferrerDetails method
        dsDetails = obj.GetReferrerDetails(id);

        // *** Initialize the controls
        if (dsDetails != null && dsDetails.Tables.Count > 0 && dsDetails.Tables[0].Rows.Count > 0)
        {

            txtName.Text = dsDetails.Tables[0].Rows[0][1].ToString();
            txtReferrer.Text = dsDetails.Tables[0].Rows[0][2].ToString();
        
        }
        
        // *** Dispose the objects
        dsDetails.Dispose();
        obj = null;

    }

    /// <summary>
    /// Function on button press
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnCreate_Click(object sender, EventArgs e)
    {

        // *** Check if operation to be performed is create
        if (oprType == 0)
        {

            // *** Calling function to Create method
            Create();

        }
        else if (oprType == 1)// *** Check if operation to be performed is update 
        {

            // *** Calling function to Update method
            Update();

        }
        else// *** Check if operation to be performed is delete
        {

            // *** Calling function to Delete method
            Delete();

        }

        // *** Execute the javascript here
        Page.ClientScript.RegisterStartupScript(this.GetType(), "relo", "window.opener.location.href=window.opener.location;window.close();", true);
    
    }

    /// <summary>
    /// Function to create a new record
    /// </summary>
    private void Create()
    {

        // *** Create an object of type clsReferrer
        clsReferrer obj = new clsReferrer();

        // *** Calling function to InsertReferrer
        obj.InsertReferrer(txtName.Text, txtReferrer.Text);
        obj = null;

    }

    private void Update()
    {

        // *** Create an object of type clsReferrer
        clsReferrer obj = new clsReferrer();

        // *** Calling function to UpdateReferrer method
        obj.UpdateReferrer(id, txtName.Text, txtReferrer.Text);
        obj = null;

    }

    private void Delete()
    {

        // *** Create an object of type clsReferrer
        clsReferrer obj = new clsReferrer();

        // *** Calling function to DeleteReferrer method
        obj.DeleteReferrer(id);
        obj = null;

    }

}
