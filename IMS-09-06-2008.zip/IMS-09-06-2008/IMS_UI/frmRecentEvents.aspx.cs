using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

#region "--Class Description--"
///<classname>Recent Events class</classname>
///<author>Santhosh Kumar</author>
///<date created>28/5/2008</datecreated>
///<datemodified>28/5/2008</datemodified>
///<modified by>Santhosh Kumar</modified by>
///<no. of classes>1</no. of classes>
///<no. of methods></no. of methods>
/// <summary>
/// Class used to retrieve recent events
/// </summary>
/// 
#endregion

public partial class frmRecentEvents : System.Web.UI.Page
{

    protected void Page_Load(object sender, EventArgs e)
    {

        // *** Check if Session exists
        if (Session["UserId"] != null && Session["UserType"] != null)
        {

            // *** Check if page post back
            if (Page.IsPostBack == false)
            {

                // *** Calling function to fill the Events list
                FillEventsList();

            }

        }
        else
        {

            // *** Redirects the page to login page
            Response.Redirect("frmLogin.aspx");

        }

    }

    /// <summary>
    /// Function to fill the events list
    /// </summary>
    private void FillEventsList()
    {

        // *** Declare the local variables
        data_Operations objData = new data_Operations();

        // *** Open a database connection
        string strSucess = objData.openConnection();

        // *** Check if connection is successful
        if (strSucess == "success")
        {

            // *** Retrieve the session user type and formula the parameters to be passed accordingly
            DataSet ds = new DataSet();
            string strUserType = Session["UserType"].ToString();
            if (strUserType.Trim().ToLower() == "user")
            {

                Hashtable hsh = new Hashtable();
                hsh.Add("@UserId", Session["UserId"].ToString());
                
                // *** Execute the stored procedure
                ds = objData.getDataSet("ui_Reports_RecentEvents", true, hsh);
            
            }
            else
            {

                // *** Execute the stored procedure
                ds = objData.getDataSet("ui_Reports_RecentEvents", true);
            
            }

            // *** Assign the dataset to the datagrid
            grdDetails.DataSource = ds;
            grdDetails.DataBind();

        }

        // *** Close the database connection
        objData.closeConnection();

    }

    /// <summary>
    /// Function to bind the row
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void grdDetails_RowDataBound(object sender, GridViewRowEventArgs e)
    {

        
        // *** Check rowtype
        if (e.Row.RowType == DataControlRowType.DataRow)
        {

            // *** Place the image into the cell
            Image img = new Image();
            img = (Image)e.Row.Cells[5].Controls[0];
            img.ImageUrl = "User_Icons/EventType/" + img.ImageUrl;

        }

    }

}
