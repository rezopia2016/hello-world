using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

#region "--Class Description--"
///<classname>Response Times class</classname>
///<author>Santhosh Kumar</author>
///<date created>20/5/2008</datecreated>
///<datemodified>20/5/2008</datemodified>
///<modified by>Santhosh Kumar</modified by>
///<no. of classes>1</no. of classes>
///<no. of methods></no. of methods>
/// <summary>
/// Class used to retrieve response times
/// </summary>
/// 
#endregion


public partial class frmRecentEvents : System.Web.UI.Page
{

    protected void Page_Load(object sender, EventArgs e)
    {

        // *** Check if Session exists
        if (Session["UserId"] != null && Session["UserType"] != null)
        {

            // *** Retrieve the Query String and assign the label based on the query string
            if (Request.QueryString["type"] != "" || Request.QueryString["type"] != null)
            {

                if (Request.QueryString["type"].ToString() == "error")
                {

                    lbl_Header.Text = "Response Time - Error Level";

                }
                else if (Request.QueryString["type"].ToString() == "group")
                {

                    lbl_Header.Text = "Response Time - Group";

                }
                else if (Request.QueryString["type"].ToString() == "queue")
                {

                    lbl_Header.Text = "Response Time - Queue";

                }
          
            }

            // *** Check if post back and assign accordingly
            if (Page.IsPostBack == false)
            {

                FillResponseList();  
            
            }
        
        }
        else
        {
        
            // *** Redirect to login page if session does not exist
            Response.Redirect("frmLogin.aspx");
        
        }
    
    }

    /// <summary>
    /// Function to fill response list
    /// </summary>
    private void FillResponseList()
    {

        // *** Retrive the value from the Query String and declare the local variables
        string strType = Request.QueryString["type"];
        data_Operations objData = new data_Operations();

        // *** Open the database connection
        string strSucess = objData.openConnection();

        // *** Check if connection is successfull
        if (strSucess == "success")
        {

            // *** Declare the hash table nd pass parameters
            Hashtable hsh = new Hashtable();
            hsh.Add("@groupBy", strType);

            // *** Retrieve the User type and assign parameters accordingly
            string strUserType = Session["UserType"].ToString();
            if (strUserType.Trim().ToLower() == "user")
            {

                hsh.Add("@UserId", Session["UserId"].ToString());
            
            }

            // *** Execute the stored procedure
            DataSet ds = objData.getDataSet("ui_GetAvgResponseTimes", true, hsh);

            // *** Initialize the datagrid with the dataset
            grdDetails.DataSource = ds;
            grdDetails.DataBind();

        }

        // *** Close the data connection
        objData.closeConnection();
    
    }

    
}
