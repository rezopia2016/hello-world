using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;


#region "--Class Description--"
///<classname>Error Levels Transaction class</classname>
///<author>Santhosh Kumar</author>
///<date created>16/5/2008</datecreated>
///<datemodified>16/5/2008</datemodified>
///<modified by>Santhosh Kumar</modified by>
///<no. of classes>1</no. of classes>
///<no. of methods></no. of methods>
/// <summary>
/// Class used perform error level transactions
/// </summary>
/// 
#endregion

public partial class frmErrorLevelsTans : System.Web.UI.Page
{
    
    // *** Declare the global variables
    int id = 0;
    int oprType = 0;


    protected void Page_Load(object sender, EventArgs e)
    {

        if (Session["UserId"] != null && Session["UserType"] != null && Session["UserType"].ToString().Trim().ToLower() == "admin")
        {

            // *** Retrive the query string from the parent page
            if (Request.QueryString["Id"] != null)
            {

                id = Convert.ToInt32(Request.QueryString["Id"]);

            }

            if (Request.QueryString["Oper"] != null)
            {

                oprType = Convert.ToInt32(Request.QueryString["Oper"]);

            }

            if (Page.IsPostBack == false)
            {

                // *** Calling function to setControlState function
                setControlState();

                if (oprType != 0)
                {

                    // *** Calling function to SetDetails function
                    SetDetails();

                }

            }
        }
        else
        {

            // **** Execute the javascript to close the pop up window
            Page.ClientScript.RegisterStartupScript(this.GetType(), "relo", "window.opener.location.href=window.opener.location;window.close();", true);
        
        }
    
    }

    /// <summary>
    /// Function to set the control state
    /// </summary>
    private void setControlState()
    {

        // *** Check if oprType = 0
        if (oprType == 0)
        {

            // *** Init. the controls
            btnCreate.Text = "Create";
            lblTitle.Text = "Error Levels - Create";
            imgIcon.Visible = false;
        
        }
        else if (oprType == 1)// *** Check if oprType = 1
        {

            // *** Init. the controls
            btnCreate.Text = "Update";
            lblTitle.Text = "Error Levels - Modify";
            txtId.Enabled = false;
        
        }
        else// *** Check if oprType = 2
        {

            // *** Init. the controls
            btnCreate.Text = "Delete";
            lblTitle.Text = "Error Levels - Delete";
            txtId.Enabled = false;
            txtDesc.Enabled = false;
            fupIcon.Enabled = false;
            btnCreate.Attributes.Add("onclick", "return confirmation();");

        }

    }

    /// <summary>
    /// Function to set the details of the controls
    /// </summary>
    private void SetDetails()
    {
        
        // *** Declare the local variables
        clsErrorLevels obj = new clsErrorLevels();
        DataSet dsDetails = new DataSet();

        // *** Execute the stored procedure
        dsDetails = obj.GetErrorLevelsDetails(id);

        if (dsDetails != null && dsDetails.Tables.Count > 0 && dsDetails.Tables[0].Rows.Count > 0)
        {

            // *** Init. the values for the controls
            txtDesc.Text = dsDetails.Tables[0].Rows[0][1].ToString();
            txtId.Text = dsDetails.Tables[0].Rows[0][0].ToString();

            if (dsDetails.Tables[0].Rows[0][2].ToString() != "")
            {

                imgIcon.ImageUrl = "User_Icons/ErrorLevels/" + dsDetails.Tables[0].Rows[0][2].ToString();
           
            }
       
        }

        // *** Dispose the dataset and the object created
        dsDetails.Dispose();
        obj = null;

    }

    /// <summary>
    /// Function performed on button click
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnCreate_Click(object sender, EventArgs e)
    {
        
        // *** Check if oprType = 0
        if (oprType == 0)
        {
            
            // *** Calling function to create function
            Create();
        
        }
        else if (oprType == 1)// *** Check if oprType = 1
        {

            // *** Calling function to update function
            Update();
       
        }
        else// *** Check if oprType = 2
        {

            // *** Calling function to delete function
            Delete();
        
        }

    }

    /// <summary>
    /// Function to create a new error level entry in the databse
    /// </summary>
    private void Create()
    {

        // *** Check if file uplad control has any value
        if (fupIcon.PostedFile != null && fupIcon.FileName != "")
        {
           // *** Convert the extension to lowercase
            if (System.IO.Path.GetExtension(fupIcon.FileName).ToLower() == ".jpeg" || System.IO.Path.GetExtension(fupIcon.FileName).ToLower() == ".jpg" || System.IO.Path.GetExtension(fupIcon.FileName).ToLower() == ".png" || System.IO.Path.GetExtension(fupIcon.FileName).ToLower() == ".gif" || System.IO.Path.GetExtension(fupIcon.FileName).ToLower() == ".ico")
            {

                // *** Declare the local object
                clsErrorLevels obj = new clsErrorLevels();

                // *** Define a string path
                string strPath = System.IO.Path.GetExtension(fupIcon.FileName);

                // *** Initialize the sting path
                strPath = "Error" + txtId.Text + strPath;

                // *** Execute the stored procedure
                int retVal = obj.InsertErrorLevels(Convert.ToInt32(txtId.Text), txtDesc.Text, strPath);
                obj = null;
                
                // *** Check if inserted
                if (retVal > 0)
                {

                    // *** Save the image in the specified path
                    fupIcon.PostedFile.SaveAs(Server.MapPath("User_Icons/ErrorLevels/" + strPath));

                }

                // *** Execute the javascript function
                Page.ClientScript.RegisterStartupScript(this.GetType(), "relo", "window.opener.location.href=window.opener.location;window.close();", true);
           
            }
            else
            {

                // *** Execute the javascript function
                Page.ClientScript.RegisterStartupScript(this.GetType(), "ale_mess", "alert('Please select Png, Gif, Jpeg or Ico images only');", true);
           
            }

        }
        else
        {

            // *** Execute the javascript function
            Page.ClientScript.RegisterStartupScript(this.GetType(), "ale", "alert('Please select images');", true);
       
        }

    }

    /// <summary>
    /// Function to update the error level details in the atabase
    /// </summary>
    private void Update()
    {
        
        // *** Create the clsErrorLevels object
        clsErrorLevels obj = new clsErrorLevels();

        // *** Check if file upload control contains value or not
        if (fupIcon.PostedFile != null && fupIcon.PostedFile.FileName != "")
        {

            // *** Check the file uploader extension
            if (System.IO.Path.GetExtension(fupIcon.FileName).ToLower() == ".jpeg" || System.IO.Path.GetExtension(fupIcon.FileName).ToLower() == ".jpg" || System.IO.Path.GetExtension(fupIcon.FileName).ToLower() == ".png" || System.IO.Path.GetExtension(fupIcon.FileName).ToLower() == ".gif" || System.IO.Path.GetExtension(fupIcon.FileName).ToLower() == ".ico")
            {

                // *** Retrirvr the extension
                string strPath = System.IO.Path.GetExtension(fupIcon.FileName);
               
                // *** Formulate the text to be stored
                strPath = "Error" + txtId.Text + strPath;

                // *** Execute the stored procedure
                int retVal =  obj.UpdateErrorLevels(Convert.ToInt32(txtId.Text), txtDesc.Text, strPath);
                obj = null;

                // *** Check the return value
                if (retVal > 0)
                {

                    // *** Save the image with the strpath name
                    fupIcon.PostedFile.SaveAs(Server.MapPath("User_Icons/ErrorLevels/" + strPath));
                
                }
                
                // *** Execute the javascript
                Page.ClientScript.RegisterStartupScript(this.GetType(), "relo", "window.opener.location.href=window.opener.location;window.close();", true);
            
            }
            else
            {
            
                // *** Execute the javascript
                Page.ClientScript.RegisterStartupScript(this.GetType(), "ale_mess", "alert('Please select Png, Gif, Jpeg or Ico images only');", true);
            
            }
        
        }
        else
        {
        
            // *** Retrieve the image path
            string strPath = System.IO.Path.GetExtension(fupIcon.FileName);
            strPath = System.IO.Path.GetFileName(imgIcon.ImageUrl);

            // *** Calling function to update error levels
            obj.UpdateErrorLevels(Convert.ToInt32(txtId.Text), txtDesc.Text, strPath);
            obj = null;

            // *** Execute the javascript
            Page.ClientScript.RegisterStartupScript(this.GetType(), "relo", "window.opener.location.href=window.opener.location;window.close();", true);
        
        }
        
        // *** Dispose the objects
        obj = null;

    }

    /// <summary>
    /// Function to delete the error level from the database
    /// </summary>
    private void Delete()
    {

        // *** Declare a local object
        clsErrorLevels obj = new clsErrorLevels();

        // *** Calling function to delete error level
        int retVal = obj.DeleteErrorLevel(id);
        
        // *** Check if record is deleted
        if (retVal > 0)
        {

            // *** Check the image url
            if (imgIcon.ImageUrl != "")
            {

                // *** Delete the image from the folder
                System.IO.File.Delete(Server.MapPath(imgIcon.ImageUrl));
            
            }
        
        }
        
        // *** Dispose the objects    
        obj = null;

        // *** Execute the javascript
        Page.ClientScript.RegisterStartupScript(this.GetType(), "relo", "window.opener.location.href=window.opener.location;window.close();", true);
    
    }

}
