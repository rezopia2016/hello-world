using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

#region "--Class Description--"
///<classname>Recent Samples class</classname>
///<author>Santhosh Kumar</author>
///<date created>29/5/2008</datecreated>
///<datemodified>29/5/2008</datemodified>
///<modified by>Santhosh Kumar</modified by>
///<no. of classes>1</no. of classes>
///<no. of methods></no. of methods>
/// <summary>
/// Class used to retrieve recent samples
/// </summary>
/// 
#endregion


public partial class frmSamples : System.Web.UI.Page
{

    protected void Page_Load(object sender, EventArgs e)
    {
       
        // *** Check if Session exists
        if (Session["UserId"] != null && Session["UserType"] != null)
        {

            // *** Check if post back
            if (Page.IsPostBack == false)
            {

                // *** Initialize the javacript to get calender control
                string strVal1 = "window.open('frmDatePicker.aspx?conId=" + txtFrom.ClientID + "','','width=230px,height=240px,status=no,resizable=no,scrollbars=no,menubar=no,toolbar=no;location=no;');return false;";
                string strVal2 = "window.open('frmDatePicker.aspx?conId=" + txtTo.ClientID + "','','width=230px,height=240px,status=no,resizable=no,scrollbars=no,menubar=no,toolbar=no;location=no;'); return false;";

                btnFrom.Attributes.Add("onclick", strVal1);
                btnTo.Attributes.Add("onclick", strVal2);

                // *** Calling function to fill drop downs
                FillDropDowns();

                // *** Calling function to fill the datagrid
                FillSampleList();

            }

        }
        else
        {

            // *** Redirect to login page
            Response.Redirect("frmLogin.aspx");

        }
    }

    /// <summary>
    /// Function to fill the sample list
    /// </summary>
    private void FillSampleList()
    {

        // *** Declare the local variables
        data_Operations objData = new data_Operations();

        // *** Open the database connection
        string strSucess = objData.openConnection();

        // *** Check if connection is successfull
        if (strSucess == "success")
        {

            // *** Declare the hash table and initialize the parameters
            Hashtable hsh = new Hashtable();

            if (ddlUrl.SelectedIndex > 0)
            {

                hsh.Add("@url", ddlUrl.Text);
           
            }

            if (txtFrom.Text != "")
            {

                hsh.Add("@Sam_From", txtFrom.Text);
            
            }

            if (txtTo.Text != "")
            {

                hsh.Add("@Sam_To", txtTo.Text);
            
            }

            if (ddlError.SelectedIndex > 0)
            {

                hsh.Add("@errorLevel", ddlError.Text);
           
            }

            string strUserType = Session["UserType"].ToString();
           
            if (strUserType.Trim().ToLower() == "user")
            {

                hsh.Add("@UserId", Session["UserId"].ToString());
            
            }
           
            // *** Execute the stored procedure
            DataSet ds = objData.getDataSet("Ui_Reports_RecentSamples", true, hsh);

            // *** Initialize the datagrid
            grdDetails.DataSource = ds;
            grdDetails.DataBind();

        }

        // *** Close the data base connection
        objData.closeConnection();

    }

    protected void grdDetails_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        
    }

    /// <summary>
    /// Fun tion to fill drop dowss
    /// </summary>
    private void FillDropDowns()
    {

        // *** Calling function to fill Url drop down
        FillDrop(ddlUrl, "ui_Url_List", "id", "url");

        // *** Calling function to fill the error drop down
        FillDrop(ddlError, "ui_ErrorLevels_List", "id", "errorLevel");

    }

    /// <summary>
    /// Function to fill drop down
    /// </summary>
    /// <param name="ddl">drop down list name</param>
    /// <param name="spName">stored procedure name</param>
    /// <param name="strData">data value field</param>
    /// <param name="strText">data text field</param>
    private void FillDrop(DropDownList ddl, string spName, string strData, string strText)
    {

        // *** Declare the local variable 
        data_Operations objData = new data_Operations();

        // *** Open the database connection
        string strSucess = objData.openConnection();

        // *** Check if connection is successfull
        if (strSucess == "success")
        {

            // *** Execute the stored procedure
            DataSet ds = objData.getDataSet(spName, true);
            ddl.DataSource = ds;
            ddl.DataTextField = strText;
            ddl.DataValueField = strData;
            
            // *** Bind the drop down list
            ddl.DataBind();

        }

        // *** Close the data connection
        objData.closeConnection();

    }

    protected void btnCreate_Click(object sender, EventArgs e)
    {

    }

    /// <summary>
    /// Function to filter the datagrid
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnSearch_Click(object sender, EventArgs e)
    {

        // *** Calling function to fill the datagrid
        FillSampleList();  

    }

}
