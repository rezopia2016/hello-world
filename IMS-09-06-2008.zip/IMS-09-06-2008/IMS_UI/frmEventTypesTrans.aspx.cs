using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

#region "--Class Description--"
///<classname>Event Types Transaction class</classname>
///<author>Santhosh Kumar</author>
///<date created>17/5/2008</datecreated>
///<datemodified>17/5/2008</datemodified>
///<modified by>Santhosh Kumar</modified by>
///<no. of classes>1</no. of classes>
///<no. of methods></no. of methods>
/// <summary>
/// Class used to do CRUD operation in event types data
/// </summary>
/// 
#endregion

public partial class frmEventTypesTrans : System.Web.UI.Page
{

    // *** Declare the local variables
    int id = 0;
    int oprType = 0;

    protected void Page_Load(object sender, EventArgs e)
    {


        if (Session["UserId"] != null && Session["UserType"] != null && Session["UserType"].ToString().Trim().ToLower() == "admin")
        {

            // *** Retrieve the query string and identify the type of operation
            if (Request.QueryString["Id"] != null)
            {

                // *** Initialize the id
                id = Convert.ToInt32(Request.QueryString["Id"]);

            }

            if (Request.QueryString["Oper"] != null)
            {

                // *** Initialize the oprType variable
                oprType = Convert.ToInt32(Request.QueryString["Oper"]);

            }

            // *** Check if post back or not
            if (Page.IsPostBack == false)
            {

                // *** Calling function to setControlState function
                setControlState();

                if (oprType != 0)
                {

                    // *** Calling function to SetDetails function
                    SetDetails();

                }

            }

        }
        else
        {

            // *** Execute the javascript
            Page.ClientScript.RegisterStartupScript(this.GetType(), "relo", "window.opener.location.href=window.opener.location;window.close();", true);

        }
   
    }

    /// <summary>
    /// Function to set control state
    /// </summary>
    private void setControlState()
    {
        
        // *** Check if operation to be performed is create
        if (oprType == 0)
        {
           
            btnCreate.Text = "Create";
            lblTitle.Text = "Event Types - Create";
            imgIcon.Visible = false;
     
        }
        else if (oprType == 1)// *** Check if operation to be performed is update
        {
           
            btnCreate.Text = "Update";
            lblTitle.Text = "Event Types - Modify";
            txtId.Enabled = false;
        
        }
        else
        {// *** Check if operation to be performed is delete
          
            btnCreate.Text = "Delete";
            lblTitle.Text = "Event Types - Delete";
            txtId.Enabled = false;
            txtDesc.Enabled = false;
            fupIcon.Enabled = false;

            // *** Execute the javascript
            btnCreate.Attributes.Add("onclick", "return confirmation();");
       
        }
  
    }

    /// <summary>
    /// Function to set details on loading the page
    /// </summary>
    private void SetDetails()
    {

        // *** Declare the local variables and objects
        clsEventTypes obj = new clsEventTypes();
        DataSet dsDetails = new DataSet();

        // *** Calling code to GetEventTypeDetails method 
        dsDetails = obj.GetEventTypesDetails(id);

        // *** Check if ataset is empty or not
        if (dsDetails != null && dsDetails.Tables.Count > 0 && dsDetails.Tables[0].Rows.Count > 0)
        {

            // *** Initialize the txt boxes
            txtDesc.Text = dsDetails.Tables[0].Rows[0][1].ToString();
            txtId.Text = dsDetails.Tables[0].Rows[0][0].ToString();
            
            // *** Initialize the image control
            if (dsDetails.Tables[0].Rows[0][2].ToString() != "")
            {
            
                imgIcon.ImageUrl = "User_Icons/EventType/" + dsDetails.Tables[0].Rows[0][2].ToString();
           
            }

        }

        // *** Dispose the objects
        dsDetails.Dispose();
        obj = null;

    }

    /// <summary>
    /// Function executed on button press
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnCreate_Click(object sender, EventArgs e)
    {

        // ***  Check if operation to be performed is create
        if (oprType == 0)
        {

            // *** Calling function to do create operation
            Create();
        
        }
        else if (oprType == 1) // ***  Check if operation to be performed is update
        {

            // *** Calling function to do update operation
            Update();
       
        }
        else // ***  Check if operation to be performed is delte
        {
            
            // *** Calling function to do delete operation
            Delete();
        
        }

    }

    /// <summary>
    /// Function to do create operation
    /// </summary>
    private void Create()
    {

        // *** Check if file uploader contains some value
        if (fupIcon.PostedFile != null && fupIcon.FileName != "")
        {

            // *** Check the extension
            if (System.IO.Path.GetExtension(fupIcon.FileName).ToLower() == ".jpeg" || System.IO.Path.GetExtension(fupIcon.FileName).ToLower() == ".jpg" || System.IO.Path.GetExtension(fupIcon.FileName).ToLower() == ".png" || System.IO.Path.GetExtension(fupIcon.FileName).ToLower() == ".gif" || System.IO.Path.GetExtension(fupIcon.FileName).ToLower() == ".ico")
            {

                // *** Create an object of type clsEventTypes
                clsEventTypes obj = new clsEventTypes();

                // *** Extract the extension and create a new path
                string strPath = System.IO.Path.GetExtension(fupIcon.FileName);
                strPath = "event" + txtId.Text + strPath;

                // *** Calling function to insert event type details in the database
                int retVal = obj.InsertEventType(Convert.ToInt32(txtId.Text), txtDesc.Text, strPath);
                obj = null;

                // *** Check if record is inserted successfully
                if (retVal > 0)
                {

                    // *** Save the image in the folder specified
                    fupIcon.PostedFile.SaveAs(Server.MapPath("User_Icons/EventType/" + strPath));

                }

                // *** Execute the javascript
                Page.ClientScript.RegisterStartupScript(this.GetType(), "relo", "window.opener.location.href=window.opener.location;window.close();", true);

            }
            else
            {

                // *** Execute the javascript
                Page.ClientScript.RegisterStartupScript(this.GetType(), "ale_mess", "alert('Please select Png, Gif, Jpeg or Ico images only');", true);

            }

        }
        else
        {

            // *** Execute the javascript
            Page.ClientScript.RegisterStartupScript(this.GetType(), "ale", "alert('Please select images');", true);

        }

    }

    /// <summary>
    /// Function to do update operation
    /// </summary>
    private void Update()
    {

        // *** Create an object of type clsEventTypes
        clsEventTypes obj = new clsEventTypes();

        // *** Check the file upload control 
        if (fupIcon.PostedFile != null && fupIcon.PostedFile.FileName != "")// *** When image is replaced by a new one
        {

            // *** Check the extension
            if (System.IO.Path.GetExtension(fupIcon.FileName).ToLower() == ".jpeg" || System.IO.Path.GetExtension(fupIcon.FileName).ToLower() == ".jpg" || System.IO.Path.GetExtension(fupIcon.FileName).ToLower() == ".png" || System.IO.Path.GetExtension(fupIcon.FileName).ToLower() == ".gif" || System.IO.Path.GetExtension(fupIcon.FileName).ToLower() == ".ico")
            {

                // *** Retrieve the extension and formulate the string
                string strPath = System.IO.Path.GetExtension(fupIcon.FileName);
                strPath = "event" + txtId.Text + strPath;

                // *** Calling function to UpdateEventType method
                int retVal =  obj.UpdateEventType(Convert.ToInt32(txtId.Text), txtDesc.Text, strPath);
                obj = null;

                // *** Check if record is updated
                if (retVal > 0)
                {

                    // *** Save the image in the path specified
                    fupIcon.PostedFile.SaveAs(Server.MapPath("User_Icons/EventType/" + strPath));

                }

                // *** Execute the javascript
                Page.ClientScript.RegisterStartupScript(this.GetType(), "relo", "window.opener.location.href=window.opener.location;window.close();", true);
            
            }
            else
            {
            
                // *** Execute the javascript
                Page.ClientScript.RegisterStartupScript(this.GetType(), "ale_mess", "alert('Please select Png, Gif, Jpeg or Ico images only');", true);
            
            }
        
        }
        else // *** When old image is left as it is
        {
        
            // *** Retrieve the filename from the image url
            string strPath = System.IO.Path.GetExtension(fupIcon.FileName);
            strPath = System.IO.Path.GetFileName(imgIcon.ImageUrl);

            // *** Execute the UpdateEventType method
            obj.UpdateEventType(Convert.ToInt32(txtId.Text), txtDesc.Text, strPath);
            obj = null;

            // *** Execute the javascript
            Page.ClientScript.RegisterStartupScript(this.GetType(), "relo", "window.opener.location.href=window.opener.location;window.close();", true);
        }

        obj = null;

    }

    /// <summary>
    /// Function to delete the event type
    /// </summary>
    private void Delete()
    {
        
        // *** Create an object
        clsEventTypes obj = new clsEventTypes();

        // *** Execute the delte operation
        int retVal = obj.DeleteEventType(id);

        // *** Check if record is elted
        if (retVal > 0)
        {

            // *** Retrieve the image url path
            if (imgIcon.ImageUrl != "")
            {

                // *** Delete the image from the folder
                System.IO.File.Delete(Server.MapPath(imgIcon.ImageUrl));
            
            }
        
        }
        
        obj = null;
        
        // *** Execute the javascript
        Page.ClientScript.RegisterStartupScript(this.GetType(), "relo", "window.opener.location.href=window.opener.location;window.close();", true);
    
    }

}
