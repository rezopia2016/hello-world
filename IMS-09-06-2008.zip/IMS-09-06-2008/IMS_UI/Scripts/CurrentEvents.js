﻿// JScript File

function setSelectedRow(con, RowNo)
{
    var grd = document.getElementById(con);
    for(var count = 1;count < grd.rows.length;count++)
    {
        if(parseInt(count) == (parseInt(RowNo+1)))
        {
            grd.rows[count].className = "GridSelectedRow";
        }
        else
        {
            grd.rows[count].className = "GridRowStyle";
        }
    }
    
    document.getElementById('ctl00_MainContent_btnDelete').disabled = false;
    document.getElementById('td_Level').innerHTML = grd.rows[RowNo + 1].cells[0].innerHTML;
    document.getElementById('td_Id').innerHTML = grd.rows[RowNo + 1].cells[1].innerHTML;
    document.getElementById('td_URL').innerHTML = grd.rows[RowNo + 1].cells[2].innerHTML;
    document.getElementById('td_Queue').innerHTML = grd.rows[RowNo + 1].cells[3].innerHTML;
    document.getElementById('td_Group').innerHTML = grd.rows[RowNo + 1].cells[4].innerHTML;
    document.getElementById('td_LastError').innerHTML = grd.rows[RowNo + 1].cells[5].innerHTML;
    document.getElementById('td_LastSample').innerHTML = grd.rows[RowNo + 1].cells[6].innerHTML;
       
}

function ShowTrans()
{

    var answer = confirm("Are you sure you want to handle the event?")
	if (answer)
	{
	
		return true;
		
	}
	return false;

}
