﻿function confirmation()
{

    var answer = confirm("Are you sure you want to delete ?")
	if (answer)
	{
	
		return true;
		
	}
	return false;

}


var selRow;

function ShowMouseOver(con)
{
    if(selRow != null)
    {
        if(con.rowIndex != selRow)
        {
            con.className = 'GridRowStyle_hover';
        }
        else
        {
            con.className = 'GridSelectedRow_hover';
        }
    }
    else
    {
        con.className = 'GridRowStyle_hover';
    }
}

function ShowMouseOut(con)
{
    if(selRow != null)
    {
         if(con.rowIndex != selRow)
         {
            con.className = 'GridRowStyle';
         }
         else
         {
            con.className = 'GridSelectedRow';
         }
     }
     else
     {
        con.className = 'GridRowStyle';
     }

}

function ShowHelp()
{
    var strUrl = "";
    
    strUrl = "Help.aspx" ;
   
    window.open(strUrl,"","width=680px,height=355px,status=no,resizable=no,scrollbars=yes,menubar=0,toolbar=no");    
    return false;
    
}

function ShowChangePassword()
{
    var strUrl = "";
    
    strUrl = "frmChangePassword.aspx" ;
   
    window.open(strUrl,"","width=680px,height=230px,status=no,resizable=no,scrollbars=no,menubar=0,toolbar=no");    
    return false;
    
}

function ShowForgot()
{
    var strUrl = "";
  
    strUrl = "ForgotPassword.aspx";
    window.open(strUrl,"","width=300px,height=180px,status=no,resizable=no,scrollbars=no,menubar=0,toolbar=no");    
    return false;
    
}
// JScript File

