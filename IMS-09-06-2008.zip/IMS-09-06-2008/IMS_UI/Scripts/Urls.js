﻿// JScript File

function ShowTrans(strType)
{
    var strUrl = "";
    if(strType == "0")
    {
         strUrl = "frmUrlsTrans.aspx?Oper=" + strType;
    }
    else
    {
        if(document.getElementById('ctl00_MainContent_hid_Val').value != "")
        {
            strUrl = "frmUrlsTrans.aspx?Oper=" + strType + "&Id=" + document.getElementById('ctl00_MainContent_hid_Val').value;
        }
        else
        {
            alert("Select Any Records");
            return false;
        }
    }
    window.open(strUrl,"","width=650px,height=280px,status=no,resizable=no,scrollbars=no,menubar=0,toolbar=no");    
    return false;
}

function setSelectedRow(con, RowNo)
{
    var grd = document.getElementById(con);
    for(var count = 1;count < grd.rows.length;count++)
    {
        if(parseInt(count) == (parseInt(RowNo+1)))
        {
            grd.rows[count].className = "GridSelectedRow";
        }
        else
        {
            grd.rows[count].className = "GridRowStyle";
        }
    }
    
    document.getElementById('td_URL').innerHTML = grd.rows[RowNo + 1].cells[1].innerHTML;
    document.getElementById('td_Group').innerHTML = grd.rows[RowNo + 1].cells[2].innerHTML;
    document.getElementById('td_Queue').innerHTML = grd.rows[RowNo + 1].cells[3].innerHTML;
    document.getElementById('td_MinError').innerHTML = grd.rows[RowNo + 1].cells[4].innerHTML;
    document.getElementById('td_LastRun').innerHTML = grd.rows[RowNo + 1].cells[5].innerHTML;
    document.getElementById('td_Text').innerHTML = grd.rows[RowNo + 1].cells[6].innerHTML;
    document.getElementById('td_LastError').innerHTML = grd.rows[RowNo + 1].cells[7].innerHTML;    
    
}