using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;


#region "--Class Description--"
///<classname>Event Handler class</classname>
///<author>Santhosh Kumar</author>
///<date created>27/5/2008</datecreated>
///<datemodified>27/5/2008</datemodified>
///<modified by>Santhosh Kumar</modified by>
///<no. of classes>1</no. of classes>
///<no. of methods></no. of methods>
/// <summary>
/// Class used handle Events
/// </summary>
/// 
#endregion

public partial class frmCurrentEvents : System.Web.UI.Page
{

    protected void Page_Load(object sender, EventArgs e)
    {

        // *** Check whether the user is the administrator or a normal user.
        if (Convert.ToBoolean(Session["IsAdmin"].ToString()) == false)
        {

            btnDelete.Visible = false;
         
        }

        // *** Calling function to FillAlertLevelList method
        FillAlertLevelList();
        btnDelete.Enabled = false;

    }

    /// <summary>
    /// Fucntion to retrieve the current alert level details and display in the dataset
    /// </summary>
    private void FillAlertLevelList()
    {

        data_Operations objData = new data_Operations();

        // *** Open the database connection
        string strSucess = objData.openConnection();

        // *** Check if connection is successfull
        if (strSucess == "success")
        {

            // *** Execute the stored procedure and retrive the information in the dataset
            DataSet ds = objData.getDataSet("ui_GetCurrentAlert", true);

            // *** Init. the grid with the dataset
            grdDetails.DataSource = ds;
            grdDetails.DataBind();

        }

        // *** Close the database connection
        objData.closeConnection();

    }

    /// <summary>
    /// Function to bind the information into the grid
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void grdDetails_RowDataBound(object sender, GridViewRowEventArgs e)
    {
    
        if (e.Row.RowType == DataControlRowType.DataRow)
        {

            // *** Create an image control and make the cell2 of the the datagrid an image column and init. the image url
            Image img = new Image();
            img = (Image)e.Row.Cells[0].Controls[0];
            img.ImageUrl = "User_Icons/ErrorLevels/" + img.ImageUrl;

            Image img1 = new Image();
            img1 = (Image)e.Row.Cells[5].Controls[0];
            img1.ImageUrl = "User_Icons/ErrorLevels/" + img1.ImageUrl;

            // *** Assign attributs to the the rows using javascript function.
            e.Row.Attributes.Add("onclick", "setSelectedRow('" + grdDetails.ClientID + "'," + e.Row.RowIndex + "); document.getElementById('" + hid_Val.ClientID + "').value = '" + e.Row.Cells[1].Text + "';");
            e.Row.Attributes.Add("onmouseover", "ShowMouseOver(this);");
            e.Row.Attributes.Add("onmouseout", "ShowMouseOut(this);");

        }

    }

    /// <summary>
    /// Function to handle event handle
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnDelete_Click(object sender, ImageClickEventArgs e)
    {

            string conn = "";

            // *** Declare an object of type data operation 
            data_Operations db = new data_Operations();

            try
            {

                // *** Open a database connection
                conn = db.openConnection();

                // *** Check if connection is successfull
                if (conn == "success")
                {

                    // *** Declare the hash table and initialize the parameters
                    Hashtable param = new Hashtable();
                    param.Add("@id", hid_Val.Value.ToString());

                    // *** Execute the stored procedure
                    int i = db.executeQuery("ui_CurrentEventHandler", true, param);

                    // *** Check if record is inserted if so popup appropriate buttons
                    if (i > 0)
                    {

                        // *** Execute the javascript
                        Page.ClientScript.RegisterStartupScript(this.GetType(), "a", "alert('Current Event is successfully handled');", true);

                    }
                    else
                    {

                        // *** Execute the javascript
                        Page.ClientScript.RegisterStartupScript(this.GetType(), "b", "alert('Problem handling Current Event');", true);

                    }

                }


                // *** Close the database connection
                db.closeConnection();

            }
            catch
            {

                // *** Close the database connection
                db.closeConnection();

            }
            finally
            {

                // *** Page refreshes to show that the event is handled
                Response.Redirect("frmCurrentEvents.aspx");

            }
        
    }

}
