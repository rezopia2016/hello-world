using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

#region "--Class Description--"
///<classname>Queue Transaction class</classname>
///<author>Santhosh Kumar</author>
///<date created>19/5/2008</datecreated>
///<datemodified>19/5/2008</datemodified>
///<modified by>Santhosh Kumar</modified by>
///<no. of classes>1</no. of classes>
///<no. of methods></no. of methods>
/// <summary>
/// Class used to call CRUD methods
/// </summary>
/// 
#endregion

public partial class frmQueueTrans : System.Web.UI.Page
{

    // *** Declare the local variables
    int id = 0;
    int oprType = 0;

    protected void Page_Load(object sender, EventArgs e)
    {


        if (Session["UserId"] != null && Session["UserType"] != null && Session["UserType"].ToString().Trim().ToLower() == "admin")
        {
            // *** Retrieve the query string and initialize
            if (Request.QueryString["Id"] != null)
            {

                id = Convert.ToInt32(Request.QueryString["Id"]);

            }

            if (Request.QueryString["Oper"] != null)
            {

                oprType = Convert.ToInt32(Request.QueryString["Oper"]);

            }

            // *** Check if post back
            if (Page.IsPostBack == false)
            {

                // *** Calling function to set control state method
                setControlState();

                // *** Check if operation type != 0
                if (oprType != 0)
                {

                    // *** Calling function to set details
                    SetDetails();

                }

            }
        
        }
        else
        {

            // *** Execute the javascript
            Page.ClientScript.RegisterStartupScript(this.GetType(), "relo", "window.opener.location.href=window.opener.location;window.close();", true);

        }
   

    }

    /// <summary>
    /// Function to set control state
    /// </summary>
    private void setControlState()
    {

        // *** Check if operation to be performed is create
        if (oprType == 0)
        {

            btnCreate.Text = "Create";
            lblTitle.Text = "Queues - Create";
        
        }
        else if (oprType == 1)   // *** Check if operation to be performed is update
        {
        
            btnCreate.Text = "Update";
            lblTitle.Text = "Queues - Modify";
        
        }
        else   // *** Check if operation to be performed is delete
        {
        
            btnCreate.Text = "Delete";
            lblTitle.Text = "Queues - Delete";

            txtName.Enabled = false;
            txtSuccess.Enabled = false;
            txtFail.Enabled = false;
            txtMax.Enabled = false;
            chkEnabled.Enabled = false;

            btnCreate.Attributes.Add("onclick", "return confirmation();");
        
        }

    }

    /// <summary>
    /// Function to set details
    /// </summary>
    private void SetDetails()
    {

        // *** Declare an object
        clsQueues obj = new clsQueues();
        DataSet dsDetails = new DataSet();
        
        // *** Calling function to GetQueueDetails methods
        dsDetails = obj.GetQueueDetails(id);

        // *** Initialize the controls
        if (dsDetails != null && dsDetails.Tables.Count > 0 && dsDetails.Tables[0].Rows.Count > 0)
        {

            txtName.Text = dsDetails.Tables[0].Rows[0]["name"].ToString();
            txtSuccess.Text = dsDetails.Tables[0].Rows[0]["samplingIntervalSuccess"].ToString();
            txtFail.Text = dsDetails.Tables[0].Rows[0]["samplingIntervalFail"].ToString();
            txtMax.Text = dsDetails.Tables[0].Rows[0]["maxThreads"].ToString();
            chkEnabled.Checked = Convert.ToBoolean(dsDetails.Tables[0].Rows[0]["enabled"]);
        
        }
        
        // *** Dispose the objects
        dsDetails.Dispose();
        obj = null;

    }

    /// <summary>
    /// Function for button press
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnCreate_Click(object sender, EventArgs e)
    {

        // *** Check if operation to be performed is create
        if (oprType == 0)
        {

            // *** Calling function to Create method
            Create();

        }
        else if (oprType == 1) // *** Check if operation to be performed is update
        {

            // *** Calling function to Update method
            Update();
       
        }
        else // *** Check if operation to be performed is delete
        {

            // *** Calling function to Delete method 
            Delete();
        
        }
        
        // *** Execute the javascript
        Page.ClientScript.RegisterStartupScript(this.GetType(), "relo", "window.opener.location.href=window.opener.location;window.close();", true);
    
    }

    /// <summary>
    /// Function to create a new record
    /// </summary>
    private void Create()
    {

        // *** Create an object of type clsQueues
        clsQueues obj = new clsQueues();

        // *** Calling function to InsertQueue method
        obj.InsertQueue(txtName.Text, Convert.ToInt32(txtSuccess.Text), Convert.ToInt32(txtFail.Text), Convert.ToInt32(txtMax.Text), chkEnabled.Checked);
        obj = null;

    }

    /// <summary>
    /// Function to update the record
    /// </summary>
    private void Update()
    {

        // *** Create an object of type clsQueues
        clsQueues obj = new clsQueues();

        // *** Calling function to UpdateQueue method
        obj.UpdateQueue(id,txtName.Text, Convert.ToInt32(txtSuccess.Text), Convert.ToInt32(txtFail.Text), Convert.ToInt32(txtMax.Text), chkEnabled.Checked);
        obj = null;
   
    }

    /// <summary>
    /// Function to delete the record
    /// </summary>
    private void Delete()
    {

        // *** Create an object of type clsQueues
        clsQueues obj = new clsQueues();

        // *** Calling function to Deletequeue method
        obj.Deletequeue(id);
        obj = null;
    
    }

}
