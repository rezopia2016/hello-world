using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

#region "--Class Description--"
///<classname>Groups Transaction Calling class</classname>
///<author>Santhosh Kumar</author>
///<date created>18/5/2008</datecreated>
///<datemodified>18/5/2008</datemodified>
///<modified by>Santhosh Kumar</modified by>
///<no. of classes>1</no. of classes>
///<no. of methods></no. of methods>
/// <summary>
/// Class to call CRUD operation methods
/// </summary>
/// 
#endregion

public partial class frmGroupTrans : System.Web.UI.Page
{

    // *** Declare the local variables
    int id = 0;
    int oprType = 0;

    protected void Page_Load(object sender, EventArgs e)
    {

        if (Session["UserId"] != null && Session["UserType"] != null && Session["UserType"].ToString().Trim().ToLower() == "admin")
        {

            // *** Check the query string
            if (Request.QueryString["Id"] != null)
            {

                // *** Initilaize the id variable
                id = Convert.ToInt32(Request.QueryString["Id"]);

            }

            // *** Check the query string
            if (Request.QueryString["Oper"] != null)
            {

                // *** Initialize the oprType variable
                oprType = Convert.ToInt32(Request.QueryString["Oper"]);

            }

            // *** Check if postback or not
            if (Page.IsPostBack == false)
            {

                // *** Calling function to setControlState
                setControlState();

                if (oprType != 0)
                {

                    // *** Calling function to SetDetails method
                    SetDetails();

                }

            }

        }
        else
        {

            // *** Execute the javascript
            Page.ClientScript.RegisterStartupScript(this.GetType(), "relo", "window.opener.location.href=window.opener.location;window.close();", true);

        }

    }

    /// <summary>
    /// Function to set Control State 
    /// </summary>

    private void setControlState()
    {

        // *** Check if operation type is create
        if (oprType == 0)
        {

            btnCreate.Text = "Create";
            lblTitle.Text = "Groups - Create";
        
        }
        else if (oprType == 1)// *** Check if operation type is update
        {

            btnCreate.Text = "Update";
            lblTitle.Text = "Groups - Modify";
       
        }
        else // *** Check if operation type is delete
        {

            btnCreate.Text = "Delete";
            lblTitle.Text = "Groups - Delete";
            txtDesc.Enabled = false;

            // *** Execute the javascript
            btnCreate.Attributes.Add("onclick", "return confirmation();");
        
        }

    }
    
    /// <summary>
    /// Function to set details
    /// </summary>
    private void SetDetails()
    {

        // *** Declare the local variable
        clsGroups obj = new clsGroups();
        DataSet dsDetails = new DataSet();

        // *** Call the GetGroupDetails method from the database
        dsDetails = obj.GetGroupDetails(id);

        // *** Initialize the controls
        if (dsDetails != null && dsDetails.Tables.Count > 0 && dsDetails.Tables[0].Rows.Count > 0)
        {

            txtDesc.Text = dsDetails.Tables[0].Rows[0][0].ToString();
        
        }
        
        // *** Dispose the objects
        dsDetails.Dispose();
        obj = null;

    }

    /// <summary>
    /// Function to be performe on button press
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnCreate_Click(object sender, EventArgs e)
    {

        // *** Check if we have to create a new record
        if (oprType == 0)
        {

            // *** Calling function to create method
            Create();

        }
        else if (oprType == 1)// *** Check if we have to update a record
        {

            // *** Calling function to update method
            Update();

        }
        else // *** Check if we have to delete a record
        {

            // *** Calling function to delete method
            Delete();

        }

        // *** Execute the javascript
        Page.ClientScript.RegisterStartupScript(this.GetType(), "relo", "window.opener.location.href=window.opener.location;window.close();", true);
    
    }

    /// <summary>
    /// Function to create a new record
    /// </summary>
    private void Create()
    {

        // *** Declare the local variables
        clsGroups obj = new clsGroups();

        // *** Insert the new record
        obj.InsertGroup(txtDesc.Text);
        obj = null;

    }

    /// <summary>
    /// Function to update a record
    /// </summary>
    private void Update()
    {

        // *** Declare the local variables
        clsGroups obj = new clsGroups();

        // *** Calling function to update the group
        obj.UpdateGroup(id, txtDesc.Text);
        obj = null;

    }

    /// <summary>
    /// Function to delete the record
    /// </summary>
    private void Delete()
    {

        // *** Declare the local variables
        clsGroups obj = new clsGroups();

        // *** Calling function to delete the group data
        obj.DeleteGroup(id);
        obj = null;

    }

}
