using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

#region "--Class Description--"
///<classname>Change Password class</classname>
///<author>Santhosh Kumar</author>
///<date created>07/06/2008</datecreated>
///<datemodified>07/06/2008</datemodified>
///<modified by>Santhosh Kumar</modified by>
///<no. of classes>1</no. of classes>
///<no. of methods></no. of methods>
/// <summary>
/// Class used to Change the Password of a User
/// </summary>
/// 
#endregion

public partial class frmChangePassword : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void txtOldPass_TextChanged(object sender, EventArgs e)
    {

        // *** Declare the local variables
        data_Operations db = new data_Operations();
        DataSet ds = new DataSet();
        string oldPassword = "";
        string cmd = "";

        // *** Open the database connection
        string conn = db.openConnection();

        // *** Check if connection is successfull
        if (conn == "success")
        {

            // *** Declare and initialize the hash table and parameters
            cmd = "ui_ChangePassword";

            Hashtable param = new Hashtable();
            param.Add("@type", "1".ToString());
            param.Add("@userid", Session["UserId"].ToString());

            // *** Execute the stored procedure
            ds = db.getDataSet(cmd,true,param);

            // *** Check if dataset is empty
            if (ds.Tables[0].Rows.Count > 0 && ds != null)
            {

                // ***  Retrive the old password
                oldPassword = ds.Tables[0].Rows[0][0].ToString();

                // *** Compare if password matches with the old password
                if (oldPassword.Trim().ToString() != txtOldPass.Text.Trim().ToString())
                {

                    // *** Disable the change password if old password is not right
                    btnCreate.Enabled = false;
                    Page.ClientScript.RegisterStartupScript(this.GetType(), "relo", "alert('Type Valid Old Password to Enable Change Password Button');", true);
                }
                else
                {

                    // *** Enable the change password buttin if old passowrd is right
                    btnCreate.Enabled = true;
                }

            }

        }

        // *** Close the database connection
        db.closeConnection();


    }

    /// <summary>
    /// Function to change the password
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnCreate_Click(object sender, EventArgs e)
    {

        // *** Declare the local variables
        data_Operations db = new data_Operations();
        string cmd = "";
       
        // *** Open the database connection
        string conn = db.openConnection();

        // *** Check if connection is successfull
        if (conn == "success")
        {

            // *** Declare the local variables and hash table
            cmd = "ui_ChangePassword";

            Hashtable param = new Hashtable();
            param.Add("@type", "2".ToString());
            param.Add("@userid", Session["UserId"].ToString());
            param.Add("@password", txtNewPass.Text.Trim().ToString());

            // *** Execute the stored procedure
            int i = db.executeQuery(cmd,true,param);

        }

        // *** Close the database connection
        db.closeConnection();

        // *** Calling function to close the popup window and return to the main page
        Page.ClientScript.RegisterStartupScript(this.GetType(), "relo", "window.opener.location.href=window.opener.location;window.close();", true);
    
    }
}
