using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

#region "--Class Description--"
///<classname>Notificaiton Types Transaction class</classname>
///<author>Santhosh Kumar</author>
///<date created>18/5/2008</datecreated>
///<datemodified>18/5/2008</datemodified>
///<modified by>Santhosh Kumar</modified by>
///<no. of classes>1</no. of classes>
///<no. of methods></no. of methods>
/// <summary>
/// Class used to call the methods to perform CRUD operation
/// </summary>
/// 
#endregion

public partial class frmNotificationTypesTrans : System.Web.UI.Page
{

    // *** Declare the local variables
    int id = 0;
    int oprType = 0;

    protected void Page_Load(object sender, EventArgs e)
    {

        if (Session["UserId"] != null && Session["UserType"] != null && Session["UserType"].ToString().Trim().ToLower() == "admin")
        {

            // *** Check the query string and initialize the id variable
            if (Request.QueryString["Id"] != null)
            {

                id = Convert.ToInt32(Request.QueryString["Id"]);

            }

            // *** Check the query string and initialize the oprType variable
            if (Request.QueryString["Oper"] != null)
            {

                oprType = Convert.ToInt32(Request.QueryString["Oper"]);

            }

            // *** Check if page is post back or not
            if (Page.IsPostBack == false)
            {

                // *** Calling function to set Control State
                setControlState();

                // *** Check oprType value
                if (oprType != 0)
                {

                    // *** Calling function to Set Details
                    SetDetails();

                }

            }

        }
        else
        {

            // *** Execute the javascript
            Page.ClientScript.RegisterStartupScript(this.GetType(), "relo", "window.opener.location.href=window.opener.location;window.close();", true);

        }
   
    }

    /// <summary>
    /// Function to set the controls state
    /// </summary>
    private void setControlState()
    {
    
        // *** Check if the operation performed is create
        if (oprType == 0)
        {
          
            btnCreate.Text = "Create";
            lblTitle.Text = "Notification Types - Create";
            imgIcon.Visible = false;
        
        }
        else if (oprType == 1) // *** Check if the operation performed is update
        {
           
            btnCreate.Text = "Update";
            lblTitle.Text = "Notification Types - Modify";
            txtId.Enabled = false;
        
        }
        else // *** Check if the operation performed is delte
        {
           
            btnCreate.Text = "Delete";
            lblTitle.Text = "Notification Types - Delete";
            txtId.Enabled = false;
            txtDesc.Enabled = false;
            fupIcon.Enabled = false;

            // *** Javascript call
            btnCreate.Attributes.Add("onclick", "return confirmation();");
        
        }
    }

    /// <summary>
    /// Function to Set Details 
    /// </summary>
    private void SetDetails()
    {
        
        // *** Declare the local variables and objects
        clsNotificationTypes obj = new clsNotificationTypes();
        DataSet dsDetails = new DataSet();

        // *** Calling function to GetNotificationTypesDetails
        dsDetails = obj.GetNotificationTypesDetails(id);

        // *** Initialize the controls
        if (dsDetails != null && dsDetails.Tables.Count > 0 && dsDetails.Tables[0].Rows.Count > 0)
        {

            txtDesc.Text = dsDetails.Tables[0].Rows[0][1].ToString();
            txtId.Text = dsDetails.Tables[0].Rows[0][0].ToString();
            
            // *** Assign image path to image control
            if (dsDetails.Tables[0].Rows[0][2].ToString() != "")
            {
                
                imgIcon.ImageUrl = "User_Icons/NotificationTypes/" + dsDetails.Tables[0].Rows[0][2].ToString();
           
            }

        }

        // *** Dispose the objects manually
        dsDetails.Dispose();
        obj = null;

    }

    /// <summary>
    /// Function call on button press
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnCreate_Click(object sender, EventArgs e)
    {
       
        // *** Check if oprType is set to create
        if (oprType == 0)
        {
            
            // *** Calling function to Create method
            Create();
        
        }
        else if (oprType == 1) // *** Check if opertion to be performed is update
        {

            // *** Calling function to Update method
            Update();
        
        }
        else // *** Check if operation to be performed is delete
        {

            // *** Calling funtion to Delete method
            Delete();
        
        }
    
    }

    /// <summary>
    /// Function to perform Create operation
    /// </summary>
    private void Create()
    {
        
        // *** Check file uploader control
        if (fupIcon.PostedFile != null && fupIcon.FileName != "")
        {

            // *** Check the extension
            if (System.IO.Path.GetExtension(fupIcon.FileName).ToLower() == ".jpeg" || System.IO.Path.GetExtension(fupIcon.FileName).ToLower() == ".jpg" || System.IO.Path.GetExtension(fupIcon.FileName).ToLower() == ".png" || System.IO.Path.GetExtension(fupIcon.FileName).ToLower() == ".gif" || System.IO.Path.GetExtension(fupIcon.FileName).ToLower() == ".ico")
            {

                // *** Create an object and formulate the string path
                clsNotificationTypes obj = new clsNotificationTypes();
                string strPath = System.IO.Path.GetExtension(fupIcon.FileName);
                strPath = "notification" + txtId.Text + strPath;

                // *** Calling function to InsertNotificationType method
                int retVal = obj.InsertNotificationType(Convert.ToInt32(txtId.Text), txtDesc.Text, strPath);
                obj = null;

                if (retVal > 0)
                {

                    // *** Save the image in the path specified
                    fupIcon.PostedFile.SaveAs(Server.MapPath("User_Icons/NotificationTypes/" + strPath));
                
                }

                // *** Execute the javascript
                Page.ClientScript.RegisterStartupScript(this.GetType(), "relo", "window.opener.location.href=window.opener.location;window.close();", true);
            
            }
            else
            {

                // *** Javascript function
                Page.ClientScript.RegisterStartupScript(this.GetType(), "ale_mess", "alert('Please select Png, Gif, Jpeg or Ico images only');", true);
            
            }
        
        }
        else
        {
            
            // *** Execute the javascript
            Page.ClientScript.RegisterStartupScript(this.GetType(), "ale", "alert('Please select images');", true);
        
        }
    
    }

    /// <summary>
    /// Function to perform update operations 
    /// </summary>
    private void Update()
    {

        // *** Create an object
        clsNotificationTypes obj = new clsNotificationTypes();

        // *** Check file uploader
        if (fupIcon.PostedFile != null && fupIcon.PostedFile.FileName != "")// *** Replace the existing image
        {

            // *** Check the extension
            if (System.IO.Path.GetExtension(fupIcon.FileName).ToLower() == ".jpeg" || System.IO.Path.GetExtension(fupIcon.FileName).ToLower() == ".jpg" || System.IO.Path.GetExtension(fupIcon.FileName).ToLower() == ".png" || System.IO.Path.GetExtension(fupIcon.FileName).ToLower() == ".gif" || System.IO.Path.GetExtension(fupIcon.FileName).ToLower() == ".ico")
            {

                // *** Formulate the string path
                string strPath = System.IO.Path.GetExtension(fupIcon.FileName);
                strPath = "notification" + txtId.Text + strPath;

                // *** Calling function to UpdateNotificationType method
                int retVal = obj.UpdateNotificationType(Convert.ToInt32(txtId.Text), txtDesc.Text, strPath);
                obj = null;

                if (retVal > 0)
                {
                
                    // *** Save the image in the specified path 
                    fupIcon.PostedFile.SaveAs(Server.MapPath("User_Icons/NotificationTypes/" + strPath));
                
                }
                
                // *** Execute the javascript
                Page.ClientScript.RegisterStartupScript(this.GetType(), "relo", "window.opener.location.href=window.opener.location;window.close();", true);
            
            }
            else
            {
            
                // *** Execute the javascript
                Page.ClientScript.RegisterStartupScript(this.GetType(), "ale_mess", "alert('Please select Png, Gif, Jpeg or Ico images only');", true);
            
            }
        
        }
        else
        {
        
            // *** Retrieve the extension and formulate the image filename
            string strPath = System.IO.Path.GetExtension(fupIcon.FileName);
            strPath = System.IO.Path.GetFileName(imgIcon.ImageUrl);

            // *** Calling function to UpdateNotificationType method
            obj.UpdateNotificationType(Convert.ToInt32(txtId.Text), txtDesc.Text, strPath);
            obj = null;

            // *** Execute the javascript
            Page.ClientScript.RegisterStartupScript(this.GetType(), "relo", "window.opener.location.href=window.opener.location;window.close();", true);
        
        }

        // *** Dispose the methods
        obj = null;

    }

    /// <summary>
    /// Function to delete the notification types 
    /// </summary>
    private void Delete()
    {

        // *** Create the objects
        clsNotificationTypes obj = new clsNotificationTypes();

        // *** Calling function to DeleteNotificationTypes method
        int retVal = obj.DeleteNotificationTypes(id);

        if (retVal > 0)
        {
        
            if (imgIcon.ImageUrl != "")
            {
            
                // *** Delete the image from the specifie path
                System.IO.File.Delete(Server.MapPath(imgIcon.ImageUrl));
            
            }
        
        }
        
        // *** Dispose the objects
        obj = null;
        
        // *** Execute the javascript
        Page.ClientScript.RegisterStartupScript(this.GetType(), "relo", "window.opener.location.href=window.opener.location;window.close();", true);
    
    }

}
