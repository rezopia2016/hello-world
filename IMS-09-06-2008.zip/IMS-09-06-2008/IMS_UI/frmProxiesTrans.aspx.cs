using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

#region "--Class Description--"
///<classname>Proxies Transaction class</classname>
///<author>Santhosh Kumar</author>
///<date created>19/5/2008</datecreated>
///<datemodified>19/5/2008</datemodified>
///<modified by>Santhosh Kumar</modified by>
///<no. of classes>1</no. of classes>
///<no. of methods></no. of methods>
/// <summary>
/// Class used to call CRUD methods
/// </summary>
/// 
#endregion

public partial class frmProxiesTrans : System.Web.UI.Page
{

    // *** Declare the local variables
    int id = 0;
    int oprType = 0;

    protected void Page_Load(object sender, EventArgs e)
    {


        if (Session["UserId"] != null && Session["UserType"] != null && Session["UserType"].ToString().Trim().ToLower() == "admin")
        {

            // *** Check the query string
            if (Request.QueryString["Id"] != null)
            {

                // *** initialize the id variable
                id = Convert.ToInt32(Request.QueryString["Id"]);

            }

            // *** Check the query string
            if (Request.QueryString["Oper"] != null)
            {

                // *** initialize the operation type variable
                oprType = Convert.ToInt32(Request.QueryString["Oper"]);

            }

            if (Page.IsPostBack == false)
            {

                // *** Calling function to setControlState method
                setControlState();

                if (oprType != 0)
                {

                    // *** Calling function to SetDetails method
                    SetDetails();

                }

            }

        }
        else
        {

            // *** Execute the javascript
            Page.ClientScript.RegisterStartupScript(this.GetType(), "relo", "window.opener.location.href=window.opener.location;window.close();", true);

        }

    }

    /// <summary>
    /// Function to set control state
    /// </summary>
    private void setControlState()
    {

        // *** Check if operation to be performed is create
        if (oprType == 0)
        {
           
            btnCreate.Text = "Create";
            lblTitle.Text = "Proxies - Create";

        }
        else if (oprType == 1)// *** Check if operation to be performed is update
        {

            btnCreate.Text = "Update";
            lblTitle.Text = "Proxies - Modify";

        }
        else // *** Check if operation to be performed is delete
        {

            btnCreate.Text = "Delete";
            lblTitle.Text = "Proxies - Delete";

            txtName.Enabled = false;
            txthost.Enabled = false;
            txtPort.Enabled = false;
            txtUserId.Enabled = false;
            txtThreshold.Enabled = false;
            txtPass.Enabled = false;

            // *** Assign the attribute to the button control
            btnCreate.Attributes.Add("onclick", "return confirmation();");
       
        }
   
    }

    /// <summary>
    /// Function to set details
    /// </summary>
    private void SetDetails()
    {
        
        // *** Create an object
        clsProxies obj = new clsProxies();
        DataSet dsDetails = new DataSet();
        
        // *** Calling function to GetProxyDetails method
        dsDetails = obj.GetProxyDetails(id);

        // *** Initialize the controls
        if (dsDetails != null && dsDetails.Tables.Count > 0 && dsDetails.Tables[0].Rows.Count > 0)
        {

            txtName.Text = dsDetails.Tables[0].Rows[0]["name"].ToString();
            txthost.Text = dsDetails.Tables[0].Rows[0]["host"].ToString();
            txtPort.Text = dsDetails.Tables[0].Rows[0]["port"].ToString();
            txtUserId.Text = dsDetails.Tables[0].Rows[0]["userid"].ToString();
            hid_Pass.Value = dsDetails.Tables[0].Rows[0]["password"].ToString();
            txtThreshold.Text = dsDetails.Tables[0].Rows[0]["slowResponseThreshold"].ToString();
        
        }
        
        // *** Dispose the objects
        dsDetails.Dispose();
        obj = null;

    }

    /// <summary>
    /// Function on button press
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnCreate_Click(object sender, EventArgs e)
    {
        
        // *** Check if operation to be performed is create 
        if (oprType == 0)
        {

            // *** Calling function to Create method
            Create();

        }
        else if (oprType == 1) // *** Check if operation to be performed is update 
        {

            // *** Calling function to Update method
            Update();
        
        }
        else // *** Check if operation to be performed is delete 
        {

            // *** Calling function to Delete method
            Delete();
        
        }

        // *** Execute the javascript
        Page.ClientScript.RegisterStartupScript(this.GetType(), "relo", "window.opener.location.href=window.opener.location;window.close();", true);
   
    }

    /// <summary>
    /// Function to create a new proxy
    /// </summary>
    private void Create()
    {

        // *** Declare an object
        clsProxies obj = new clsProxies();

        // *** calling function to InsertProxies methods
        obj.InsertProxies(txtName.Text, txthost.Text, txtPort.Text, txtUserId.Text, txtPass.Text, Convert.ToInt32(txtThreshold.Text));
        obj = null;

    }

    /// <summary>
    /// Function to update the existing proxy
    /// </summary>
    private void Update()
    {

        // *** Declare an object
        clsProxies obj = new clsProxies();

        // *** Calling function to UpdateProxies methods
        obj.UpdateProxies(id, txtName.Text, txthost.Text, txtPort.Text, txtUserId.Text, txtPass.Text != "" ? txtPass.Text : hid_Pass.Value, Convert.ToInt32(txtThreshold.Text));
        obj = null;

    }

    /// <summary>
    /// Function to delete the proxy record
    /// </summary>
    private void Delete()
    {

        // *** Declare an object
        clsProxies obj = new clsProxies();

        // *** Calling function to DeleteProxies method
        obj.DeleteProxies(id);
        obj = null;

    }

}
