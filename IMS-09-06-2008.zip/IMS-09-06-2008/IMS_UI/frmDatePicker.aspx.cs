using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

#region "--Class Description--"
///<classname>Date Time Picker class</classname>
///<author>Santhosh Kumar</author>
///<date created>27/5/2008</datecreated>
///<datemodified>27/5/2008</datemodified>
///<modified by>Santhosh Kumar</modified by>
///<no. of classes>1</no. of classes>
///<no. of methods></no. of methods>
/// <summary>
/// Class used as data time picker
/// </summary>
/// 
#endregion

public partial class frmDatePicker : System.Web.UI.Page
{

    // ***  Declare the local variables
    string strcon = "";

    protected void Page_Load(object sender, EventArgs e)
    {

        // *** Retrieve the query string
        strcon = Request.QueryString["conId"];

    }

    /// <summary>
    /// Function to pass the date selected value back to the main page
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void Calendar1_SelectionChanged(object sender, EventArgs e)
    {

        // *** Formulate the javasc ript
        string strScr = "window.opener.document.getElementById('" + strcon + "').value='" + Calendar1.SelectedDate + "';";
        strScr = strScr + "window.close();";

        // *** Execute the javascript
        Page.ClientScript.RegisterStartupScript(this.GetType(), "setVal", strScr, true);

    }

}
