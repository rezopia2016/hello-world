using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

#region "--Class Description--"
///<classname>User Agents Main class</classname>
///<author>Santhosh Kumar</author>
///<date created>22/5/2008</datecreated>
///<datemodified>22/5/2008</datemodified>
///<modified by>Santhosh Kumar</modified by>
///<no. of classes>1</no. of classes>
///<no. of methods></no. of methods>
/// <summary>
/// Class used to list the records in the datagrid
/// </summary>
/// 
#endregion


public partial class frmUserAgents : System.Web.UI.Page
{

    protected void Page_Load(object sender, EventArgs e)
    {

        // *** Check whether the user is the administrator or a normal user.
        if (Session["UserId"] != null && Session["UserType"] != null && Session["UserType"].ToString().Trim().ToLower() == "admin")
        {

            // *** Calling function to FillUserAgents Details
            FillUserAgentsList();
       
        }
        else
        {

            // *** Redirect to login page if session does not exist
            Response.Redirect("frmLogin.aspx");

        }

    }

    /// <summary>
    /// Function to list the information in the grid
    /// </summary>
    private void FillUserAgentsList()
    {

        // *** Declare the objects
        data_Operations objData = new data_Operations();
        
        // *** Open a database connection
        string strSucess = objData.openConnection();
        
        // *** Check if connection is open
        if (strSucess == "success")
        {

            // *** Execute the stored procedure
            DataSet ds = objData.getDataSet("ui_UserAgents_List", true);
            grdDetails.DataSource = ds;
            grdDetails.DataBind();

        }

        // *** Close the database connection
        objData.closeConnection();

    }

    /// <summary>
    /// Function to bind the data in the row
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void grdDetails_RowDataBound(object sender, GridViewRowEventArgs e)
    {

        // *** Hide the first cell in the datarow
        e.Row.Cells[0].Style.Add("display", "none");
        
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
        
            // *** Assign attributes to the row
            e.Row.Attributes.Add("onclick", "setSelectedRow('" + grdDetails.ClientID + "'," + e.Row.RowIndex + "); document.getElementById('" + hid_Val.ClientID + "').value = '" + e.Row.Cells[0].Text + "';selRow = " + (e.Row.RowIndex + 1) + ";");
            e.Row.Attributes.Add("onmouseover", "ShowMouseOver(this);");
            e.Row.Attributes.Add("onmouseout", "ShowMouseOut(this);");        
        
        }
    
    }

}
