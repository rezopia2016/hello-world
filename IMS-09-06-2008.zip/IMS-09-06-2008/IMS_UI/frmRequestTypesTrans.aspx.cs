using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

#region "--Class Description--"
///<classname>Request Type class</classname>
///<author>Santhosh Kumar</author>
///<date created>20/5/2008</datecreated>
///<datemodified>20/5/2008</datemodified>
///<modified by>Santhosh Kumar</modified by>
///<no. of classes>1</no. of classes>
///<no. of methods></no. of methods>
/// <summary>
/// Class used to call the CRUD methods
/// </summary>
/// 
#endregion

public partial class frmRequestTypesTrans : System.Web.UI.Page
{

    // *** Declare the global variables
    int id = 0;
    int oprType = 0;

    protected void Page_Load(object sender, EventArgs e)
    {


        if (Session["UserId"] != null && Session["UserType"] != null && Session["UserType"].ToString().Trim().ToLower() == "admin")
        {

            // *** Retrieve the query string and initialize the parameters
            if (Request.QueryString["Id"] != null)
            {

                id = Convert.ToInt32(Request.QueryString["Id"]);

            }

            if (Request.QueryString["Oper"] != null)
            {

                oprType = Convert.ToInt32(Request.QueryString["Oper"]);

            }

            // *** Check if post back 
            if (Page.IsPostBack == false)
            {
                // *** Calling function to set control state
                setControlState();

                if (oprType != 0)
                {

                    // *** Calling function to set details
                    SetDetails();

                }

            }

        }
        else
        {

            // *** Execute the javascript
            Page.ClientScript.RegisterStartupScript(this.GetType(), "relo", "window.opener.location.href=window.opener.location;window.close();", true);

        }
  
    }


    /// <summary>
    /// Function to set control state
    /// </summary>
    private void setControlState()
    {
      
        // *** Check if operation to be performed is create
        if (oprType == 0)
        {
           
            btnCreate.Text = "Create";
            lblTitle.Text = "Request Types - Create";
        
        }
        else if (oprType == 1)// *** Check if operation to be performed is update
        {
           
            btnCreate.Text = "Update";
            lblTitle.Text = "Request Types - Modify";
       
        }
        else// *** Check if operation to be performed is delete
        {

            btnCreate.Text = "Delete";
            lblTitle.Text = "Request Types - Delete";
            txtDesc.Enabled = false;
            btnCreate.Attributes.Add("onclick", "return confirmation();");
        
        }

    }

    /// <summary>
    /// Function to Set Details
    /// </summary>
    private void SetDetails()
    {

        // *** Create an object of type clsRequestType
        clsRequestType obj = new clsRequestType();
        DataSet dsDetails = new DataSet();

        // *** Calling function to GetRequestTypeDetails method
        dsDetails = obj.GetRequestTypeDetails(id);

        // *** Initialize the controls
        if (dsDetails != null && dsDetails.Tables.Count > 0 && dsDetails.Tables[0].Rows.Count > 0)
        {

            txtDesc.Text = dsDetails.Tables[0].Rows[0][1].ToString();
        
        }
        
        // *** Dispose the objects
        dsDetails.Dispose();
        obj = null;

    }

    /// <summary>
    /// Function to execute on button press
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnCreate_Click(object sender, EventArgs e)
    {

        // *** Check if operation to be performed is Create
        if (oprType == 0)
        {

            // *** Calling function to Create
            Create();

        }
        else if (oprType == 1)  // *** Check if operation to be performed is Update
        {

            // *** Calling function to Update
            Update();
        
        }
        else  // *** Check if operation to be performed is Delete
        {

            // *** Calling function to Delete
            Delete();

        }

        // *** Execute the javascript
        Page.ClientScript.RegisterStartupScript(this.GetType(), "relo", "window.opener.location.href=window.opener.location;window.close();", true);
   
    }

    /// <summary>
    /// Function to create a new record
    /// </summary>
    private void Create()
    {

        // *** Create an object of type clsRequestType
        clsRequestType obj = new clsRequestType();
        
        // *** Calling function to InsertRequestType method
        obj.InsertRequestType(txtDesc.Text);
        obj = null;

    }

    /// <summary>
    /// Function to update a record
    /// </summary>
    private void Update()
    {

        // *** Create an object of type clsRequestType
        clsRequestType obj = new clsRequestType();

        // *** Calling function to UpdateRequestType method
        obj.UpdateRequestType(id, txtDesc.Text);
        obj = null;

    }

    /// <summary>
    /// Function to delete  a record
    /// </summary>
    private void Delete()
    {

        // *** Create an object of type clsRequestType
        clsRequestType obj = new clsRequestType();

        // *** Calling function to DeleteRequestType method
        obj.DeleteRequestType(id);
        obj = null;

    }

}
