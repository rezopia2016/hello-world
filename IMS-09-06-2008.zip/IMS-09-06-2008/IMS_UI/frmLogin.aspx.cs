using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;


#region "--Class Description--"
///<classname>Authentication & permission class</classname>
///<author>Santhosh Kumar</author>
///<date created>04/06/2008</datecreated>
///<datemodified>04/06/2008</datemodified>
///<modified by>Santhosh Kumar</modified by>
///<no. of classes>1</no. of classes>
///<no. of methods></no. of methods>
/// <summary>
/// Class used for Authentication into the application
/// </summary>
/// 
#endregion

public partial class frmLogin : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void btnLogin_Click(object sender, EventArgs e)
    {
        
        
        // *** Declare the local variables
        data_Operations objData = new data_Operations();

        // *** Open the database connection
        string strSucess = objData.openConnection();
        
        // *** Check if connection is succesfull
        if (strSucess == "success")
        {

            // *** Declare the hashtable and initialize the parameters
            Hashtable hsh = new Hashtable();
            hsh.Add("@UserId", txtUserName.Text);
            hsh.Add("@Password", txtPassWord.Text);

            // *** Execute the stored procedure an retrieve the result in the dataset
            DataSet ds = objData.getDataSet("ui_checkLogin", true, hsh);

            // *** Close the database connection
            objData.closeConnection();

            // *** Check if dataset is empty
            if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {

                // *** Initialize the Session Variables
                Session["UserId"] = ds.Tables[0].Rows[0]["id"].ToString();
                Session["UserType"] = Convert.ToBoolean(ds.Tables[0].Rows[0]["isAdmin"]) == true ? "Admin" : "User";
                
                // *** Redirect the User to the Master page
                if (Convert.ToBoolean(ds.Tables[0].Rows[0]["isAdmin"]) == true)
                {

                    // *** Redirect to the concerned Url
                    Response.Redirect("Home.aspx");

                }
                else
                {

                    // *** Redirect to the concerned Url
                    Response.Redirect("Home.aspx");

                }

            }
            else
            {

                // *** If Authentication fails execute the javascript
                Page.ClientScript.RegisterStartupScript(this.GetType(), "aler", "alert('Invalid Credentials!. Please try again');",true);
           
            }

        }
        
    }

}
