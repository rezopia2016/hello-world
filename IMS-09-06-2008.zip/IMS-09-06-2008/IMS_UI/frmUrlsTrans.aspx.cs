using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

#region "--Class Description--"
///<classname>Urls Transaction class</classname>
///<author>Santhosh Kumar</author>
///<date created>21/5/2008</datecreated>
///<datemodified>21/5/2008</datemodified>
///<modified by>Santhosh Kumar</modified by>
///<no. of classes>1</no. of classes>
///<no. of methods></no. of methods>
/// <summary>
/// Class used to call the CRUD methods
/// </summary>
/// 
#endregion

public partial class frmUrlsTrans : System.Web.UI.Page
{

    // *** Declare the local variables
    int id = 0;
    int oprType = 0;

    protected void Page_Load(object sender, EventArgs e)
    {


        if (Session["UserId"] != null && Session["UserType"] != null && Session["UserType"].ToString().Trim().ToLower() == "admin")
        {

            // *** Retrieve the query string and initialize the parameters
            if (Request.QueryString["Id"] != null)
            {

                id = Convert.ToInt32(Request.QueryString["Id"]);

            }

            if (Request.QueryString["Oper"] != null)
            {

                oprType = Convert.ToInt32(Request.QueryString["Oper"]);

            }

            // *** Check if post back
            if (Page.IsPostBack == false)
            {

                // *** Calling function to set control state
                setControlState();

                // *** Calling function to fill drop downs
                FillDropDowns();

                if (oprType != 0)
                {

                    // *** Calling function to Set Details
                    SetDetails();

                }

           }
        
        }
        else
        {

            // *** Execute the javascript
            Page.ClientScript.RegisterStartupScript(this.GetType(), "relo", "window.opener.location.href=window.opener.location;window.close();", true);

        }

    }

    /// <summary>
    /// Function to fill drop downs
    /// </summary>
    private void FillDropDowns()
    {

        FillDrop(ddlCookie, "ui_cookies_List", "id", "name");
        FillDrop(ddlCurrent, "ui_ErrorLevels_List", "id", "errorLevel");
        FillDrop(ddlMinError, "ui_ErrorLevels_List", "id", "errorLevel");
        FillDrop(ddlUnhandled, "ui_ErrorLevels_List", "id", "errorLevel");
        FillDrop(ddlGroupId, "ui_Groups_List", "id", "groupName");
        FillDrop(ddlProxy, "ui_porxies_list", "id", "name");
        FillDrop(ddlQueueId, "ui_queue_List", "id", "name");
        FillDrop(ddlReferrer, "ui_Referrer_List", "id", "name");
        FillDrop(ddlRequest, "ui_RequestType_List", "id", "requestType");
        FillDrop(ddlUserAgent, "ui_UserAgents_List", "id", "name");
    
    }

    /// <summary>
    /// Function to fill drop down
    /// </summary>
    /// <param name="ddl">drop down name</param>
    /// <param name="spName">stored procedure name</param>
    /// <param name="strData">data text field</param>
    /// <param name="strText">data value field</param>
    private void FillDrop(DropDownList ddl, string spName, string strData, string strText)
    {

        // *** Declare the data operation
        data_Operations objData = new data_Operations();
        
        // *** Open the data connection
        string strSucess = objData.openConnection();
        
        // *** Check if connection is successfull
        if (strSucess == "success")
        {

            // *** Execute the stored procedure
            DataSet ds = objData.getDataSet(spName, true);
            ddl.DataSource = ds;
            ddl.DataTextField = strText;
            ddl.DataValueField = strData;
            ddl.DataBind();

        }

        // *** Close the database connection
        objData.closeConnection();

    }

    /// <summary>
    /// Function to set the control state
    /// </summary>
    private void setControlState()
    {

        // *** Check if operation to be performed is create
        if (oprType == 0)
        {

            btnCreate.Text = "Create";
            lblTitle.Text = "Url - Create";
        
        }
        else if (oprType == 1)// *** Check if operation to be performed is update
        {

            btnCreate.Text = "Update";
            lblTitle.Text = "Url - Modify";
       
        }
        else // *** Check if operation to be performed is delete
        {

            btnCreate.Text = "Delete";
            lblTitle.Text = "Url - Delete";

            txtURL.Enabled = false;
            ddlGroupId.Enabled = false;
            ddlQueueId.Enabled = false;
            ddlUserAgent.Enabled = false;
            ddlReferrer.Enabled = false;
            ddlCookie.Enabled = false;
            ddlRequest.Enabled = false;
            ddlProxy.Enabled = false;
            ddlMinError.Enabled = false;
            ddlCurrent.Enabled = false;
            ddlUnhandled.Enabled = false;
            txtExpected.Enabled = false;

            btnCreate.Attributes.Add("onclick", "return confirmation();");
        
        }
   
    }

    /// <summary>
    /// Function to Set Details
    /// </summary>
    private void SetDetails()
    {

        // *** Declare the objects
        clsUrls obj = new clsUrls();
        DataSet dsDetails = new DataSet();

        // *** Calling function to GetUrlsDetails
        dsDetails = obj.GetUrlsDetails(id);

        // *** Initialize the controls
        if (dsDetails != null && dsDetails.Tables.Count > 0 && dsDetails.Tables[0].Rows.Count > 0)
        {

            txtURL.Text = dsDetails.Tables[0].Rows[0]["url"].ToString();
            ddlGroupId.Text = dsDetails.Tables[0].Rows[0]["groups_id"].ToString();
            ddlQueueId.Text = dsDetails.Tables[0].Rows[0]["queues_id"].ToString();
            ddlUserAgent.Text = dsDetails.Tables[0].Rows[0]["userAgents_id"].ToString();
            ddlReferrer.Text = dsDetails.Tables[0].Rows[0]["referrers_id"].ToString();
            ddlCookie.Text = dsDetails.Tables[0].Rows[0]["cookies_id"].ToString();
            ddlRequest.Text = dsDetails.Tables[0].Rows[0]["requestTypes_id"].ToString();
            ddlProxy.Text = dsDetails.Tables[0].Rows[0]["proxies_id"].ToString();
            ddlMinError.Text = dsDetails.Tables[0].Rows[0]["minErrorLevels_id"].ToString();
            ddlCurrent.Text = dsDetails.Tables[0].Rows[0]["currentAlertLevel"].ToString();
            ddlUnhandled.Text = dsDetails.Tables[0].Rows[0]["unHandledAlertLevel"].ToString();
            txtExpected.Text = dsDetails.Tables[0].Rows[0]["expectedText"].ToString();
        
        }
        
        // *** Dispose the objects
        dsDetails.Dispose();
        obj = null;

    }

    /// <summary>
    /// Function on button press
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnCreate_Click(object sender, EventArgs e)
    {

        // *** Check if operation to be performed is create
        if (oprType == 0)
        {

            // *** Calling function to Create method
            Create();

        }
        else if (oprType == 1)// *** Check if operation to be performed is update
        {
            
            // *** Calling function to Update method
            Update();

        }
        else// *** Check if operation to be performed is delete
        {
            
            // *** Calling function to Delete method
            Delete();

        }

        // *** Execute the javascript
        Page.ClientScript.RegisterStartupScript(this.GetType(), "relo", "window.opener.location.href=window.opener.location;window.close();", true);
    
    }

    /// <summary>
    /// Function to create a new record 
    /// </summary>
    private void Create()
    {

        // *** Declare an object of type clsUrls
        clsUrls obj = new clsUrls();

        // *** Calling function to InsertUrls method
        obj.InsertUrls(Convert.ToInt32(ddlGroupId.Text), Convert.ToInt32(ddlQueueId.Text), txtURL.Text, Convert.ToInt32(ddlUserAgent.Text), Convert.ToInt32(ddlReferrer.Text),
                        Convert.ToInt32(ddlCookie.Text), Convert.ToInt32(ddlRequest.Text), Convert.ToInt32(ddlProxy.Text), Convert.ToInt32(ddlMinError.Text), txtExpected.Text,
                        Convert.ToInt32(ddlCurrent.Text), Convert.ToInt32(ddlUnhandled.Text));
        obj = null;

    }

    /// <summary>
    /// Function to update the record
    /// </summary>
    private void Update()
    {

        // *** Declare an object of type clsUrls
        clsUrls obj = new clsUrls();

        // *** Calling function to UpdateUrls method
        obj.UpdateUrls(id, Convert.ToInt32(ddlGroupId.Text), Convert.ToInt32(ddlQueueId.Text), txtURL.Text, Convert.ToInt32(ddlUserAgent.Text), Convert.ToInt32(ddlReferrer.Text),
                        Convert.ToInt32(ddlCookie.Text), Convert.ToInt32(ddlRequest.Text), Convert.ToInt32(ddlProxy.Text), Convert.ToInt32(ddlMinError.Text), txtExpected.Text,
                        Convert.ToInt32(ddlCurrent.Text), Convert.ToInt32(ddlUnhandled.Text));
        obj = null;

    }

    /// <summary>
    /// Function to delete the record
    /// </summary>
    private void Delete()
    {

        // *** Declare an object of type clsUrls
        clsUrls obj = new clsUrls();

        // *** Calling function to DeleteUrls method
        obj.DeleteUrls(id);
        obj = null;

    }

}
