using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

#region "--Class Description--"
///<classname>Cookies Transaction class</classname>
///<author>Santhosh Kumar</author>
///<date created>16/5/2008</datecreated>
///<datemodified>16/5/2008</datemodified>
///<modified by>Santhosh Kumar</modified by>
///<no. of classes>1</no. of classes>
///<no. of methods></no. of methods>
/// <summary>
/// Class used do transactions using cookies data
/// </summary>
/// 
#endregion

public partial class frmCookiesTrans : System.Web.UI.Page
{

    // *** Declare the local variables
    int id = 0;
    int oprType = 0;

    protected void Page_Load(object sender, EventArgs e)
    {

            if (Session["UserId"] != null && Session["UserType"] != null && Session["UserType"].ToString().Trim().ToLower() == "admin")
            {

                // *** Retrieve the id from the Query String
                if (Request.QueryString["Id"] != null)
                {

                    // *** Initialize the local variable
                    id = Convert.ToInt32(Request.QueryString["Id"]);

                }

                // *** Retrieve the type of operation to be performed from the query string
                if (Request.QueryString["Oper"] != null)
                {

                    // *** Initialize the local variable
                    oprType = Convert.ToInt32(Request.QueryString["Oper"]);

                }

                // *** Check if the page is been postback
                if (Page.IsPostBack == false)
                {

                    // *** Calling function to setControlState
                    setControlState();

                    // *** Check if operationtype is 0
                    if (oprType != 0)
                    {

                        // *** Calling function to SetDetails
                        SetDetails();

                    }

                }
            }
            else
            {

                Page.ClientScript.RegisterStartupScript(this.GetType(), "relo", "window.opener.location.href=window.opener.location;window.close();", true);
            
            }

    }

    /// <summary>
    /// Function to set the controls its value
    /// </summary>
    private void setControlState()
    {

        // *** Check if oprType is equal to 0
        if (oprType == 0)
        {

            // *** Initialize the controls
            btnCreate.Text = "Create";
            lblTitle.Text = "Cookies - Create";

        }
        else if (oprType == 1)// *** Check if oprType is equal to 1
        {

            // *** Initialize the controls
            btnCreate.Text = "Update";
            lblTitle.Text = "Cookies - Modify";

        }
        else
        {

            // *** Initialize the controls
            btnCreate.Text = "Delete";
            lblTitle.Text = "Cookies - Delete";
            txtDesc.Enabled = false;
            txtCookie.Enabled = false;
            btnCreate.Attributes.Add("onclick", "return confirmation();");

        }

    }

    /// <summary>
    /// Function to set the information from the database
    /// </summary>
    private void SetDetails()
    {

        // *** Declare the local variables
        clsCookies obj = new clsCookies();
        DataSet dsDetails = new DataSet();

        // *** Calling function to retrieve cookies data from the database through clsCookies class
        dsDetails = obj.GetCookieDetails(id);

        // *** Check if dataset is empty
        if (dsDetails != null && dsDetails.Tables.Count > 0 && dsDetails.Tables[0].Rows.Count > 0)
        {

            // *** Initialize the controls
            txtDesc.Text = dsDetails.Tables[0].Rows[0][1].ToString();
            txtCookie.Text = dsDetails.Tables[0].Rows[0][2].ToString();

        }

        // *** Dispose the dataset
        dsDetails.Dispose();
        obj = null;

    }

    /// <summary>
    /// Function to initiate the button click on the pop up window
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnCreate_Click(object sender, EventArgs e)
    {

        // *** Check the oprType value
        if (oprType == 0)
        {

            // *** Calling function for Create
            Create();

        }
        else if (oprType == 1)
        {

            // *** Calling function for Update
            Update();
        }
        else
        {

            // *** Calling function for Delete
            Delete();

        }

        // *** Calling function to close the popup window and return to the main page
        Page.ClientScript.RegisterStartupScript(this.GetType(), "relo", "window.opener.location.href=window.opener.location;window.close();", true);
    
    }

    /// <summary>
    /// Function call when  oprType = 0
    /// </summary>
    private void Create()
    {

        // *** Declare the local variable
        clsCookies obj = new clsCookies();

        // *** calling function to Insert Cookie value into the database
        obj.InsertCookie(txtDesc.Text, txtCookie.Text);
        obj = null;

    }

    /// <summary>
    /// Function call when oprType = 1 
    /// </summary>
    private void Update()
    {

        // *** Declare the local variable
        clsCookies obj = new clsCookies();

        // *** calling function to Update Cookies value into the database
        obj.UpdateCookie(id,txtDesc.Text, txtCookie.Text);
        obj = null;

    }

    /// <summary>
    /// Function call when oprType = 2
    /// </summary>
    private void Delete()
    {

        // *** Declare the local variable
        clsCookies obj = new clsCookies();

        // *** calling function to Delete Cookies value from the database
        obj.DeleteCookie(id);
        obj = null;

    }

}
