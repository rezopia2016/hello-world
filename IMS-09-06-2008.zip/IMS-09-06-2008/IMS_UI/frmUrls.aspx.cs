using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

#region "--Class Description--"
///<classname>Urls class</classname>
///<author>Santhosh Kumar</author>
///<date created>21/5/2008</datecreated>
///<datemodified>21/5/2008</datemodified>
///<modified by>Santhosh Kumar</modified by>
///<no. of classes>1</no. of classes>
///<no. of methods></no. of methods>
/// <summary>
/// Class used to list information in the datagrid and subset operation is performed in this class.
/// </summary>
/// 
#endregion


public partial class frmUrls : System.Web.UI.Page
{

    protected void Page_Load(object sender, EventArgs e)
    {


            // *** Check whether the user is the administrator or a normal user.
            if (Session["UserId"] != null && Session["UserType"] != null && Session["UserType"].ToString().Trim().ToLower() == "admin")
            {

                // *** Check if postback
                if (Page.IsPostBack == false)
                {

                    // *** Calling function to FillDropDowns method
                    FillDropDowns();

                }

                // *** Calling function to FillUrlsList method
                FillUrlsList();

            }
            else
            {

                // *** Redirect to login page when session expires
                Response.Redirect("frmLogin.aspx");

            }
                
    }

    /// <summary>
    /// Function to fill the grid
    /// </summary>
    private void FillUrlsList()
    {

        // *** Declare the objects
        data_Operations objData = new data_Operations();

        // *** Open the database connection
        string strSucess = objData.openConnection();
        
        // *** Check if connection is successfull
        if (strSucess == "success")
        {

            // *** Declare hash table to pass parameters
            Hashtable hsh = new Hashtable();

            // *** Check if some item is selected in the ddlGroup drop down
            if (ddlGroup.SelectedIndex > 0)
            {
              
                hsh.Add("@GroupId", ddlGroup.Text);
           
            }

            // *** Check if some item is selected in the ddlQueue drop down
            if (ddlQueue.SelectedIndex > 0)
            {

                hsh.Add("@QueueId", ddlQueue.Text);

            }

            // *** Check if some item is selected in the ddlRequest drop down
            if (ddlRequest.SelectedIndex > 0)
            {

                hsh.Add("@RequestId", ddlRequest.Text);
            
            }

            // *** Execute the stored procedure
            DataSet ds = objData.getDataSet("ui_Url_List", true, hsh);
            grdDetails.DataSource = ds;
            grdDetails.DataBind();

        }

        // *** Close the databse connection
        objData.closeConnection();

    }

    /// <summary>
    /// Function to bind the grid
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void grdDetails_RowDataBound(object sender, GridViewRowEventArgs e)
    {

        // *** Hide the first column and 7th column
        e.Row.Cells[0].Style.Add("display", "none");
        e.Row.Cells[6].Style.Add("display", "none");
       
        if (e.Row.RowType == DataControlRowType.DataRow)
        {

            // *** Assign the attributes for the grid row
            e.Row.Attributes.Add("onclick", "setSelectedRow('" + grdDetails.ClientID + "'," + e.Row.RowIndex + "); document.getElementById('" + hid_Val.ClientID + "').value = '" + e.Row.Cells[0].Text + "';selRow = " + (e.Row.RowIndex + 1) + ";");
            e.Row.Attributes.Add("onmouseover", "ShowMouseOver(this);");
            e.Row.Attributes.Add("onmouseout", "ShowMouseOut(this);");
        
        }

    }

    /// <summary>
    /// Function to fill the drop downs
    /// </summary>
    private void FillDropDowns()
    {
        // *** Calling function to fill the group drop down
        FillDrop(ddlGroup, "ui_Groups_List", "id", "groupName");

        // *** Calling function to fill the queue drop down
        FillDrop(ddlQueue, "ui_queue_List", "id", "name");

        // *** Calling function to fill the request drop down
        FillDrop(ddlRequest, "ui_RequestType_List", "id", "requestType");
   
    }

    /// <summary>
    /// Function to fill the drop down list
    /// </summary>
    /// <param name="ddl">drop down name</param>
    /// <param name="spName">stored procedure name</param>
    /// <param name="strData">data text field</param>
    /// <param name="strText">data value field</param>
    private void FillDrop(DropDownList ddl, string spName, string strData, string strText)
    {

        // *** Declare an object of type data_Operations
        data_Operations objData = new data_Operations();

        // *** Open the dataase connection
        string strSucess = objData.openConnection();
        
        // *** Check if connection is successfull
        if (strSucess == "success")
        {

            // *** Execute the stored procedure
            DataSet ds = objData.getDataSet(spName, true);

            // *** Fill the drop down and assign datatext field and data value field
            ddl.DataSource = ds;
            ddl.DataTextField = strText;
            ddl.DataValueField = strData;
            ddl.DataBind();

        }

        // *** Close the data connection
        objData.closeConnection();

    }

}
