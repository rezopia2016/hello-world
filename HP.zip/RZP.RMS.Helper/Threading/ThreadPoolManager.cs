﻿//-----------------------------------------------------------------------
// <copyright file="ThreadPoolManager.cs" company="Rezopia">
//     Custom company copyright tag.
// </copyright>
// <summary>This is the ThreadPoolManager class.</summary>
//-----------------------------------------------------------------------

namespace RZP.RMS.Helper
{
    using System;
    using System.Collections.Generic;
    using System.Threading;

    /// <summary>
    /// Thread Pool Manager.
    /// </summary>
    public class ThreadPoolManager
    {
        /// <summary>
        /// The queue Lock.
        /// </summary>
        /// <value>
        /// Queue Lock Value.
        /// </value>
        private object queueLock = new object();

        /// <summary>
        /// Threads List.
        /// </summary>
        /// /// <value>
        /// Threads List Value.
        /// </value>
        private List<IThreadPoolHandler> threadsList = new List<IThreadPoolHandler>();

        /// <summary>
        /// Rest Event List.
        /// </summary>
        /// /// <value>
        /// Rest Event Value.
        /// </value>
        private List<ManualResetEvent> restEvent = new List<ManualResetEvent>();

        /// <summary>
        /// Queue Pool.
        /// </summary>
        /// /// <value>
        /// Queue Pool Value.
        /// </value>
        private Queue<IThreadPoolHandler> queuePool = new Queue<IThreadPoolHandler>();

        
        /// <summary>
        /// Initializes a new instance of the <see cref="ThreadPoolManager"/> class.
        /// </summary>
        public ThreadPoolManager()
        {
            this.MaxThreadPool = 1;
          
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ThreadPoolManager"/> class.
        /// </summary>
        /// <param name="max">The maximum.</param>
        public ThreadPoolManager(int max)
        {
            this.MaxThreadPool = max;
            
        }

        /// <summary>
        /// Gets or sets MaxThreadPool.
        /// </summary>
        /// <value>App AWSSecurityKey.</value>
        public int MaxThreadPool
        {
            get;
            set;
        }

        /// <summary>
        /// Pools the thread handler.
        /// </summary>
        /// <param name="handler">The handler.</param>
        public void PoolThreadHandler(IThreadPoolHandler handler)
        {
            lock (this.queueLock)
            {
                this.queuePool.Enqueue(handler);
            }
        }

        /// <summary>
        /// Gets the pool object.
        /// </summary>
        /// <returns>Returns value.</returns>
        public IThreadPoolHandler GetPoolObject()
        {
            IThreadPoolHandler retobj = null;
            try
            {
                retobj = this.queuePool.Dequeue();
            }
            catch (Exception ex)
            {
                Console.WriteLine(" queuePool is having problem");
                Console.WriteLine(ex.Message);
            }

            return retobj;
        }

        /// <summary>
        /// Stops this instance.
        /// </summary>
        public void Stop()
        {
            try
            {
                foreach (IThreadPoolHandler stp in this.threadsList)
                {
                    stp.Stop();
                }

                foreach (ManualResetEvent et in this.restEvent)
                {
                    et.Reset();
                }

                Thread.Sleep(1000);
                this.restEvent.Clear();
                this.queuePool.Clear();
            }
            catch (Exception ex)
            {
                ////log//
            }
        }

        /// <summary>
        /// Waits this instance.
        /// </summary>
        public void Wait()
        {
            TimeSpan waitTime = new TimeSpan(0, 30, 4);
            WaitHandle.WaitAny(this.restEvent.ToArray(), waitTime);
        }

        /// <summary>
        /// Creates the thread handle.
        /// </summary>
        public virtual bool CreateThreadHandle<T>() where T : ThreadHandler
        {
            try
            {
                for (int i = 0; i < this.MaxThreadPool; i++)
                {
                    ManualResetEvent newEvent = new ManualResetEvent(true);
                    string threadname = string.Format("Thread-{0}", i + 1);
                    ThreadHandler newhandler = (T)Activator.CreateInstance(typeof(T));  
                    newhandler.SetHandler(this, newEvent, threadname);
                    this.threadsList.Add(newhandler);
                    this.restEvent.Add(newEvent);
                    this.PoolThreadHandler(newhandler);
                }
            }
            catch (Exception e)
            {

            }
            return true;
        }
    }
}
