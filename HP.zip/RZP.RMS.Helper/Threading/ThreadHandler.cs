﻿//-----------------------------------------------------------------------
// <copyright file="VoucherConsumer.cs" company="Rezopia">
//     Custom company copyright tag.
// </copyright>
// <summary>This is the VoucherConsumer class.</summary>
//-----------------------------------------------------------------------

namespace RZP.RMS.Helper
{
    using System;
    using System.Threading;
    using System.Diagnostics;
    using log4net;
 
    /// <summary>
    /// Thread Pool Manager.
    /// </summary>
    public abstract  class ThreadHandler : IThreadPoolHandler
    {
        /// <summary>
        /// The log object
        /// </summary>
        private static readonly ILog log = LogManager.GetLogger(typeof(ThreadHandler));

        /// <summary>
        /// The _thread
        /// </summary>
        private Thread _thread;

        /// <summary>
        /// Gets or sets Event.
        /// </summary>
        /// <value>App Event.</value>
        public ManualResetEvent Event
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or sets Event.
        /// </summary>
        /// <value>App Event.</value>
        public string TName
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or sets Event.
        /// </summary>
        /// <value>App Event.</value>
        public object Input
        {
            get;
            set;
        }

        /// <summary>
        /// The is cancel
        /// </summary>
        private bool IsCancel = false;

        /// <summary>
        /// The thread pool
        /// </summary>
        private ThreadPoolManager threadPool;

         public ThreadHandler()
        {

        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ThreadHandler"/> class.
        /// </summary>
        /// <param name="poolmanager">The poolmanager.</param>
        /// <param name="evet">The evet.</param>
        /// <param name="threadname">The threadname.</param>
        public ThreadHandler(ThreadPoolManager poolmanager, ManualResetEvent evet, string threadname)
        {
           SetHandler(poolmanager,evet,threadname);
        }

        public void SetHandler (ThreadPoolManager poolmanager, ManualResetEvent evet, string threadname)
        {
             this.threadPool = poolmanager;
            this.TName = threadname;
            this.Event = evet;
        }

        /// <summary>
        /// Determines whether this instance is alive.
        /// </summary>
        /// <returns></returns>
        public bool IsAlive()
        {
            if (_thread != null)
            {
                return _thread.IsAlive;
            }
            return false;
        }

        /// <summary>
        /// Starts the specified object.
        /// </summary>
        /// <param name="obj">The object.</param>
        /// <returns></returns>
        public bool Start(object obj)
        {
            if (obj == null)
            {
                Console.WriteLine("Thread {0} is not started", TName);
                return false;
            }

            Input = obj;

            if (Event != null)
            {
                Event.Reset();
                _thread = null;
            }

            if (_thread == null)
            {
                this._thread = new Thread(ThreadHandler.ThreadProc);
                _thread.Start(this);
            }
            return true;
        }

        /// <summary>
        /// Stops this instance.
        /// </summary>
        /// <returns></returns>
        public bool Stop()
        {
            if (_thread != null)
            {
                if (_thread.IsAlive)
                {
                    IsCancel = true;
                    _thread.Abort();
                    _thread = null;
                    Console.WriteLine("Thread {0} is removed from thread pool", TName);
                }
            }
            return true;
        }

        /// <summary>
        /// Releases the object.
        /// </summary>
        /// <returns></returns>
        public bool ReleaseObject()
        {
            if (threadPool != null)
            {
                threadPool.PoolThreadHandler(this);
            }

            if (Event != null)
            {
                Event.Set();
            }
            return true;
        }

        /// <summary>
        /// Does the work.
        /// </summary>
        /// <param name="obj">The object.</param>
        public abstract void  DoWork(object obj);
       
        /// <summary>
        /// Threads the proc.
        /// </summary>
        /// <param name="obj">The object.</param>
        public static void ThreadProc(object obj)
        {
            ThreadHandler tobj = (ThreadHandler)obj;
            tobj.DoWork(tobj.Input);
            tobj.ReleaseObject();
        }
    }
}
