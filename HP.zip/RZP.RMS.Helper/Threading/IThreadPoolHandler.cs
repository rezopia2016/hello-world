﻿//-----------------------------------------------------------------------
// <copyright file="IThreadPoolHandler.cs" company="Rezopia">
//     Custom company copyright tag.
// </copyright>
// <summary>This is the IThreadPoolHandler class.</summary>
//-----------------------------------------------------------------------

namespace RZP.RMS.Helper
{
    /// <summary>
    /// IThreadPoolHandler
    /// </summary>
    public interface IThreadPoolHandler
    {
        bool Start(object obj);
        bool Stop();
        bool IsAlive();
    }
}
