﻿using log4net;
using RMS.Adapter.Consumer;
using System;
using System.Collections.Generic;
using System.Linq;

namespace RZP.RMS.Helper
{
    public class RMSTenantInvoker
    {
        protected static ILog log = null;
        protected List<QueueConsumer> tenantConsumerList = new List<QueueConsumer>();

        public int RMSClusterId { get; set; }
        public string RMSClusterName { get; set; }
        public string ServiceName { get; set; }

        protected List<QueueConsumer> TenantConsumerList
        {
            get
            {
                return tenantConsumerList;
            }
            set
            {
                tenantConsumerList = value;
            }
        }

        public RMSTenantInvoker()
        { }

      
        protected virtual bool Initialization<T>(string rmsConfigurationServiceURL, string rmsSystemUrl, string[] tenantsToRegister = null) where T : QueueConsumer
        {
            // initialize the logger.
            log = LogManager.GetLogger("RMSTenantInvoker-" + typeof(T));

            // validate url.
            if (string.IsNullOrEmpty(rmsConfigurationServiceURL))
            {
                log.Warn("RMS Configuration Service URL is empty");
                return false;
            }

            // download the configuration and validate the it.
            List<TenantInfo> tenantList = null;
            try
            {
                tenantList = Utility.GetTenant(rmsConfigurationServiceURL);

                if (tenantList == null || tenantList.Count == 0)
                {
                    log.Warn("Tenants are not found. Tenant list is empty");
                    return false;
                }
            }
            catch (Exception ex)
            {
                log.Error(ex);
                return false;
            }
          
            

            //check whetehr to register all tenants or configured tenants in app.config
            if (tenantsToRegister == null)
            {
                return CreateQueueConsumers<T>(rmsSystemUrl, tenantList);
            }
            else
            {
                //string[] arrTenants = tenantsToRegister.Split(',');

                var filteredTenants = (from tenant in tenantList
                                       join t in tenantsToRegister on tenant.TenantId.ToString().ToLower() equals t.ToLower()
                                       select tenant).ToList();  
              
                return CreateQueueConsumers<T>(rmsSystemUrl, filteredTenants);

            }
        }

        protected bool CreateQueueConsumers<T>(string rmsSystemUrl, List<TenantInfo> tenantList) where T : QueueConsumer
        {
            string ipAddress = Utility.GetIPAddress();
            string machineName = Utility.GetMachineName();
            string version = Utility.GetVersion();


            foreach (var tenant in tenantList)
            {
                tenant.ClusterId = this.RMSClusterId;
                tenant.ClusterName = this.RMSClusterName;
                tenant.ConsumerName = this.ServiceName;
                tenant.IpAddress = ipAddress;
                tenant.MachineName = machineName;
                tenant.ConsumerVersion = version;

                QueueConsumer queue = CreateConsumers<T>(rmsSystemUrl, tenant);
                if (queue != null)
                    tenantConsumerList.Add(queue);
            }

            return true;
        }

        protected virtual T CreateConsumers<T>(string rmsSystemUrl, TenantInfo tenant) where T : QueueConsumer
        { 
            return (T)Activator.CreateInstance(typeof(T), tenant, rmsSystemUrl);
        }

     
     
        public virtual void Start<T>(string ConfigUrl, string rmsSystemUrl, string[] tenantsToRegister=null) where T : QueueConsumer
        {
            if (!Initialization<T>(ConfigUrl, rmsSystemUrl, tenantsToRegister))
            {
                log.Warn("Initialization is failed");
                log.Error("Failed to start all Tenants consumer system");
                return;
            }

            log.Info("Starting all Tenants consumer system");

            foreach (QueueConsumer tenant in tenantConsumerList)
            {
                try
                {
                    tenant.Start();
                }
                catch (Exception ex)
                {
                    log.Error(ex);
                }
            }
        }

        public virtual void Stop()
        {
            log.Info("Stoping all Tenants consumer system");
            foreach (QueueConsumer tenant in tenantConsumerList)
            {
                tenant.Stop();
            }
        }
    }
}
