﻿using RMS.Adapter.Producer;
using System;

namespace RZP.RMS.Helper
{
    public class ConsumerException : RMSMessage
    {
        public string ExceptionMessage { get; set; }
        public ConsumerException(string rmsServiceId, string message)
        {
            CommandType = 3;
            RMSServiceId = rmsServiceId;
            IpAddress = string.Empty;
            ExceptionMessage = message;
        }

        public void Send(string url)
        {
            MessageSender objm = new MessageSender(url, this);
            objm.SendMessage();
        }

        public static bool SendExceptionMessage(string rmsServiceId, string rmsSystemUrl, string message)
        {
            ConsumerException consumerException = new ConsumerException(rmsServiceId, message);
            consumerException.Send(rmsSystemUrl);
            return true;
        }
    }
}
