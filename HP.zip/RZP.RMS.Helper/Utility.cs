﻿using RMS.Adapter.Consumer;
using RMS.Adapter.Producer;
using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Sockets;
using System.Reflection;
using System.Text;

namespace RZP.RMS.Helper
{
    public class Utility
    {
        public static List<TenantInfo> GetTenant(string rmsSystemUrl)
        {
            try
            {
                StringBuilder sb = new StringBuilder();
                using (WebClient client = new WebClient())
                {
                    client.Headers[HttpRequestHeader.ContentType] = "string";
                    client.Encoding = System.Text.Encoding.UTF8;
                    byte[] bytes = client.DownloadData(rmsSystemUrl);
                    sb.Append(System.Text.Encoding.Default.GetString(bytes));
                }

                // string response = sb.ToString();

                if (sb.ToString().Contains("Unsuccessful"))
                    throw new Exception("Failed to get tenant info from RMS service.");

                return MessageSender.ReceiveMessage<List<TenantInfo>>(MessageSender.ReceiveMessage<string>(sb.ToString()));
            }
            catch (Exception)
            {
                throw;
            }
        }

        public static QueueInfo Register(string rmsSystemUrl, string rmsServiceId, TenantInfo tenantInfo)
        {
            try
            {
                RMSRegistration message = new RMSRegistration(rmsServiceId, tenantInfo.IpAddress, tenantInfo.MachineName,
                    tenantInfo.ClusterId, tenantInfo.ClusterName, tenantInfo.ConsumerName, tenantInfo.ConsumerVersion);
                MessageSender messageSender = new MessageSender(rmsSystemUrl, message);
                string response = messageSender.SendMessage();
                return MessageSender.ReceiveMessage<QueueInfo>(MessageSender.ReceiveMessage<string>(response));
            }
            catch (Exception)
            {
                throw;
            }
        }

        public static bool UnRegister(string rmsSystemUrl, string rmsServiceId, string ipAddress)
        {
            try
            {
                RMSUnRegistration message = new RMSUnRegistration(rmsServiceId, ipAddress);
                MessageSender messageSender = new MessageSender(rmsSystemUrl, message);
                string response = messageSender.SendMessage();
                QueueInfo QueueInfo = MessageSender.ReceiveMessage<QueueInfo>(MessageSender.ReceiveMessage<string>(response));
                return QueueInfo.MessageCode == 1;
            }
            catch (Exception)
            {
                throw;
            }
        }

        public static string GetMachineName()
        {
            return Dns.GetHostName();
        }

        public static string GetIPAddress()
        {
            string localIP = string.Empty;
            IPHostEntry host = Dns.GetHostEntry(GetMachineName());
            foreach (IPAddress ip in host.AddressList)
            {
                if (ip.AddressFamily == AddressFamily.InterNetwork)
                {
                    localIP = ip.ToString();
                    break;
                }
            }
            return localIP;
        }

        public static string GetVersion()
        {
            return Assembly.GetEntryAssembly().GetName().Version.ToString();
        }
    }
}
