﻿using RMS.Adapter.Producer;
using System;

namespace RMS.Adapter.Consumer
{
    public class QueueInfo : RMSMessage
    {
        public string QueuePath { get; set; }

        public UInt64 QueueId { get; set; }

        public int State { get; set; }

        public string QueueName { get; set; }

        public string Message { get; set; }

        public int MessageCode { get; set; }

        public QueueInfo()
        { }
    }
}
