﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Messaging;
using System.Threading;

namespace RMS.Adapter.Consumer
{
    public abstract class QueueConsumer : IQueueConsumer
    {
        private static readonly log4net.ILog Log = log4net.LogManager.GetLogger(typeof(QueueConsumer));
        public string QueueName { get; set; }
        public string QueuePath { get; set; }
        protected MessageQueue MQueue = null;

        public QueueConsumer()
        {

        }

        public void Start()
        {
            try
            {
                Init();

                if (string.IsNullOrEmpty(QueuePath))
                    throw new Exception("QueueConsumer throws an exception.", new Exception("Queuename or QueuePath is empty"));

                MQueue = new MessageQueue(QueuePath);
                MQueue.ReceiveCompleted += MessageEventHandler;
                MQueue.BeginReceive();
                Thread.Sleep(500);
            }
            catch(Exception ex)
            {
                Log.Error(ex);
                throw ex;               
            }
        }

        public void Stop()
        {
            OnClose();
            MQueue.Close();
            MQueue.Dispose();
        }

        protected virtual void Init()
        {

        }

        protected virtual void OnClose()
        {

        }

        protected abstract void DoWork(string json);

        protected void MessageEventHandler(object sender, ReceiveCompletedEventArgs e)
        {
            try
            {
              
                MQueue = (MessageQueue)sender;
                MQueue.Formatter = new XmlMessageFormatter(new Type[] { typeof(string) });
                var message = MQueue.EndReceive(e.AsyncResult);
                DoWork(message.Body.ToString());
                MQueue.BeginReceive();
              
            }
            catch (Exception ex)
            {
                Log.Error(ex);
                throw ex;
            }
        }

        protected virtual void CurrentDomain_UnhandledException(object sender, UnhandledExceptionEventArgs e)
        {
            Log.Error(e.ExceptionObject);
            throw (MessageQueueException)e.ExceptionObject;
        }
    }
}
