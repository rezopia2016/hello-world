﻿
namespace RMS.Adapter.Producer
{
    public interface ISerialize
    {
        string Serialize();
    }
}
