﻿
namespace RMS.Adapter.Producer
{
    /// <summary>
    /// Command type Enum
    /// </summary>
    public enum CommandType
    {
        /// <summary>
        /// Register into RMS system
        /// </summary>
        Register = 1,

        /// <summary>
        /// Unregister from RMS system
        /// </summary>
        Unregister = 2,

        /// <summary>
        /// Message to RMS system
        /// </summary>
        Message = 3,
    }
}
