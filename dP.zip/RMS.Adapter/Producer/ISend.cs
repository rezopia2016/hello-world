﻿
namespace RMS.Adapter.Producer
{
    public interface ISend
    {
        string SendMessage();
    }
}
