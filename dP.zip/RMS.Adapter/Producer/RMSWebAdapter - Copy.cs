﻿using HttpWebAdapters;
using HttpWebAdapters.Adapters;
using Newtonsoft.Json;
using System;
using System.IO;
using System.Net;
using System.Runtime.Serialization;
using System.Text;

namespace RMS.Adapter.Producer
{
    public interface ISerialize
    {
        string Serialize();
    }

    [DataContract]
    public abstract class RMSWebAdapter : ISerialize
    {
        [DataMember]
        public int RMSCommandType { get; set; }

        [DataMember]
        public string QueueId { get; set; }

        [DataMember]
        public string RMSMessageType { get; set; }

        public RMSWebAdapter()
        { }

        public RMSWebAdapter(RMSCommandType commandType, string queueId , string rmsMessageType) 
        {
            this.RMSCommandType = (int)commandType;
            this.QueueId = queueId;
            this.RMSMessageType = rmsMessageType;
        }

        public string Serialize()
        {
            return JsonConvert.SerializeObject(this);
        }
    }

    public interface ISend
    {
        bool SendMessage();
    }

    public class MessageSender : ISend
    {
        private string _rmsSystemURL;
        private ISerialize _message;

        public MessageSender()
        {
        }

        public MessageSender(string rmsSystemURL, ISerialize message)
        {
            this._rmsSystemURL = rmsSystemURL;
            this._message = message;
        }

        public bool SendMessage()
        {
            Post(this._message.Serialize());
            return true;
        }

        public static T ReceiveMessage<T>(string json)
        {
            return JsonConvert.DeserializeObject<T>(json);
        }

        private void Post(string postData)
        {
            // create web response
            var request = new HttpWebRequestAdapter((HttpWebRequest)WebRequest.Create(this._rmsSystemURL));
            // add the header
            request.Method = HttpWebRequestMethod.POST;
            // should keep the connection alive until getting response
            request.KeepAlive = true;
            // to reduce network data transfer size
            request.AutomaticDecompression = DecompressionMethods.Deflate | DecompressionMethods.GZip;
            // convert postdata to bitearray
            byte[] byteArray = Encoding.UTF8.GetBytes(string.Format("={0}", postData));
            // set the content type
            request.ContentType = "application/x-www-form-urlencoded";
            // set the content length
            request.ContentLength = byteArray.Length;
            // write to request
            using (var requeststream = request.GetRequestStream())
            {
                requeststream.Write(byteArray, 0, byteArray.Length);
            }
            // get response
            using (var response = request.GetResponse())
            {
                using (var responseStream = response.GetResponseStream())
                // encode the response with UTF8
                using (var reader = new StreamReader(responseStream, TryGetEncoding(response)))
                {
                    // read the response.
                    reader.ReadToEnd();
                }
            }
        }

        private Encoding TryGetEncoding(IHttpWebResponse response)
        {
            try
            {
                return Encoding.GetEncoding(response.CharacterSet);
            }
            catch
            {
                return Encoding.UTF8;
            }
        }
    }

    public enum RMSCommandType
    {
        Register = 1,
        Unregister = 2,
        Message = 3,
    }
}
