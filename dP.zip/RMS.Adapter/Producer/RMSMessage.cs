﻿using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;
using System;
using System.Reflection;
using System.Runtime.Serialization;

namespace RMS.Adapter.Producer
{
    /// <summary>
    /// The data transfer object that holds RMS message body.
    /// </summary>
    public abstract class RMSMessage : ISerialize
    {
        private static readonly log4net.ILog Log = log4net.LogManager.GetLogger(typeof(RMSMessage));
        /// <summary>
        /// The command type
        /// </summary>
        public int CommandType { get; set; }

        /// <summary>
        /// The RMS message queue name
        /// </summary>
        public string RMSServiceId { get; set; }

        /// <summary>
        /// The ip address of the client
        /// </summary>
        public string IpAddress { get; set; }

        /// <summary>
        /// The machine name of the client
        /// </summary>
        public string MachineName { get; set; }

        /// <summary>
        /// The cluster id
        /// </summary>
        public int ClusterId { get; set; }

        /// <summary>
        /// The cluster name
        /// </summary>
        public string ClusterName { get; set; }

        /// <summary>
        /// Consumer system name
        /// </summary>
        public string ConsumerName { get; set; }

        /// <summary>
        /// Consumer version
        /// </summary>
        public string ConsumerVersion { get; set; }

        /// <summary>
        /// Constructor
        /// </summary>
        public RMSMessage()
        { }

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="commandType">Command Type</param>
        /// <param name="rmsServiceId">RMS Service Id</param>
        /// <param name="ipAddress">Ip Address</param>
        public RMSMessage(string rmsServiceId, string ipAddress)
        {
            this.CommandType = 3;
            this.RMSServiceId = rmsServiceId;
            this.IpAddress = ipAddress;
        }


        public RMSMessage(string rmsServiceId, string ipAddress, string machineName, int clusterId, string clusterName, string consumerName, string consumerVersion)
            : this(rmsServiceId, ipAddress)
        {
            this.MachineName = machineName;
            this.ClusterId = clusterId;
            this.ClusterName = clusterName;
            this.ConsumerName = consumerName;
            this.ConsumerVersion = consumerVersion;
        }

        /// <summary>
        /// Serialize the message body to json string
        /// </summary>
        /// <returns>Json string</returns>
        public string Serialize()
        {
            try
            {
#if DEBUG
                return JsonConvert.SerializeObject(this, Formatting.Indented);
#else
            return JsonConvert.SerializeObject(this);
#endif
            }
            catch (Exception ex)
            {
                Log.Error(ex);
                return string.Empty;
            }
        }
    }

    public class RMSRegistration : RMSMessage
    {
        public RMSRegistration(string rmsServiceId, string ipAddress, string machineName, int clusterId, string clusterName, string consumerName, string consumerVersion)
            : base(rmsServiceId, ipAddress, machineName, clusterId, clusterName, consumerName, consumerVersion)
        {
            this.CommandType = 1;
        }
    }

    public class RMSUnRegistration : RMSMessage
    {
        public RMSUnRegistration(string rmsServiceId, string ipAddress)
        {
            this.CommandType = 2;
            this.RMSServiceId = rmsServiceId;
            this.IpAddress = ipAddress;
        }
    }
}
