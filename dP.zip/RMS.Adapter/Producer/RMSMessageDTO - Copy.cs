﻿using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;
using System;
using System.Reflection;
using System.Runtime.Serialization;

namespace RMS.Adapter.Producer
{
    /// <summary>
    /// The data transfer object that holds RMS message body.
    /// </summary>
    public abstract class RMSMessageDTO : ISerialize
    {
        /// <summary>
        /// The command type
        /// </summary>
        public int CommandType { get; set; }

        /// <summary>
        /// The RMS message queue name
        /// </summary>
        public string RMSServiceId { get; set; }

        /// <summary>
        /// The ip address of the client
        /// </summary>
        public string IpAddress { get; set; }

        /// <summary>
        /// Constructor
        /// </summary>
        public RMSMessageDTO()
        { }

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="commandType">Command Type</param>
        /// <param name="rmsServiceId">RMS Service Id</param>
        /// <param name="ipAddress">Ip Address</param>
        public RMSMessageDTO(CommandType commandType, string rmsServiceId, string ipAddress)
        {
            this.CommandType = (int)commandType;
            this.RMSServiceId = rmsServiceId;
            this.IpAddress = ipAddress;
        }

        /// <summary>
        /// Serialize the message body to json string
        /// </summary>
        /// <returns>Json string</returns>
        public string Serialize()
        {
#if DEBUG
            return JsonConvert.SerializeObject(this, Formatting.Indented, new JsonSerializerSettings { ContractResolver = new AllPropertiesResolver() });
#else
            return JsonConvert.SerializeObject(this, new JsonSerializerSettings { ContractResolver = new AllPropertiesResolver() });
#endif
        }
    }

    /// <summary>
    /// The data contract resolver
    /// </summary>
    class AllPropertiesResolver : DefaultContractResolver
    {
        /// <summary>
        /// Create memberwise property
        /// </summary>
        /// <param name="member">Member</param>
        /// <param name="memberSerialization">Member serialization</param>
        /// <returns>Json property</returns>
        protected override JsonProperty CreateProperty(MemberInfo member, MemberSerialization memberSerialization)
        {
            // create the json property
            JsonProperty property = base.CreateProperty(member, memberSerialization);
            // ignore the contract
            property.Ignored = false;
            // return the property
            return property;
        }
    }
}
