﻿using HttpWebAdapters;
using Newtonsoft.Json;
using System;
using System.Net;
using System.Text;

namespace RMS.Adapter.Producer
{
    /// <summary>
    /// The message helper
    /// </summary>
    public class MessageSender : ISend
    {
        private static readonly log4net.ILog Log = log4net.LogManager.GetLogger(typeof(MessageSender));
        private string _rmsSystemURL;
        private ISerialize _message;

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="rmsSystemURL">RMS system url</param>
        /// <param name="message">Message that to be sent to rms</param>
        public MessageSender(string rmsSystemURL, ISerialize message)
        {
            this._rmsSystemURL = rmsSystemURL;
            this._message = message;
        }

        /// <summary>
        /// Send the message to rms system
        /// </summary>
        /// <returns></returns>
        public string SendMessage()
        {
            try
            {
                return Post(this._message.Serialize());
            }
            catch (Exception ex)
            {
                Log.Error(ex);
                return string.Empty;
            }
        }

        /// <summary>
        /// Descrialize the message of rms
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="json"></param>
        /// <returns></returns>
        public static T ReceiveMessage<T>(string json)
        {
            return JsonConvert.DeserializeObject<T>(json);
        }

        //private string Post(string postData)
        //{
        //    // create web response
        //    var request = new HttpWebAdapters.Adapters.HttpWebRequestAdapter((HttpWebRequest)WebRequest.Create(this._rmsSystemURL));
        //    // add the header
        //    request.Method = HttpWebRequestMethod.POST;
        //    // should keep the connection alive until getting response
        //    request.KeepAlive = true;
        //    // to reduce network data transfer size
        //    request.AutomaticDecompression = DecompressionMethods.Deflate | DecompressionMethods.GZip;
        //    // convert postdata to bitearray
        //    byte[] byteArray = Encoding.UTF8.GetBytes(string.Format("{0}", postData));
        //    // set the content type
        //    request.ContentType = "application/json; charset=utf-8";
        //    // set the content length
        //    request.ContentLength = byteArray.Length;
        //    // write to request
        //    using (var requeststream = request.GetRequestStream())
        //    {
        //        requeststream.Write(byteArray, 0, byteArray.Length);
        //    }
        //    // get response
        //    using (var response = request.GetResponse())
        //    {
        //        using (var responseStream = response.GetResponseStream())
        //        // encode the response with UTF8
        //        using (var reader = new System.IO.StreamReader(responseStream, TryGetEncoding(response)))
        //        {
        //            // read the response.
        //            return reader.ReadToEnd();
        //        }
        //    }
        //}

        /// <summary>
        /// Post the message to the url
        /// </summary>
        /// <param name="postData">Json data</param>
        private string Post(string postData)
        {
            try
            {
                using (WebClient client = new WebClient())
                {
                    client.Headers[HttpRequestHeader.ContentType] = "string";
                    client.Encoding = System.Text.Encoding.UTF8;
                    return client.UploadString(this._rmsSystemURL, "POST", postData);
                }
            }
            catch (Exception ex)
            {
                Log.Error(ex);
                throw ex;
            }
        }

        /// <summary>
        /// Encoding
        /// </summary>
        /// <param name="response">IHttpWebResponse</param>
        /// <returns>Type of encoding</returns>
        private Encoding TryGetEncoding(IHttpWebResponse response)
        {
            try
            {
                return Encoding.UTF8;
            }
            catch
            {
                return Encoding.UTF8;
            }
        }
    }
}
