using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.ServiceProcess;
using System.Text;
using System.Timers;
using System.Data.SqlClient;
using IMS_QueueManager;
using System.Collections;
using System.Net;
using System.Net.Mail;
using System.Configuration;

namespace IMS_Notification
{
    public partial class Notifier : ServiceBase
    {

        // *** Local Variables to handle Data Operations
        DataSet dsUsers = new DataSet();
        data_Operations db = new data_Operations();
        String conn = "";
        string cmd = "";


        // *** Variable to hold Users Count
        int totalUsers = 0;
        clsUsers[] Users = null;


        // *** Initialize a Timer Object
        System.Timers.Timer timer = new System.Timers.Timer();


        public Notifier()
        {
            InitializeComponent();
        }

        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        static void Main()
        {
            ServiceBase[] ServicesToRun;

            // More than one user Service may run within the same process. To add
            // another service to this process, change the following line to
            // create a second service object. For example,
            //
            //   ServicesToRun = new ServiceBase[] {new Service1(), new MySecondUserService()};
            //
            ServicesToRun = new ServiceBase[] { new Notifier() };

            ServiceBase.Run(ServicesToRun);
        }

        protected override void OnStart(string[] args)
        {
           
            // TODO: Add code here to start your service.

            // *** Handle Elapsed Event
            timer.Elapsed += new ElapsedEventHandler(OnElapsedTime);

            // *** Set Interval to 2 minutes
            timer.Interval = 120000;

            // *** Enabling Timer
            timer.Enabled = true;

        }

        protected override void OnStop()
        {
            // TODO: Add code here to perform any tear-down necessary to stop your service.
        }

        private void OnElapsedTime(object source, ElapsedEventArgs e)
        {

            // *** Stop the Timer
            timer.Stop();

            // *** Run the notifier to send email and sms to the concerned user who has subscribed to the url
            Notifier notify = new Notifier();

            // *** Call the GetUsersFromDB using Notifier object
            notify.GetUsersFromDB();

            // *** Handle Emails here
            notify.handleEmail();

            // *** Start the Timer
            timer.Start();

        }

        /// <summary>
        /// Function to get all the User Details from the Database
        /// </summary>
        public void GetUsersFromDB()
        {

            // *** Open a database connection
            conn = db.openConnection();

            // *** Check if connection is successful or not
            if (conn == "success")
            {

                // *** Stored Procedure to retrieve user information
                cmd = "notifier_GetUsers";

                // *** Retrive the User Details onto the dataset
                dsUsers = db.getDataSet(cmd, false);

            }

            // *** Close the database connection
            db.closeConnection();


            // *** Initialize the totalUsers variable to the number of users available in the dataset
            totalUsers = dsUsers.Tables[0].Rows.Count;

            // *** Dynamically create an array of Users
            Users = new clsUsers[totalUsers];

            // *** For loop to iterate the users
            for (int i = 0; i < totalUsers; i++)
            {

                // *** Call the clsUsers constructor and initialize its properties
                Users[i] = new clsUsers(Convert.ToInt32(dsUsers.Tables[0].Rows[i]["id"]), dsUsers.Tables[0].Rows[i]["userName"].ToString(), dsUsers.Tables[0].Rows[i]["emailAddress"].ToString(), 0);

            }

        }

        /// <summary>
        /// Function to handle Email and formulate the body of an email based on the 
        /// number of events.Send Email to the concerned User Email Address.
        /// </summary>
        public void handleEmail()
        {

            // *** Initialize the local variables
            int i = 0;
            int highestID = 0;
            string htmlBody = "";
            bool doSend = false;
            bool bg = false;

            // *** Iterate through the  number of Users retrieved from the Database.
            for (i = 1; i <= totalUsers; i++)
            {

                doSend = false;
                highestID = 0;
                htmlBody = "<HTML><BODY style='font-family:Verdana;font-size:9pt'>" + "\r\n";

                DataSet ds = new DataSet();

                // *** Open a database connection
                conn = db.openConnection();

                // *** Check if connection is successful or not
                if (conn == "success")
                {

                    Hashtable param = new Hashtable();
                    param.Add("@users_id", Users[i - 1].userId.ToString());

                    // *** Stored Procedure to get the Events details to be mailed to the concerned User
                    cmd = "notifier_GetEvents";

                    // *** Retrieve the Events Details into the dataset
                    ds = db.getDataSet(cmd, true, param);

                }

                // *** Close the database connection
                db.closeConnection();

                // *** Check if dataset is empty or not
                if (ds.Tables[0].Rows.Count > 0)
                {

                    //then alert list is not empty

                    doSend = true;

                    // *** Formulate the html body
                    htmlBody = htmlBody + "<B>Recent URL Events:</B> The following table lists changes to URL alerts, since last e-mail notification was sent to you. ";
                    htmlBody = htmlBody + "Click a specific URL for additional information.<BR><BR>" + "\r\n";
                    htmlBody = htmlBody + "<TABLE border=1 cellspacing=0 align=Center rules=all style='background-color:#EEEEEE;font-family:Verdana;font-size:9pt;width:100%;border-collapse:collapse;'>" + "\r\n";
                    htmlBody = htmlBody + "  <TR align=center style='color:White;background-color:#000080;font-weight:bold;'>" + "\r\n";

                    // *** Retrive the column names
                    foreach (DataColumn field in ds.Tables[0].Columns)
                    {


                        htmlBody = htmlBody + "    <TH>" + field.ColumnName.ToString() + "</TH>" + "\r\n";

                    }

                    htmlBody = htmlBody + "</TR>" + "\r\n";

                    // *** This field is used to assign alternate colors for each row of the table body
                    bg = false;

                    int k = 0;

                    // *** This loop is used to check whether all the rows are added to the body
                    while (k < ds.Tables[0].Rows.Count)
                    {

                        // *** Check if current id is the highest event id
                        if (Convert.ToInt32(ds.Tables[0].Rows[k][0]) > highestID)
                        {

                            // ***  Assign the highest Event id based on the iteration
                            highestID = Convert.ToInt32(ds.Tables[0].Rows[k][0]);

                        }

                        htmlBody = htmlBody + "  <TR";

                        // *** Setting bg color
                        if (bg == true)
                        {

                            htmlBody = htmlBody + " style='background-color:White;'";


                        }
                        else
                        {

                        }

                        // *** Alternating bg color
                        if (bg == true)
                        {

                            bg = false;

                        }
                        else
                        {

                            bg = true;

                        }

                        htmlBody = htmlBody + ">" + "\r\n";

                        // *** Formulate the table rows
                        for (int m = 0; m < ds.Tables[0].Columns.Count; m++)
                        {

                            htmlBody = htmlBody + "    <TD>" + ds.Tables[0].Rows[k][m].ToString() + "</TD>" + "\r\n";

                        }

                        k++;
                        htmlBody = htmlBody + "</TR>" + "\r\n";

                    }

                    // *** Close the table
                    htmlBody = htmlBody + "</TABLE>" + "\r\n" + "<BR>" + "\r\n";

                }

                // *** Close the body 
                htmlBody = htmlBody + "</BODY></HTML>" + "\r\n";

                // *** Check id doSend parameter is true
                if (doSend == true)
                {

                    // *** Calling function to Send Email
                    SendEmail(Users[i - 1].useremailAddress, "URL Monitoring Alert(s)", htmlBody);

                    // *** Increment useremailSend
                    Users[i - 1].useremailSend = Users[i - 1].useremailSend + 1;

                    // *** set last event notified for this user

                    // *** Open the database connection
                    conn = db.openConnection();

                    // *** Check If connection is success
                    if (conn == "success")
                    {

                        // *** Store Procedure to update the last Event notified id
                        cmd = "notifier_mailSent";
                        Hashtable param = new Hashtable();
                        param.Add("@users_id", Users[i - 1].userId);
                        param.Add("@highestId", highestID);

                        // *** Execute the Stored Procedure and update the last Event Notified
                        int lastEventNotify = db.executeQuery(cmd, true, param);

                    }

                    // *** Close the database connection
                    db.closeConnection();

                }


            }


        }

        /// <summary>
        /// Function to Send Email to the concerned User
        /// </summary>
        /// <param name="mailTo">To Address</param>
        /// <param name="subject">Subject of the Email</param>
        /// <param name="body">Email Body</param>
        private void SendEmail(string mailTo, string subject, string body)
        {

            try
            {
                //create the mail message
                MailMessage mail = new MailMessage();

                //mail.From = new MailAddress("admin@infomeda.com", "Santhosh Kumar");
                // *** set the addresses to which Email has to be send
                mail.To.Add(mailTo);

                // *** Test Email id
                mail.CC.Add("santhosh_jits@mail.com");

                // *** set the content like subject and body 
                mail.Subject = subject;
                mail.Body = body;
                mail.IsBodyHtml = true;

                // *** send the message - Create an Smtp Client object
                //SmtpClient smtp = new SmtpClient(mMailSettings.Smtp.Network.Host, mMailSettings.Smtp.Network.Port);
                SmtpClient smtp = new SmtpClient();

                // *** To authenticate we set the username and password properites on the SmtpClient
                smtp.Credentials = new NetworkCredential(ConfigurationManager.AppSettings["smtpUsername"].ToString(), ConfigurationManager.AppSettings["smtpPassword"].ToString());

                // *** Send an email
                smtp.Send(mail);

            }

            // *** Exception Handler
            catch (Exception ex)
            {
                Exception ex2 = ex;
                string errorMessage = string.Empty;

                while (ex2 != null)
                {

                    errorMessage += ex2.ToString();
                    ex2 = ex2.InnerException;

                }


            }

        }
        

    }
}
