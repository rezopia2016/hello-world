namespace IMS_Notification
{
    partial class ProjectInstaller
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.notifierProcessInstaller1 = new System.ServiceProcess.ServiceProcessInstaller();
            this.notifierInstaller1 = new System.ServiceProcess.ServiceInstaller();
            // 
            // notifierProcessInstaller1
            // 
            this.notifierProcessInstaller1.Account = System.ServiceProcess.ServiceAccount.LocalService;
            this.notifierProcessInstaller1.Password = null;
            this.notifierProcessInstaller1.Username = null;
            // 
            // notifierInstaller1
            // 
            this.notifierInstaller1.DisplayName = "Notification Service To Send Email and SMS";
            this.notifierInstaller1.ServiceName = "Notifier Service";
            this.notifierInstaller1.StartType = System.ServiceProcess.ServiceStartMode.Automatic;
            // 
            // ProjectInstaller
            // 
            this.Installers.AddRange(new System.Configuration.Install.Installer[] {
            this.notifierProcessInstaller1,
            this.notifierInstaller1});

        }

        #endregion

        private System.ServiceProcess.ServiceProcessInstaller notifierProcessInstaller1;
        private System.ServiceProcess.ServiceInstaller notifierInstaller1;
    }
}