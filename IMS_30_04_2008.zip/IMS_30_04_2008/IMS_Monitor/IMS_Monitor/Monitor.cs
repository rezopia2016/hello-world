using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.ServiceProcess;
using System.Text;
using System.Timers;
using IMS_QueueManager;
using System.Threading;


#region "--Class Description--"
///<classname>Internet Monitoring System - Windows Service</classname>
///<author>Santhosh Kumar</author>
///<date created>26/3/2008</datecreated>
///<datemodified>17/4/2008</datemodified>
///<modified by>Santhosh Kumar</modified by>
///<no. of classes>1</no. of classes>
///<no. of methods></no. of methods>
/// <summary>
/// This Windows Service is used to retrieve the Queues from the database.
/// Create Individual Threads for the Queues retrieved at a perticular time.
/// Samples the Urls of each Queue.
/// Retrieve the nextRunTime of the Queue and stores in the database.
/// and Kills the thread.This is a continuous process
/// </summary>
/// 
#endregion

namespace IMS_Monitor
{

    #region "----Monitor Class----"

    partial class Monitor : ServiceBase
    {



        // *** Global Variable Declaration for Data Operation - 08/04/2008
        DataSet dsQueue = new DataSet();
        data_Operations db = new data_Operations();
        String conn = "";
        String cmd = "";

        // *** Queue Active Check Variable
        static int qCount = 0;


        /// <summary>
        /// Declare an array of objects for Queue Operations
        /// </summary>
        Monitor[] instance = new Monitor[30];

        

        /// <summary>
        /// Thread Variables
        /// </summary>
        /// <param name="obj"></param>
        Thread[] ThreadArray = null;


        // *** Initialize a Timer Object
        System.Timers.Timer timer = new System.Timers.Timer();


        public Monitor()
        {
            InitializeComponent();
        }

        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        static void Main()
        {
            ServiceBase[] ServicesToRun;

            // More than one user Service may run within the same process. To add
            // another service to this process, change the following line to
            // create a second service object. For example,
            //
            //   ServicesToRun = new ServiceBase[] {new Service1(), new MySecondUserService()};
            //
            ServicesToRun = new ServiceBase[] { new Monitor() };

            ServiceBase.Run(ServicesToRun);
        }

        protected override void OnStart(string[] args)
        {
           

            // TODO: Add code here to start your service.
           
            // *** Handle Elapsed Event
            timer.Elapsed += new ElapsedEventHandler(OnElapsedTime);

            // *** Set Interval to 2 minutes
            timer.Interval = 120000;

            // *** Enabling Timer
            timer.Enabled = true;
        }

        private void OnElapsedTime(object source, ElapsedEventArgs e) 
        {
            
            // *** Stop the Timer
            timer.Stop();

            // *** Run the Queue Manager and Sampe the Urls - Entry Point
            Monitor qMgr = new Monitor();

            // *** Call the GetQueuesFromDB using Monitor object
            qMgr.GetQueuesFromDB();
            
            // *** Start the Timer
            timer.Start();
        }

        protected override void OnStop()
        {
            // TODO: Add code here to perform any tear-down necessary to stop your service.
        }

        /// <summary>
        /// 
        /// </summary>
        public void GetQueuesFromDB()
        {
            
            // *** Local variable Declaration for Data Operations
            DataSet dsQueue = new DataSet();
            data_Operations db = new data_Operations();

            // *** Open a database connection
            conn = db.openConnection();

            // *** check if connection is established or not
            if (conn == "success")
            {
               
                // *** Initialize the stored procedure
                cmd = "sampler_GetQueueList";

                // *** Execute the Stored Procedure and retrieve the Queues into the Dataset
                dsQueue = db.getDataSet(cmd, true);

            }

            //close a database connection
            db.closeConnection();

            // *** Check number of Active Queues in the database
            qCount = dsQueue.Tables[0].Rows.Count;

            // *** Create an array of objects of MyWorkerThread Class dynamicall using the count from the dataset
            MyWorkerThread[] ob = new MyWorkerThread[qCount];

            // *** Initialize the objects of MyWorkerThread
            for (int i = 0; i < qCount; i++)
            {

                ob[i] = new MyWorkerThread(dsQueue.Tables[0].Rows[i][0].ToString());

            }


            // *** Declare an array of threads based on the active Queue in the database to be worker threads.
            ThreadArray = new Thread[dsQueue.Tables[0].Rows.Count];




            // *** Creating Thread instances and placing the instance objects QueueFirstRun function
            // *** to be the main function of each thread and setting the attributes value for each Queue
            // ** and start the thread
            for (int i = 0; i < qCount; i++)
            {

                // *** Create a thread and point it to Run function of the worker thread
                ThreadArray[i] = new Thread(ob[i].Run);

                // *** Make the Thread to run as the Background thread
                ThreadArray[i].IsBackground = true;

                // *** Start the Thread
                ThreadArray[i].Start();

            }

            // *** Call the WaitForThreadToStart function for each object Created
            for (int i = 0; i < qCount; i++)
            {

                // *** Calling Function
                ob[i].WaitForThreadToStart();

            }


            // *** Call the KillThread function for each object
            for (int i = 0; i < qCount; i++)
            {

                ob[i].KillThread();

            }
        
        }


    }

    #endregion

}
