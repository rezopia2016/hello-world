namespace IMS_Monitor
{
    partial class ProjectInstaller
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.monitorProcessInstaller1 = new System.ServiceProcess.ServiceProcessInstaller();
            this.monitorInstaller = new System.ServiceProcess.ServiceInstaller();
            // 
            // monitorProcessInstaller1
            // 
            this.monitorProcessInstaller1.Account = System.ServiceProcess.ServiceAccount.LocalService;
            this.monitorProcessInstaller1.Password = null;
            this.monitorProcessInstaller1.Username = null;
            // 
            // monitorInstaller
            // 
            this.monitorInstaller.Description = "Queue Manager to Handle the Queue Handler";
            this.monitorInstaller.DisplayName = "Monitor";
            this.monitorInstaller.ServiceName = "Monitor";
            // 
            // ProjectInstaller
            // 
            this.Installers.AddRange(new System.Configuration.Install.Installer[] {
            this.monitorProcessInstaller1,
            this.monitorInstaller});

        }

        #endregion

        private System.ServiceProcess.ServiceProcessInstaller monitorProcessInstaller1;
        private System.ServiceProcess.ServiceInstaller monitorInstaller;
    }
}