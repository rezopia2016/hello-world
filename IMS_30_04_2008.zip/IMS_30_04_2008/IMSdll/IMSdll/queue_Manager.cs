using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.Collections;


#region "--Class Description--"
///<classname>Queue Manager Operations</classname>
///<author>Santhosh Kumar</author>
///<date created>26/03/2008</datecreated>
///<datemodified>09/04/2008</datemodified>
///<modified by>Santhosh Kumar</modified by>
///<no. of classes></no. of classes>
///<no. of methods></no. of methods>

/// <summary>
/// This class contains the methods for the overall activities of the Queue Operations.
/// It includes enqueue() - get into the line 
/// dequeue() - pull first object from the line
/// peek() - to traverse the object
/// count property - to count the number of items in the queue
/// based on these activities we pull the information from the sql database and include it 
/// in the coding part.
/// </summary>

#endregion



namespace IMS_QueueManager
{
    #region "----clsQueues Class----"
    /// <summary>
    /// clsQueues class is mainly used to initialize the variables within its objects for manipulation 
    /// purpose.It contains six variables and an instance constructor and six properties.This holds the content of an
    /// object in a queue
    /// </summary>
    /// 


    public class clsQueues
    {
        /// <summary>
        /// Declare the local variables for the clsQueues class
        /// </summary>
        private int id;
        private string name;
        private int process;
        private string nextRun;
        private string runSince;
        private bool enabled;

        /// <summary>
        /// Default constructor
        /// </summary>
        public clsQueues() { }

        /// <summary>
        /// Instantiate the local varibles from the calling function
        /// </summary>
        /// <param name="queueId">queue id from the database</param>
        /// <param name="queueName">queue name for the specified id</param>
        /// <param name="queueProcess">handles the queue handler</param>
        /// <param name="queueNextRun">time specifies when the queue has to run again</param>
        /// <param name="queueRunSince">time specify when the queue started running</param>
        /// <param name="queueEnabled">boolean function which specifies wheter the queue is enabled to run or not</param>
        public clsQueues(int queueId,
                          string queueName,
                            int queueProcess,
                                string queueNextRun,
                                    string queueRunSince,
                                        bool queueEnabled)
        {

            id = queueId;
            name = queueName;
            process = queueProcess;
            nextRun = queueNextRun;
            runSince = queueRunSince;
            enabled = queueEnabled;


        }

        /// <summary>
        /// Property to set the queueId
        /// </summary>
        public int queueId
        {
            get { return id; }
            set { id = value; }
        }

        /// <summary>
        /// Property to set and get the queueName
        /// </summary>
        public string queueName
        {
            get { return name; }
            set { name = value; }
        }

        /// <summary>
        /// Property to set and get the queueProcess
        /// </summary>
        public int queueProcess
        {
            get { return process; }
            set { process = value; }
        }

        /// <summary>
        /// Property to set and get the queueNextRun
        /// </summary>
        public string queueNextRun
        {
            get { return nextRun; }
            set { nextRun = value; }
        }

        /// <summary>
        /// Property to get and set the queueRunSince
        /// </summary>
        public string queueRunSince
        {
            get { return runSince; }
            set { runSince = value; }
        }

        /// <summary>
        /// Property to get and set the queueEnabled
        /// </summary>
        public bool queueEnabled
        {
            get { return enabled; }
            set { enabled = value; }
        }

    }

    #endregion

    #region "----queue_Manager Class----"
    /// <summary>
    /// queue_Manager contains the variable declaration for Queues and all the 
    /// queue objects are part of this qManager variable of type Queue.
    /// </summary>
    public class queue_Manager
    {

        public Queue qManager = new Queue();

    }

    #endregion
}
