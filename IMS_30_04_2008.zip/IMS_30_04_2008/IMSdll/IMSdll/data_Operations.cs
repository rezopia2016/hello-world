using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.Collections;


#region "--Class Description--"
///<classname>Data Operations</classname>
///<author>Santhosh Kumar</author>
///<date created>26/3/2008</datecreated>
///<datemodified>17/4/2008</datemodified>
///<modified by>Santhosh Kumar</modified by>
///<no. of classes>1</no. of classes>
///<no. of methods>8</no. of methods>

/// <summary>
/// This class contains the methods for the data base functionalites.
/// its incudes methods for database connection to be opened, connection to be closed.
/// and also get the datas throught datareader or dataset and execute the queries based on the query send by
/// the user.
/// </summary>

#endregion

namespace IMS_QueueManager
{

    #region "----1) Data Operations Class----"
    /// <summary>
    /// Data Operations Class to simplify ADO.Net Operations
    /// </summary>
    public class data_Operations 
    {
        //Decare a variable to open a database connection
        SqlConnection con;

        //default constructor to instantiate the connection
        public data_Operations()
        {
            con = new SqlConnection(ConfigurationManager.ConnectionStrings["conStr"].ConnectionString);

        }

        #region "----1) Method to Open a database connectivity----"
        /// <summary>
        /// method to open the database connection
        /// </summary>
        /// <returns>string value "success" if connection is established else an exception</returns>
        /// 
        public string openConnection()
        {

            try
            {
              
                //call the open method of the connection to open the database connection
                con.Open();

                //if the connection returned successfully, then we return true to the called fucnction
                return "success";

            }
            catch (Exception ex)
            {

                return ex.Message;

            }
        }
        #endregion

        #region "----2) Method to close the database connection----"
        /// <summary>
        /// method to close the database connection
        /// </summary>
        public void closeConnection()
        {

            // *** Close the Connection 
            con.Close();
                        
        }
        #endregion

        #region "----3) Method to retrieve the DataReader by passing the query directly----"
        /// <summary>
        /// by executing the command and get the datareader
        /// </summary>
        /// <param name="command">select query to get the datareader</param>
        /// <param name="Is_StoredProedure">a boolean value to check whether the  query is a stored procdure or normal command</param>
        /// <returns>datareader</returns>
        public SqlDataReader getDataReader(string command, Boolean Is_StoredProedure)
        {

            try
            {

                SqlDataReader dReader = null;

                //check the state of the connection
                if (con.State == ConnectionState.Open)
                {

                    SqlCommand cmd = new SqlCommand();
                    cmd.CommandText = command;
                    cmd.Connection = con;

                    //to check the type of command
                    if (Is_StoredProedure == true)
                    {

                        cmd.CommandType = CommandType.StoredProcedure;

                    }
                    else
                    {

                        cmd.CommandType = CommandType.Text;

                    }
                    //exeute the query and get the resultset in the datareader
                    dReader = cmd.ExecuteReader();

                    // *** Dispose the command Object - 05/04/2008
                    cmd.Dispose();

                }

                return dReader;

            }
            catch
            {
                //if there is a execption, we will return the null value to the calling method
                return null;

            }

        }
        #endregion

        #region "----4) Method to retieve the datareader by passing the stored procedures name and parameters----"
        /// <summary>
        /// executing the stored procedure and get the datareder
        /// </summary>
        /// <param name="command">select query</param>
        /// <param name="Is_StoredProedure">to set whether its a ordinary command or stred procedure</param>
        /// <param name="Param">hashtable to hold the parametes for to execute the  stored procedure</param>
        /// <returns></returns>
        public SqlDataReader getDataReader(string command, Boolean Is_StoredProedure, Hashtable Param)
        {

            try
            {

                SqlDataReader dReader = null;

                //check for the state of the connection
                if (con.State == ConnectionState.Open)
                {

                    SqlCommand cmd = new SqlCommand();
                    cmd.CommandText = command;
                    cmd.Connection = con;

                    //check whether its a stored procedure or not
                    if (Is_StoredProedure == true)
                    {
                        cmd.CommandType = CommandType.StoredProcedure;

                        //if the ccommand is a stored procedure then we have to pass the paraters from the
                        //param to command
                        if (Param.Count > 0)
                        {
                            //loop to add the parameters in the param table with the command
                            foreach (string hKey in Param.Keys)
                            {
                                //Add the parameters in the param hashtable to as parameter fileds to command
                                cmd.Parameters.Add(new SqlParameter(hKey, Param[hKey]));
                            }

                        }

                    }
                    else
                    {

                        //if the command is not a stored procedure then, set it as the normal text type
                        cmd.CommandType = CommandType.Text;

                    }
                    //execute the query and get the datareader
                    dReader = cmd.ExecuteReader();

                    // *** Dispose the command Object - 05/04/2008
                    cmd.Dispose();

                }

                //return the datareader to the calling method
                return dReader;

            }
            catch
            {
                //return null for the
                return null;

            }


        }
        #endregion


        #region "----5) Method to execute the Query to Insert,Update and Delete records directly from the business logic----"
        /// <summary>
        /// method to execute the inser, update and delete query
        /// </summary>
        /// <param name="command">query to execute</param>
        /// <param name="Is_Stored_Procedure">parameter to decide whether the command is a stored procedure or normal text</param>
        /// <returns>no of records ajjected</returns>
        public int executeQuery(string command, Boolean Is_Stored_Procedure)
        {

            try
            {

                int Records_Affected = 0;
                //check for the connetion state
                if (con.State == ConnectionState.Open)
                {

                    SqlCommand cmd = new SqlCommand();
                    cmd.CommandText = command;
                    cmd.Connection = con;

                    //to check whetehr command is a stored procedure or normal text type
                    if (Is_Stored_Procedure == true)
                    {

                        cmd.CommandType = CommandType.StoredProcedure;

                    }
                    else
                    {

                        cmd.CommandType = CommandType.Text;

                    }

                    //execute the query and returns the no of records affected
                    Records_Affected = cmd.ExecuteNonQuery();

                    // *** Dispose the command Object - 05/04/2008
                    cmd.Dispose();

                }
                //return the no of records affected to the calling method
                return Records_Affected;

            }
            catch
            {

                //if there is any execption occured, we will return 0 to the calling method
                return 0;

            }

        }
        #endregion

        #region "----6) Method to execute the Query to Insert,Update and Delete records by passing stored procedures name and parameters----"
        /// <summary>
        /// execute the stroed procedure for insert,update or delete
        /// </summary>
        /// <param name="command">query to execute</param>
        /// <param name="Is_Stored_Procedure">to decide whether the application is stored peocdure or not</param>
        /// <param name="Param">hashtable to hold parameter for the stored procedures</param>
        /// <returns></returns>
        public int executeQuery(string command, Boolean Is_Stored_Procedure, Hashtable Param)
        {

            try
            {

                int Records_Affected = 0;
                //check the staus of the connection
                if (con.State == ConnectionState.Open)
                {

                    SqlCommand cmd = new SqlCommand();
                    cmd.CommandText = command;
                    cmd.Connection = con;

                    //check for the type of the stored procedure
                    if (Is_Stored_Procedure == true)
                    {

                        cmd.CommandType = CommandType.StoredProcedure;

                        //check the no of items in the param hashtable and add those keys to the  command as a parameter
                        if (Param.Count > 0)
                        {

                            //loop to add each items in the list to  the command parameters
                            foreach (string hKey in Param.Keys)
                            {

                                cmd.Parameters.Add(new SqlParameter(hKey, Param[hKey]));
                            
                            }

                        }

                    }
                    else
                    {

                        cmd.CommandType = CommandType.Text;

                    }

                    //execute the query and check the no of records affected by the query
                    Records_Affected = cmd.ExecuteNonQuery();

                    // *** Dispose the command Object - 05/04/2008
                    cmd.Dispose();

                }

                //return the no of records affected to the calling method
                return Records_Affected;

            }
            catch
            {
               
                //if any exception occured, return 0 to the calling method
                return 0;

            }

        }
        #endregion

        #region "----7) Method to execute the query and retrieve the dataset directly----"
        /// <summary>
        /// method to execute the query and get the dataset
        /// </summary>
        /// <param name="command">query to execute</param>
        /// <param name="Is_Stored_Procedure">check whether its a stored procedure or text command</param>
        /// <returns></returns>
        public DataSet getDataSet(string command, Boolean Is_Stored_Procedure)
        {

            try
            {

                SqlCommand cmd = new SqlCommand();
                SqlDataAdapter dap = new SqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                //check the status of the connection
                if (con.State == ConnectionState.Open)
                {

                    cmd.CommandText = command;
                    cmd.Connection = con;

                    //check the type of the command
                    //wheterh the command is stored procedure or normal text command
                    if (Is_Stored_Procedure == true)
                    {

                        cmd.CommandType = CommandType.StoredProcedure;

                    }
                    else
                    {

                        cmd.CommandType = CommandType.Text;

                    }

                    //execute the query
                    cmd.ExecuteNonQuery();

                    //fill the dataset with the dataadapter
                    dap.Fill(ds);

                    // *** Dispose the command Object and dataadapter Object - 05/04/2008
                    cmd.Dispose();
                    dap.Dispose();

                }

                //return the dataset to the calling method
                return ds;

            }
            catch
            {

                //if any exception occur, return null to calling method
                return null;

            }

        }
        #endregion

        #region "----8) Method to retrieve the dataset by passing the stored procedure and parameters----"
        /// <summary>
        /// metohd to execute the stored procedure and returns the dataset
        /// </summary>
        /// <param name="command">stroed procedure name to execute</param>
        /// <param name="Is_Stored_Procedure">type of the command</param>
        /// <param name="Param">hastable to hold the parameter for the stored procedure</param>
        /// <returns></returns>
        public DataSet getDataSet(string command, Boolean Is_Stored_Procedure, Hashtable Param)
        {

            try
            {

                SqlCommand cmd = new SqlCommand();
                SqlDataAdapter dap = new SqlDataAdapter(cmd);
                DataSet ds = new DataSet();

                //check the status of the connection
                if (con.State == ConnectionState.Open)
                {

                    cmd.CommandText = command;
                    cmd.Connection = con;
                    //check whetehr the commad is stored procedure or not
                    if (Is_Stored_Procedure == true)
                    {

                        cmd.CommandType = CommandType.StoredProcedure;

                        //check the no or items in the param hashtable is 0 or not
                        if (Param.Count > 0)
                        {

                            //loop to add the parameer to command
                            foreach (string hKey in Param.Keys)
                            {

                                //add the parameter to the command
                                cmd.Parameters.Add(new SqlParameter(hKey, Param[hKey]));
                           
                            }

                        }

                    }
                    else
                    {

                        cmd.CommandType = CommandType.Text;

                    }

                    //execute the stored procedure
                    cmd.ExecuteNonQuery();

                    //fill the dataset with the result of tht stored procedure using dataadapter
                    dap.Fill(ds);

                    // *** Dispose the command Object and Dataadapter Object - 05/04/2008
                    cmd.Dispose();
                    dap.Dispose();

                }

                //return dataset to the calling mathod
                return ds;

            }
            catch
            {

                //is any exception occurs,then return null to calling method
                return null;

            }

        }
        #endregion


        
    }

    #endregion
}
