using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.Threading;
using System.Collections;
using System.IO;
using System.Net;
using IMS_QueueManager;
using System.Collections.Specialized;
using System.Diagnostics;
using System.Text.RegularExpressions;



#region "--Class Description--"
///<classname>Queue Handler Operations</classname>
///<author>Santhosh Kumar</author>
///<date created>26/3/2008</datecreated>
///<datemodified>17/4/2008</datemodified>
///<modified by>Santhosh Kumar</modified by>
///<no. of classes>1</no. of classes>
///<no. of methods>11</no. of methods>
/// <summary>
/// This class is the Queue Handler which takes the queueid as the input and handles the overall 
/// operations by scanning the queue's urls and providing the next runtime of the queue to the 
/// Queue Manager. It scans each and evry URL and if any error occurs it writes the information to the
/// statistics table in the database
/// </summary>
/// 
#endregion


namespace IMS_QueueManager
{

    #region "----queue_Handler Class----"

    /// <summary>
    /// This class is the Sampling Queue Handler of the system. It runs once and then terminates, returning information to the  
    /// Queue Manager Class.
    /// </summary>
    public class queue_Handler : System.Exception, System.IDisposable
    {
        private int queueId = 0;
        private bool disposed = false;
        DataSet dsUrls = new DataSet();
        SqlDataReader drNext = null;
        data_Operations db = new data_Operations();
        String conn = "";
        string cmd = "";

        /// <summary>
        /// Default Constructor for Queue Handler
        /// </summary>
        public queue_Handler()
        {
            //
            // TODO: Add constructor logic here
            //
        }

        /// <summary>
        /// Instance Constructor for Queue Handler which holds the Queue Id
        /// </summary>
        /// <param name="Id"></param>
        public queue_Handler(int Id)
        {
            queueId = Id;
        }

        /// <summary>
        /// Property to set the queueId
        /// </summary>
        public int Id
        {
            get { return queueId; }
            set { queueId = value; }
        }

        /// <summary>
        /// Function to get the list of URLs from the database to be sampled
        /// </summary>
        public void GetURLSFromDB()
        {


            //int i = 0;
            Hashtable param = new Hashtable();

            //Open a database connection
            conn = db.openConnection();

            //check if connection is established or not
            if (conn == "success")
            {
               
                cmd = "sampler_GetUrlsToSample";
                param.Add("@queueid", queueId.ToString());

                // *** Execute the Stored Procedure and retrieve the information into the dataset
                dsUrls = db.getDataSet(cmd, true, param);

            }

            //close a database connection
            db.closeConnection();


            int i = 0;
            while (i < dsUrls.Tables[0].Rows.Count)
            {

                //Declare all the local varibles and initialize it to pass to the SampleUrl function
                int id = 0;
                string url = "";
                string requestType = "";
                string userAgent = "";
                string proxyHost = "";
                string proxyUserId = "";
                string proxyPassword = "";
                int proxyPort = 0;
                int slowResponseThreshold = 0;
                string referer = "";
                string cookie = "";
                string expected = "";
                int minError = 0;

                //Check that the value returned is null from the database
                if (dsUrls.Tables[0].Rows[i]["id"] != System.DBNull.Value)
                {

                    id = Convert.ToInt32(dsUrls.Tables[0].Rows[i]["id"]);

                }

                //Check that the value returned is null from the database
                if (dsUrls.Tables[0].Rows[i]["url"] != System.DBNull.Value)
                {

                    url = Convert.ToString(dsUrls.Tables[0].Rows[i]["url"]);

                }

                //Check that the value returned is null from the database
                if (dsUrls.Tables[0].Rows[i]["requestType"] != System.DBNull.Value)
                {

                    requestType = Convert.ToString(dsUrls.Tables[0].Rows[i]["requestType"]);

                }

                //Check that the value returned is null from the database
                if (dsUrls.Tables[0].Rows[i]["userAgent"] != System.DBNull.Value)
                {

                    userAgent = Convert.ToString(dsUrls.Tables[0].Rows[i]["userAgent"]);

                }

                //Check that the value returned is null from the database
                if (dsUrls.Tables[0].Rows[i]["proxyHost"] != System.DBNull.Value)
                {

                    proxyHost = Convert.ToString(dsUrls.Tables[0].Rows[i]["proxyHost"]);

                }

                //Check that the value returned is null from the database
                if (dsUrls.Tables[0].Rows[i]["proxyUserId"] != System.DBNull.Value)
                {

                    proxyUserId = Convert.ToString(dsUrls.Tables[0].Rows[i]["proxyUserId"]);

                }

                //Check that the value returned is null from the database
                if (dsUrls.Tables[0].Rows[i]["proxyPassword"] != System.DBNull.Value)
                {

                    proxyPassword = Convert.ToString(dsUrls.Tables[0].Rows[i]["proxyPassword"]);

                }

                //Check that the value returned is null from the database
                if (dsUrls.Tables[0].Rows[i]["proxyPort"] != System.DBNull.Value)
                {

                    proxyPort = Convert.ToInt32(dsUrls.Tables[0].Rows[i]["proxyPort"]);

                }

                //Check that the value returned is null from the database
                if (dsUrls.Tables[0].Rows[i]["slowResponseThreshold"] != System.DBNull.Value)
                {

                    slowResponseThreshold = Convert.ToInt32(dsUrls.Tables[0].Rows[i]["slowResponseThreshold"]);

                }

                //Check that the value returned is null from the database
                if (dsUrls.Tables[0].Rows[i]["referrer"] != System.DBNull.Value)
                {

                    referer = Convert.ToString(dsUrls.Tables[0].Rows[i]["referrer"]);

                }

                //Check that the value returned is null from the database
                if (dsUrls.Tables[0].Rows[i]["cookie"] != System.DBNull.Value)
                {

                    cookie = Convert.ToString(dsUrls.Tables[0].Rows[i]["cookie"]);

                }

                //Check that the value returned is null from the database
                if (dsUrls.Tables[0].Rows[i]["minErrorLevels_Id"] != System.DBNull.Value)
                {

                    minError = Convert.ToInt32(dsUrls.Tables[0].Rows[i]["minErrorLevels_Id"]);

                }

                //Check that the value returned is null from the database
                if (dsUrls.Tables[0].Rows[i]["expectedText"] != System.DBNull.Value)
                {

                    expected = Convert.ToString(dsUrls.Tables[0].Rows[i]["expectedText"]);

                }


                // *** SampleURL should come here
                SampleURL(id, ProcessPlaceHolders(url), requestType, ProcessPlaceHolders(userAgent), proxyHost, proxyUserId, proxyPassword, proxyPort,
                    slowResponseThreshold, ProcessPlaceHolders(referer), ProcessPlaceHolders(cookie), minError, expected);

                Thread.Sleep(Convert.ToInt32(ConfigurationManager.AppSettings["DelayBetweenUrls"].ToString()));

                i++;

            }

                      

        }

        /// <summary>
        /// This is the function where the actual Sampling of the url takes place.We place the url and
        /// its corresponding atttributes into the function and create a httpRequest and send the request to the webserver
        /// which contains the url and check the status of the url.
        /// </summary>
        /// <param name="id">url id from the database</param>
        /// <param name="url">url to be sampled</param>
        /// <param name="requestType">urls request type GET,POST or HEAD</param>
        /// <param name="userAgent">user agent of the url</param>
        /// <param name="proxyHost">proxy server</param>
        /// <param name="proxyUserId">proxy servers user id</param>
        /// <param name="proxyPassword">proxy servers password</param>
        /// <param name="proxyPort">proxy servers port</param>
        /// <param name="slowResponseThreshold">minimum threshold</param>
        /// <param name="referrer">referrer to the url</param>
        /// <param name="cookie">cookie to the url</param>
        /// <param name="minErrorLevel">minimum error level to write to the stats</param>
        /// <param name="expectedText">expected text from the server</param>
        private void SampleURL(int id, string url, string requestType, string userAgent, string proxyHost, string proxyUserId, string proxyPassword, int proxyPort, int slowResponseThreshold, string referrer, string cookie, int minErrorLevel, string expectedText)
        {

            // *** Declare Variables for http request and response
            HttpWebRequest http = null;




            // *** Declare variables to be passed to Write into the Statistics table
            int ErrorLevel = 0;
            string ErrorDesc = "";
            string debugHeaders = "";
            string debugHTML = "";

            // *** start timer and send the request
            common_Operations time = new common_Operations();
            int timerStart = 0;
            int duration = 0;



            try
            {

                // *** create a web request for the url to be sampled
                http = (HttpWebRequest)WebRequest.Create(url);

                // *** set properties for the http webrequest

                http.Timeout = slowResponseThreshold;

                http.KeepAlive = false;

                if (userAgent != null && userAgent != "")
                    // *** set the user agent for the web request
                    http.UserAgent = userAgent;

                if (referrer != null && referrer != "")
                    // *** set the referrer for the http web request
                    http.Referer = referrer;

                if (cookie != null && cookie != "")
                {
                    // *** set the cookie for the http webrequest
                    //Cookie newCookie = new Cookie("Cookie",cookie);
                    http.Headers.Add("Cookie", cookie);

                }

                if (proxyHost != null && proxyHost != "")
                {
                    // *** set the proxy host for the webrequest
                    WebProxy myProxy = new WebProxy();

                    // *** Create a new Uri object.
                    Uri newUri = new Uri(proxyHost);

                    // *** Assign the uri as the address to the web proxy
                    myProxy.Address = newUri;

                    if (proxyUserId == null || proxyUserId == "")
                    {
                        proxyUserId = "";
                        proxyPassword = "";

                    }

                    // *** set the network credentials for the uri
                    myProxy.Credentials = new NetworkCredential(proxyUserId, proxyPassword);

                }

                // *** Start the timer to calculate the time in milliseconds
                timerStart = time.MillisecondTimer();

                // *** Retrieve request info headers
                HttpWebResponse WebResponse = (HttpWebResponse)http.GetResponse();

                // *** calculate the total response time, in milliseconds.
                duration = time.MillisecondTimer() - timerStart;


                // *** Get the information for the debugHTML

                System.Text.Encoding enc = System.Text.Encoding.GetEncoding(1252);  // Windows default Code Page

                StreamReader ResponseStream =
                  new StreamReader(WebResponse.GetResponseStream(), enc);

                // *** Retrieve the headers from http cbject
                debugHeaders = http.Headers.ToString();

                // *** Retrieve the response using the Response Stream
                debugHTML = ResponseStream.ReadToEnd();

                // *** Close the Response Stream
                ResponseStream.Close();


                // *** Working with Errors

                if (WebResponse.StatusCode.ToString() == "OK")
                {

                    ErrorDesc = "";

                    // *** Check if expectedText not equal to null 
                    if (expectedText != null || expectedText != "")
                    {

                        // *** Check if the expected text pattern is found in the website or not
                        Regex matchExpected = new Regex(expectedText);
                        Match chkMatch = matchExpected.Match(debugHTML);

                        // *** If expected text is foud then no error else ErrorLevel = 300
                        if (chkMatch.Success)
                        {

                            ErrorDesc = "";

                        }
                        else
                        {

                            ErrorLevel = 300;
                            ErrorDesc = "Expected Text not found";
                            
                        }

                    }

                    // *** we now need to check for a special case of error: ADDED ON 11/04/2008
                    // *** the custom "error 400" which is actually a regular (HTTP 200)
                    // *** response page.
                    if (WebResponse.StatusDescription.ToString().Contains("Error 400 - Host Not Found"))
                    {

                        ErrorLevel = 300;
                        ErrorDesc = "400: Host Not Found!";

                    }

                    // *** we also need to check if the response time is below the : ADDED on 15/14/2008
                    // *** treshold. however, it is not really interesting if we already
                    // *** found a more severe error.
                    if (ErrorLevel < 200 && (duration > slowResponseThreshold))
                    {

                        ErrorLevel = 200;
                        ErrorDesc = "Slow Response " + duration.ToString() + " > " + slowResponseThreshold.ToString();

                    }

                }

                // *** Close the WebResponse object
                WebResponse.Close();

            }

            // *** This block gets executed when there is an exception in the above try block
            catch (WebException e)
            {

                try
                {

                    // *** Create an errorHandler object of type queue_Handler
                    queue_Handler errorHandler = new queue_Handler();

                    // *** Retrieve the 10 git negative error code 
                    int errorCritical = errorHandler.HResult;


                    // *** calculate the total response time, in milliseconds.
                    duration = time.MillisecondTimer() - timerStart;


                    // *** Check if error Response is equal to null or not
                    if (e.Response != null)
                    {
                        
                        System.Text.Encoding enc = System.Text.Encoding.GetEncoding(1252);  // Windows default Code Page

                        StreamReader ResponseStream =
                            new StreamReader(e.Response.GetResponseStream(), enc);

                        
                        debugHTML = ResponseStream.ReadToEnd();

                       
                        ResponseStream.Close();

                    }

                    // *** Retrieve the Headers from the http object
                    debugHeaders = http.Headers.ToString();

                    if (e.Status.ToString() == "TimeOut")
                    {

                        // *** Error Level when Operation Times out
                        ErrorLevel = 200;
                        ErrorDesc = e.Message;

                    }
                    else if (e.Status.ToString() == "ProtocolError")
                    {

                        // *** These are Http errors and the ErrorLevel is set to 400 for all protocol errors as per our Application
                        ErrorLevel = 400;
                        ErrorDesc = e.Message.ToString();

                    }
                    else // *** For the errors which escaped Timeout and Protocol Error
                    {

                        // *** For any other unknown http errors we can user Error Level = 400
                        ErrorLevel = 400; //500 is assigned to server internal error. so we need to use other number
                        ErrorDesc = e.Message.ToString() + "(" + errorCritical + ")";

                    }


                    // *** Handle Critical Errors Over Here


                    switch (errorCritical.ToString())
                    {

                        // *** This error indicates that one or more files
                        // *** in the Network Test Environment (NTE) folder has an attribute of �Read Only� assigned.
                        case "-2147012889":
                            {

                                if (ErrorLevel < 600)
                                {

                                    ErrorLevel = 600;
                                    ErrorDesc = e.Message.ToString() + "(" + errorCritical + ")";

                                }
                                break;

                            }

                        // *** ERROR_INTERNET_CANNOT_CONNECT
                        case "-2147012867":
                            {

                                if (ErrorLevel < 500)
                                {

                                    ErrorLevel = 500;
                                    ErrorDesc = e.Message.ToString() + "(" + errorCritical + ")";

                                }
                                break;

                            }

                        // *** ERROR_INTERNET_TIMEOUT
                        case "-2147012894":
                            {

                                if (ErrorLevel < 500)
                                {

                                    ErrorLevel = 500;
                                    ErrorDesc = e.Message.ToString() + "(" + errorCritical + ")";

                                }
                                break;

                            }

                        // *** These two are some other critical errors. Couldn't get information in GOOGLE Search
                        case "-2147012866":
                            {

                                if (ErrorLevel < 500)
                                {

                                    ErrorLevel = 500;
                                    ErrorDesc = e.Message.ToString() + "(" + errorCritical + ")";

                                }
                                break;

                            }
                        case "-2147012744":
                            {

                                if (ErrorLevel < 400)
                                {

                                    ErrorLevel = 400;
                                    ErrorDesc = e.Message.ToString() + "(" + errorCritical + ")";

                                }
                                break;

                            }

                        default:
                            {
                                if (ErrorLevel < 100)
                                {

                                    ErrorLevel = 100;
                                    ErrorDesc = e.Message.ToString() + "(" + errorCritical + ")";

                                }
                                break;

                            }

                    }

                    
                }

                // *** Block catches the Errors caused due to Application within the catch block
                catch (Exception ex)
                {

                    ErrorLevel = 700; 
                    ErrorDesc = "Application Error :" + ex.Message.ToString();
                    debugHeaders = "";
                    debugHTML = "";

                }

            }

            // *** Block catches the Errors caused due to Application within the catch block
            catch (Exception e)
            {

                //this error exception is due to null reference or some others
                //this we need to log the message in our internal log file.... 
                ErrorLevel = 700; 
                ErrorDesc = "Application Error :" + e.Message.ToString();
                debugHeaders = "";
                debugHTML = "";
               

            }
            finally
            {

                try
                {


                    // *** Write the Statistical Information into the database on the Statistics Table
                    WriteStats(id, ErrorLevel, ErrorDesc, duration, minErrorLevel, debugHeaders, debugHTML);


                }
                catch (Exception ex)
                {

                    ErrorDesc = "Error Writing to Sql Server using WriteStats function:" + ex.Message.ToString();
                  
                }
                
            }

        }

       
        /// <summary>
        /// Main function for entry into Queue Handler
        /// </summary>
        public int qHandler_Main()
        {
            
            int queueNextRunTime = 0;
            // *** Gets the list of Urls for a specified Queue
            GetURLSFromDB();

            // *** Get Queues Next Run Timer
            queueNextRunTime = GetQueueNextRunTime();

            // *** Returns the QueueNextRunTime
            return queueNextRunTime;


        }



        ///// <summary>
        ///// Function to calculate the Queues Next Run Time
        ///// </summary>
        ///// <returns>nextRunSeconds</returns>
        public int GetQueueNextRunTime()
        {

            int nextRunSeconds = 0;
            Hashtable param = new Hashtable();

            // *** Open a database Connection
            conn = db.openConnection();

            // *** Check if connection is sucessfull or not
            if (conn == "success")
            {

                // *** Stored procedure to get the queue next run time
                cmd = "sampler_GetQueueNextRunTime";
                param.Add("@queueid", queueId.ToString());

                // *** Execute the Stored Procedure and retrieve the information in the datareader
                drNext = db.getDataReader(cmd, true, param);

                // *** Check if datareader contains any data
                while (drNext.Read() == true)
                {

                    if (drNext[0] != null)
                    {

                        //Calculate the next runtime of the queue
                        nextRunSeconds = Convert.ToInt32(drNext[0].ToString());

                    }

                }

                // *** Close the DataReader
                drNext.Close();
            }

            // *** Close the database connection
            db.closeConnection();

            // *** Return the nextRunSeconds
            return nextRunSeconds;

        }

        /// <summary>
        /// Function to Process Place Holders
        /// Currently supported placeholders:
        /// %%%rnd%%%   random number
        /// %%%date%%%  current date
        /// %%%time%%%  current time
        /// %%%ver%%%   application version
        /// </summary>
        /// <param name="strIn"></param>
        /// <returns>"strOut"</returns>
        public string ProcessPlaceHolders(string strIn)
        {
            string strOut = "";
            Random rnd = new Random();

            if (strIn == "" || strOut == null)
                strOut = strIn;
            else
            {
                // *** Replace the string values according to the conventions
                strOut = strIn;
                strOut = strOut.Replace("%%%rnd%%%", Convert.ToString(rnd.NextDouble() * 100000000));
                strOut = strOut.Replace("%%%date%%%", DateTime.Now.Date.ToString());
                strOut = strOut.Replace("%%%time%%%", DateTime.Now.TimeOfDay.ToString());
                strOut = strOut.Replace("%%%ver%%%", ConfigurationManager.AppSettings["AppVersion"].ToString());

            }

            // *** Returns the string output after conversion
            return strOut;
        }

        /// <summary>
        /// Function to Write Results to database
        /// </summary>
        /// <param name="id"></param>
        /// <param name="ErrorLevel"></param>
        /// <param name="ErrorDesc"></param>
        /// <param name="responseDuration"></param>
        /// <param name="minErrorLevel"></param>
        /// <param name="debugHeaders"></param>
        /// <param name="debugHTML"></param>
        private void WriteStats(int id, int ErrorLevel, string ErrorDesc, int responseDuration, int minErrorLevel, string debugHeaders, string debugHTML)
        {

            Hashtable param = new Hashtable();

            // *** Stored Procedure to write to the stats table
            cmd = "sampler_InsertStats";

            // *** Add attributes to be passed to the stored procedures
            param.Add("@urls_id", id);
            param.Add("@errorLevel", ErrorLevel);
            param.Add("@errorDesc", ErrorDesc);
            param.Add("@responseDuration", responseDuration);
            param.Add("@minErrorLevel", minErrorLevel);
            param.Add("@alertThreshold", ConfigurationManager.AppSettings["AlertThreshold"].ToString());
            param.Add("@debugHeaders", debugHeaders);
            param.Add("@debugHtml", debugHTML);



            // *** Open the database connection
            conn = db.openConnection();

            // *** Check if connection is established successfully
            if (conn == "success")
            {

                // *** Execute the stored procedure to insert data into the stats table
                int i = db.executeQuery(cmd, true, param);

            }


            //// *** Close the database connection
            db.closeConnection();

        }



        /// <summary>
        /// Destructor for queue_Handler class
        /// </summary>
        ~queue_Handler()
        {

            // *** call Dispose with false.  Since we're in the
            // *** destructor call, the managed resources will be
            // *** disposed of anyways.

            Dispose(false);

        }

        /// <summary>
        /// Dispose function to dispose the managed and unmabaged resource
        /// </summary>
        public void Dispose()
        {

            // dispose of the managed and unmanaged resources
            Dispose(true);

            // tell the GC that the Finalize process no longer needs
            // to be run for this object.

            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Proceed only if managed and unmanaged code is not disposed
        /// </summary>
        /// <param name="disposeManagedResources"></param>
        protected virtual void Dispose(bool disposeManagedResources)
        {
            // *** process only if mananged and unmanaged resources have
            // *** not been disposed of.

            if (!this.disposed)
            {

                if (dsUrls != null)
                {
                    dsUrls.Dispose();
                    dsUrls = null;
                }

                if (drNext != null)
                {
                    drNext.Dispose();
                    drNext = null;
                }



                disposed = true;
            }

        }
    }

    #endregion
}