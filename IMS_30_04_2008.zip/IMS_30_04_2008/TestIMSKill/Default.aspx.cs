using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.Threading;
using IMS_QueueManager;
using System.Collections;

public partial class _Default : System.Web.UI.Page 
{

    // *** Global Variable Declaration for Queue Operation
    int k = 0;
    int qId = 0;
    string qName = "";
    int qProcess = 0;
    string qNextRun = "";
    string qRunSince = "";
    bool qEnabled = false;

    // *** Global Variable Declaration for Data Operation - 08/04/2008
    DataSet dsQueue = new DataSet();
    data_Operations db = new data_Operations();
    String conn = "";
    String cmd = "";

    // *** Queue Active Check Variable
    static int qCount = 0;


    /// Declare an array of clsQueues class objects
    /// </summary>
  //  clsQueues[] qDetails = new clsQueues[30];

    /// <summary>
    /// Decaew an array of objects for Queue Operations
    /// </summary>
    _Default[] instance = new _Default[30];


    


    /// <summary>
    /// Thread Variables
    /// </summary>
    /// <param name="obj"></param>
    static object locker = new object();
    Thread[] ThreadArray = null;

    protected void Page_Load(object sender, EventArgs e)
    {

        // *** Local variable Declaration for Data Operations
        DataSet dsQueue = new DataSet();
        data_Operations db = new data_Operations();


        // *** Open a database connection
        conn = db.openConnection();

        // *** check if connection is established or not
        if (conn == "success")
        {
            cmd = "sampler_GetQueueList";

            dsQueue = db.getDataSet(cmd, true);
        }

        //close a database connection
        db.closeConnection();

        // *** Check number of Active Queues in the database
        qCount = dsQueue.Tables[0].Rows.Count;

        MyWorkerThread[] ob = new MyWorkerThread[qCount];

        for (int i = 0; i < qCount; i++)
        {

            ob[i] = new MyWorkerThread(dsQueue.Tables[0].Rows[i][0].ToString());

        }


            // *** Declare an array of threads based on the active Queue in the database to be worker threads.
            ThreadArray = new Thread[dsQueue.Tables[0].Rows.Count];


           

            // *** Creating Thread instances and placing the instance objects QueueFirstRun function
            // *** to be the main function of each thread and setting the attributes value for each Queue
            // ** and start the thread
            for (int i = 0; i < qCount; i++)
            {

                //// *** Create an instance of the main class
                //instance[i] = new _Default();
                //instance[i].k = i;

                //// *** Set the parameters for each attributes for instance object
                //instance[i].qId = Convert.ToInt32(dsQueue.Tables[0].Rows[i][0]);
                //instance[i].qName = Convert.ToString(dsQueue.Tables[0].Rows[i][1]);
                //instance[i].qProcess = 0;

                //// *** MODIFIED ON 9/4/2008
                //instance[i].qNextRun = "-";
                //instance[i].qRunSince = "-";

                //instance[i].qEnabled = Convert.ToBoolean(dsQueue.Tables[0].Rows[i][5]);

                // *** Create a thread and point it to QueueFirstRun function
                ThreadArray[i] = new Thread(ob[i].Run);

                // *** Set a name to the thread
                //ThreadArray[i].Name = instance[i].qName;

                // *** Make the Thread to run as the Background thread
                ThreadArray[i].IsBackground = true;

                // *** Start the Thread
                ThreadArray[i].Start();

            }

            for (int i = 0; i < qCount; i++)
            {

                ob[i].WaitForThreadToStart();
            
            }


            for (int i = 0; i < qCount; i++)
            {

                ob[i].KillThread();
            }
        


    }
}
