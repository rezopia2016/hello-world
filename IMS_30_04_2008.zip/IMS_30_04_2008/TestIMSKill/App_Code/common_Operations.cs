using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Timers;

#region "--Class Description--"
///<classname>Comman Operations</classname>
///<author>Santhosh Kumar</author>
///<date created>29/3/2008</datecreated>
///<datemodified>3/4/2008</datemodified>
///<modified by>Santhosh Kumar</modified by>
///<no. of classes></no. of classes>
///<no. of methods></no. of methods>

/// <summary>
///This class contains all the common operations that needs to be implemented while creating the IMS project
/// </summary>

#endregion

namespace IMS_QueueManager
{
    #region "----Common Operations Class----"

    /// <summary>
    /// This class implements all the common functionality , variables and methods that are used through out the application
    /// </summary>

    public class common_Operations
    {
        public common_Operations()
        {
            //
            // TODO: Add constructor logic here
            //
        }

        /// <summary>
        /// Function to find the duration in millisec
        /// </summary>
        /// <returns>integer value is returned which is the time in millisec</returns>
        public int MillisecondTimer()
        {

            // *** convert seconds to millisecond
            int sec_millisec = (Convert.ToInt32(DateTime.Now.Second) * 1000);

            // *** convert minutes to millisecond
            int min_millisec = (Convert.ToInt32(DateTime.Now.Minute) * 60000);

            // *** convert hour to milisecond - MODIFIED ON 05/04/2008
            int hr_millisec = (Convert.ToInt32(DateTime.Now.Hour) * 3600000);

            // *** calculate the toltal millisecond

            int totalmillisec = sec_millisec + min_millisec + hr_millisec + DateTime.Now.Millisecond;

            // *** return the total millisecond to the calling function
            return totalmillisec;

        }

    }
    #endregion
}