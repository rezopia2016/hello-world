using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Threading;
using System.Diagnostics;
using IMS_QueueManager;

namespace IMS_QueueManager
{

    public class MyWorkerThread : System.IDisposable
    {
        /* Data members */
        protected bool m_bEndLoop = false;
        protected string m_strName = "";
        protected Mutex m_mutexEndLoop = new Mutex();
        protected AutoResetEvent m_autoEvent = new AutoResetEvent(false);
        protected Thread m_objThread = null;

        /* Constructors/Destructors */
        public MyWorkerThread(string strName)
        {
            Debug.WriteLine("Enter MyWorkerThread " + strName);
            m_strName = strName;
            Debug.WriteLine("Exit MyWorkerThread " + strName);
        }

        /* Presence of this destructor will generate a call to Finalize which will mark
        this object as finalizable and hence is placed in the finalization queue. The finalization
        queue is examined by the .NET Runtime before it frees memory for objects. This will only
        be called if user did not call Dispose() (Dispose frees both managed and unmanaged resources
        and suppresses finalization as there becomes no need for it) */
        ~MyWorkerThread()
        {
            // Free unmanaged resources only
            Debug.WriteLine("Enter ~MyWorkerThread " + m_strName);
            Dispose(false);
            Debug.WriteLine("Exit ~MyWorkerThread " + m_strName);
        }

        /* IDisposable implementation */

        /* Users must explicitly call this to free managed and unmanaged
        resources. Once managed and unmanaged resources are freed, there becomes no need to call
        the destructor which frees unmanaged resouces and hence the call to GC.SuppressFinalize */
        public void Dispose()
        {
            Debug.WriteLine("Enter IDisposable.Dispose " + m_strName);
            // Free managed and unmanaged resources
            Dispose(true);

            // Supress finalization because Dispose(true) frees both managed and unmanged resources
            GC.SuppressFinalize(this);
            Debug.WriteLine("Exit IDisposable.Dispose " + m_strName);
        }

        /* Properties */
        public bool EndLoop
        {
            get
            {
                // Protect access to the m_bEndLoop variable which will be shared my all clients using
                // this class to manage threads
                bool bResult = false;
                m_mutexEndLoop.WaitOne();
                bResult = m_bEndLoop;
                m_mutexEndLoop.ReleaseMutex();
                return bResult;
            }
            set
            {
                // Protect acces to the m_bEndLoop variable which will be shared my all clients using
                // this class to manage threads
                m_mutexEndLoop.WaitOne();
                m_bEndLoop = (bool)value;
                m_mutexEndLoop.ReleaseMutex();
            }
        }

        /* Public interface methods */

        // Thread function
        public void Run()
        {
            Debug.WriteLine("Enter thread function " + m_strName);

            // Cache the current thread. The current thread should be cached in the thread function
            // and not the in the constructor which runs in the client's thread.
            m_objThread = Thread.CurrentThread;
            m_objThread.Name = m_strName;
            m_autoEvent.Set();

            // Can thread run or was it told to stop
            while (EndLoop == false)
            {

                queue_Handler qhandle = new queue_Handler(Convert.ToInt32(m_strName));
                int i = qhandle.qHandler_Main();
                // Do thread functionality here
                Thread.Sleep(100);
                Debug.Write(".");
            }
            Debug.WriteLine("Exit thread function " + m_strName);
        }

        // Killing a thread
        public void KillThread()
        {
            Debug.WriteLine("Enter KillThread " + m_strName);

            // Is the thread dead anyway
            if (m_objThread.IsAlive == false)
                return;

            // Thread is alive. Set a property indicating that thread should be killed
            EndLoop = true;

            // This function should only return when the thread has died
            m_objThread.Join();
            Debug.WriteLine("Exit KillThread " + m_strName);
        }

        public void WaitForThreadToStart()
        {
            Debug.WriteLine("Enter WaitForThreadToStart " + m_strName);
            m_autoEvent.WaitOne();
            Debug.WriteLine("Exit WaitForThreadToStart " + m_strName);
        }

        /* Helpers */

        // Helper function that implemented the actual clean up
        protected virtual void Dispose(bool bFreeAll)
        {
            Debug.WriteLine("Enter Helper Dispose " + m_strName);

            // First of all, kill the thread
            KillThread();

            // Then free resources
            if (bFreeAll)
            {
                // Called by Dispose(). Free managed and unmanaged resources
                m_mutexEndLoop.Close();
            }
            else
            {
                // Called by Destructor(). Free unmanaged resources only
                m_mutexEndLoop.Close();
            }
            Debug.WriteLine("Exit Helper Dispose " + m_strName);
        }


    }

}