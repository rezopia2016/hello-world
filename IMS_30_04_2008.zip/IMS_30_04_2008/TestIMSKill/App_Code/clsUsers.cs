using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

/// <summary>
/// Summary description for clsUsers
/// </summary>
/// 
namespace IMS_QueueManager
{
    public class clsUsers
    {


        /// <summary>
        /// Declare the local variables for the clsUsers class
        /// </summary>
        private int id;
        private string name;
        private string emailAddress;
        private int emailSend;

        public clsUsers()
        {

        }

        //
        // TODO: Add constructor logic here
        //
        public clsUsers(int userId,
                         string userName,
                              string useremailAddress,
                                   int useremailSend)
        {

            id = userId;
            name = userName;
            emailAddress = useremailAddress;
            emailSend = useremailSend;

        }

        /// <summary>
        /// Property to set the userId
        /// </summary>
        public int userId
        {
            get { return id; }
            set { id = value; }
        }

        /// <summary>
        /// Property to set and get the userName
        /// </summary>
        public string userName
        {
            get { return name; }
            set { name = value; }
        }

        /// <summary>
        /// Property to set and get the useremailAddress
        /// </summary>
        public string useremailAddress
        {
            get { return emailAddress; }
            set { emailAddress = value; }
        }

        /// <summary>
        /// Property to set and get the useremailSend
        /// </summary>
        public int useremailSend
        {
            get { return emailSend; }
            set { emailSend = value; }
        }

    }
}
