﻿
namespace RZP.RMS.Common
{
    using System;
    using System.Text.RegularExpressions;
    using log4net.Config;

    /// <summary>
    /// Class Logger.
    /// </summary>
    public static class LogForNet
    {
        private static log4net.ILog Log { get; set; }

        static LogForNet()
        {
            log4net.Config.XmlConfigurator.Configure();
            Log = log4net.LogManager.GetLogger("RMSService_");
        }

        public static void Error(string type, object msg)
        {
            Console.WriteLine(msg);
            log4net.LogManager.GetLogger(type).Error(msg);
        }

        public static void Error(string type, object msg, Exception ex)
        {
            Console.WriteLine(msg);
            log4net.LogManager.GetLogger(type).Error(msg, ex);
        }

        public static void Error(string type, Exception ex)
        {
            Console.WriteLine(ex.Message);
            log4net.LogManager.GetLogger(type).Error(ex.Message, ex);
        }

        public static void Info(string type, object msg)
        {
            Console.WriteLine(msg);
            log4net.LogManager.GetLogger(type).Info(msg);
        }

        public static void Warn(string type, object msg)
        {
            Console.WriteLine(msg);
            log4net.LogManager.GetLogger(type).Warn(msg);
        }

        public static void Fatal(string type, object msg)
        {
            Console.WriteLine(msg);
            log4net.LogManager.GetLogger(type).Fatal(msg);
        }
    }
}
