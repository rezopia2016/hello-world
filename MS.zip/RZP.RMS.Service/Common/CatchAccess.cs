﻿// <copyright file="CouchbaseCache.cs" company="sonata-software ltd">
// Copyright (c) 2014 All Rights Reserved
// </copyright>
// <date>01/02/2014 11:39:58 AM </date>
// <summary> Implementation of the Class Program</summary>

namespace RZP.RMS.Common
{
    using System;
    using System.Configuration;
    using Couchbase;
    using Couchbase.Configuration;
    using Newtonsoft.Json;

    /// <summary>
    /// Class that contains an Advanced Cache.
    /// </summary>
    public class CouchbaseCache : IDisposable
    {
        /// <summary>
        /// Creates a new instance of an Advanced Cache.
        /// </summary>
        public CouchbaseCache()
        {
        }

        /// <summary>
        /// Fetch an element from the cache by ID.
        /// </summary>
        /// <typeparam name="T">Type to fetch.</typeparam>
        /// <param name="key">Cache key to fetch.</param>
        /// <returns>Returns fetched item.</returns>
        public T Fetch<T>(string key) where T : class
        {
            return FetchJson<T>(key);
        }

        /// <summary>
        /// Fetches the json.
        /// </summary>
        /// <typeparam name="T">Type of fetch.</typeparam>
        /// <param name="cacheKey">The cache key.</param>
        /// <returns>Returns Json Deserialize Object.</returns>
        private T FetchJson<T>(string cacheKey) where T : class
        {
            var json = CouchbaseClientSingleton.Instance.Get<string>(cacheKey);
            if (json == null)
            { 
                return null;
            }

            return JsonConvert.DeserializeObject<T>(json);
        }

        /// <summary>
        /// Dispose the object
        /// </summary>
        public void Dispose()
        {
            CouchbaseClientSingleton.Instance.Dispose();
        }
    }

    /// <summary>
    /// To create instance of couchbase
    /// </summary>
    public sealed class CouchbaseCacheSingleton
    {
        /// <summary>
        /// Represents Couch base Cache Singleton Property.
        /// </summary>
        private static volatile CouchbaseCache _instance;

        /// <summary>
        /// Represents Couch base Cache Singleton Property.
        /// </summary>
        private static object SyncRoot = new Object();

        /// <summary>
        /// Private constructor since it was a sealed class.
        /// </summary>
        private CouchbaseCacheSingleton()
        {
        }

        /// <summary>
        /// Creates single ton instance.
        /// </summary>
        public static CouchbaseCache Instance
        {
            get
            {
                if (_instance == null)
                {
                    lock (SyncRoot)
                    {
                        if (_instance == null)
                        {
                            try
                            {
                                _instance = new CouchbaseCache();
                            }
                            catch (Exception)
                            {
                                _instance = null;
                            }
                        }
                    }
                }

                return _instance;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        public static void Dispose()
        {
            if (_instance != null)
            {
                lock (SyncRoot)
                {
                    if (_instance != null)
                    {
                        _instance.Dispose();
                    }
                }
            }
        }
    }

    /// <summary>
    /// Creates CouchbaseClient singleton instance.
    /// </summary>
    internal sealed class CouchbaseClientSingleton
    {
        private static volatile CouchbaseClient _instance;
        private static object SyncRoot = new Object();

        private CouchbaseClientSingleton()
        {
        }

        public static CouchbaseClient Instance
        {
            get
            {
                if (_instance == null)
                {
                    lock (SyncRoot)
                    {
                        if (_instance == null)
                        {
                            try
                            {
                                _instance = new CouchbaseClient((CouchbaseClientSection)ConfigurationManager.GetSection("couchbase/couchbasebucket"));
                            }
                            catch (Exception)
                            {
                                _instance = null;
                            }
                        }
                    }
                }

                return _instance;
            }
        }

        public static void Dispose()
        {
            if (_instance != null)
            {
                lock (SyncRoot)
                {
                    if (_instance != null)
                    {
                        _instance.Dispose();
                    }
                }
            }
        }
    }
}
