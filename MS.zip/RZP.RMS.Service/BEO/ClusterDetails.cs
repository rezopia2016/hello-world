﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RZP.RMS.BEO
{
    public class ClusterDetails
    {
        /// <summary>
        /// The ClusterId
        /// </summary>
        public int ClusterId { get; set; }

        /// <summary>
        /// The Cluster Name
        /// </summary>
        public string ClusterName { get; set; }

        /// <summary>
        /// IP address of client system
        /// </summary>
        public string IPAddress { get; set; }

        /// <summary>
        /// Constructor
        /// </summary>
        public ClusterDetails()
        {

        }

        /// <summary>
        /// Constructor
        /// </summary>
        public ClusterDetails(string ipAddress, int clusterId, string clusterName)
        {
            this.IPAddress = ipAddress;
            this.ClusterId = clusterId;
            this.ClusterName = clusterName;
        }
    }
}
