﻿
namespace RZP.RMS.Processor
{
    /// <summary>
    /// This class provides logic for systems to unregister from RMS
    /// </summary>
    public class RMSUnRegistration : IAcceptor   
    {
        private static readonly log4net.ILog Log = log4net.LogManager.GetLogger(typeof(RMSMessage));
        /// <summary>
        /// To unregister a consumer system from RMS
        /// </summary>
        /// <param name="json">Details of the system to be unregistered</param>
        /// <returns>string containing QueuePath </returns>
        public string Execute(string json)
        {           
                return QueueDataContext.Delete(json);          
        }
    }
}