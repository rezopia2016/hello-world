﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using log4net;
using RZP.RMS.Helper;
using RZP.RMS.PayloadConsumer.Payload;
using XTP.Framework.Media;
using RZP.DAM.FileSystems;
using RZP.DAM;
using RZP.DAM.Utility;

namespace RZP.RMS.PayloadConsumer
{
    public class PayloadThreadHandler : ThreadHandler
    {
        /// <summary>
        /// To log the information.
        /// </summary>
        private static readonly ILog log = LogManager.GetLogger(typeof(PayloadThreadHandler));

        /// <summary>
        /// Sends the notification.
        /// </summary>
        /// <param name="obj">The object.</param>
        public override void DoWork(object obj)
        {
            try
            {
                log.Info("Payload consumer DoWork in PayloadThreadHandler - Enter");
                XTP.Framework.Media.PayloadAdapter process = (XTP.Framework.Media.PayloadAdapter)obj;
                Save(process.document, process.path, process.savePayload, process.payloadPath);
                log.Info("Path :" + process.path + " --- Payload path" + process.payloadPath);
                log.Info("Payload consumer DoWork in PayloadThreadHandler - Exit");
            }
            catch (Exception ex)
            {
                log.Error(ex);
            }
        }

        /// <summary>
        /// Saves the specified document.
        /// </summary>
        /// <param name="document">The document.</param>
        /// <param name="path">The path.</param>
        /// <param name="savePayload">if set to <c>true</c> [save payload].</param>
        /// <param name="payloadPath">The payload path.</param>
        public static void Save(string document, string path, bool savePayload, string payloadPath)
        {
            FileContext context = new FileContext(new PayloadFileSystem());
            try
            {
                if (savePayload && !string.IsNullOrEmpty(context.MediaPath))
                {
                    if (document != null)
                    {
                        string str = context.MediaPath + path + Guid.NewGuid() + ".xml";
                        log.Info("path information :- " + str);
                        string dirName = System.IO.Path.GetDirectoryName(str);
                        context.CreateDirectory(dirName);
                        context.Save(document.ToString(), str);
                    }
                    else
                    {
                        log.Info("Error document : " + document);
                    }
                }
                else
                {
                    log.Info("Media path from context : " + context.MediaPath);
                }
            }
            catch (Exception ex)
            {
                log.Error("Exception while saving document", ex);
            }
            finally
            {
                context = null;
            }
        }
    }
}
