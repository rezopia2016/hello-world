﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RMS.Adapter.Consumer;
using RMS.Adapter.Producer;
using RZP.RMS.Helper;
using log4net;
using XTP.Framework.Media;
using RZP.RMS.PayloadConsumer.Config;

namespace RZP.RMS.PayloadConsumer
{
    public class PayloadConsumer : QueueConsumer
    {
        /// <summary>
        /// The log class.
        /// </summary>
        private ILog log;

        /// <summary>
        /// The tenant.
        /// </summary>
        private TenantInfo tenant;

        /// <summary>
        /// The RMS url.
        /// </summary>
        private string rmsurl;

        /// <summary>
        /// The service name.
        /// </summary>
        private string serviceName;

        /// <summary>
        /// The thread pool manager.
        /// </summary>
        private ThreadPoolManager threadPoolManager;

         /// <summary>
        /// initializes Media Consumer
        /// </summary>
        /// <param name="tenantInfo">Tenant information.</param>
        /// <param name="rmsUrl">URL to connect to RMS.</param>
        public PayloadConsumer(TenantInfo tenantInfo, string rmsUrl)
        {
            this.log = LogManager.GetLogger(this.GetType().Name + "-" + tenantInfo.TenantCode);
            this.tenant = tenantInfo;
            this.rmsurl = rmsUrl;
            this.serviceName = this.tenant.TenantId + RMSUtility.PAYLOAD.ToLower();
        }


        /// <summary>
        /// Get media Consumer registered with all active tenants in RMS.
        /// </summary>
        protected override void Init()
        {
            try
            {
                QueueInfo queueInfo = RZP.RMS.Helper.Utility.Register(this.rmsurl, this.serviceName, this.tenant);
                base.QueuePath = queueInfo.QueuePath;
                this.threadPoolManager = new ThreadPoolManager(AppSetting.ThreadPoolSize);
                this.threadPoolManager.CreateThreadHandle<PayloadThreadHandler>();
            }
            catch (Exception ex)
            {
                this.log.Error(ex);
            }
        }

        /// <summary>
        /// Unregister the media Notification Consumer from RMS.
        /// </summary>
        protected override void OnClose()
        {
            try
            {
                if (!RZP.RMS.Helper.Utility.UnRegister(this.rmsurl, this.serviceName, this.tenant.IpAddress))
                {
                    this.log.Error("Notification system failed to close.");
                }
            }
            catch (Exception ex)
            {
                this.log.Error(ex);
            }
        }

        /// <summary>
        /// To process the media Notification message.
        /// </summary>
        /// <param name="json">The json text.</param>
        protected override void DoWork(string json)
        {
            try
            {
                this.log.Info("Enter Dowork");

                XTP.Framework.Media.PayloadAdapter order = MessageSender.ReceiveMessage<XTP.Framework.Media.PayloadAdapter>(json);

                this.threadPoolManager.Wait();
                IThreadPoolHandler handler = threadPoolManager.GetPoolObject();
                if (handler != null)
                {
                    handler.Start(order);
                }

                this.log.Info("Exit Dowork");
            }
            catch (Exception ex)
            {
                this.log.Error(ex);
                this.log.Error("Media system process failed.");
            }
        }

        
    }

    /// <summary>
    /// 
    /// </summary>
    public class testRMS : RMSMessage
    {
        public string firstname { get; set; }
        public string lastname { get; set; }
    }
}
