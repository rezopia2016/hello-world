﻿//-----------------------------------------------------------------------
// <copyright file="AppSetting.cs" company="Rezopia - Sonata">
//     Implementation of the class AppSetting.
// </copyright>
// <summary>This is the AppSetting class.</summary>
//-----------------------------------------------------------------------

namespace RZP.RMS.PayloadConsumer.Config
{
    using System;
    using System.Collections.Generic;
    using System.Collections.Specialized;
    using System.Configuration;
    using System.Linq;
    using System.Net.Configuration;
    using System.Text;
    using log4net;

    /// <summary>
    /// Implementation of the class APP Setting.
    /// </summary>
    public static class AppSetting
    {
        /// <summary>
        /// Represents Log Property.
        /// </summary>
        private static readonly ILog Log = LogManager.GetLogger(typeof(AppSetting));

        /// <summary>
        /// Gets APP RMS ClusterId.
        /// </summary>
        /// <value>APP RMS ClusterId.</value>
        public static int RMSClusterId
        {
            get
            {
                int rmsClusterId;
                if (int.TryParse(ConfigurationManager.AppSettings.Get("RMSClusterId"), out rmsClusterId))
                {
                    return rmsClusterId;
                }

                Log.Error("RMSClusterId is not configured.");
                return rmsClusterId;
            }
        }

        /// <summary>
        /// Gets APP RMS Cluster Name.
        /// </summary>
        /// <value>APP RMS Cluster Name.</value>
        public static string RMSClusterName
        {
            get
            {
                if (!string.IsNullOrEmpty(ConfigurationManager.AppSettings.Get("RMSClusterName")))
                {
                    return ConfigurationManager.AppSettings.Get("RMSClusterName").Trim();
                }

                Log.Error("RMSClusterName is not configured.");
                return string.Empty;
            }
        }

        /// <summary>
        /// Gets App RMS Configuration Service URL.
        /// </summary>
        /// <value>App RMS Configuration Service URL.</value>
        public static string RMSConfigurationServiceURL
        {
            get
            {
                if (!string.IsNullOrEmpty(ConfigurationManager.AppSettings.Get("RMSConfigurationServiceURL")))
                {
                    return ConfigurationManager.AppSettings.Get("RMSConfigurationServiceURL").Trim();
                }

                Log.Error("RMSConfigurationServiceURL is not configured.");
                return string.Empty;
            }
        }

        /// <summary>
        /// Gets App RMS Configuration Service URL.
        /// </summary>
        /// <value>App RMS Configuration Service URL.</value>
        public static string RMSSystemUrl
        {
            get
            {
                if (!string.IsNullOrEmpty(ConfigurationManager.AppSettings.Get("RMSSystemUrl")))
                {
                    return ConfigurationManager.AppSettings.Get("RMSSystemUrl").Trim();
                }

                Log.Error("RMSSystemUrl is not configured.");
                return string.Empty;
            }
        }

        /// <summary>
        /// Gets App ServiceName.
        /// </summary>
        /// <value>App RMS Configuration Service URL.</value>
        public static string ServiceName
        {
            get
            {
                if (!string.IsNullOrEmpty(ConfigurationManager.AppSettings.Get("ServiceName")))
                {
                    return ConfigurationManager.AppSettings.Get("ServiceName").Trim();
                }

                Log.Warn("Service name is not configured.");
                return string.Empty;
            }
        }

        /// <summary>
        /// Gets the enable all tenants.
        /// </summary>
        /// <value>The enable all tenants.</value>
        public static string EnableAllTenants
        {
            get
            {
                if (!string.IsNullOrEmpty(ConfigurationManager.AppSettings.Get("EnableAllTenants")))
                {
                    return ConfigurationManager.AppSettings.Get("EnableAllTenants").Trim();
                }

                Log.Warn("EnableAllTenants is not configured.");
                return string.Empty;
            }
        }

        /// <summary>
        /// Gets the size of the thread pool.
        /// </summary>
        /// <value>The size of the thread pool.</value>
        public static int ThreadPoolSize
        {
            get
            {
                int threadPoolSize;
                if (int.TryParse(ConfigurationManager.AppSettings.Get("ThreadPoolSize"), out threadPoolSize))
                {
                    return threadPoolSize;
                }

                Log.Error("Thread pool size is not configured.");
                return threadPoolSize;
            }
        }

        /// <summary>
        /// Gets the tenant codes.
        /// </summary>
        /// <value>The tenant codes.</value>
        public static string[] TenantCodes
        {
            get
            {
                string strTenantCodes = string.Empty;
                var section = ConfigurationManager.GetSection("tenantcodes") as System.Collections.Specialized.NameValueCollection;

                if (section != null)
                {
                    string[] tenatcode = new string[section.Count];
                    section.CopyTo(tenatcode, 0);
                    return tenatcode;
                }
                else
                {
                    Log.Warn("TenantCodes is not configured.");
                    return null;
                }
            }
        }

        /// <summary>
        /// Gets App Connection String.
        /// </summary>
        /// <value>App Connection String.</value>
        public static string MasterConnectionString
        {
            get
            {
                if (ConfigurationManager.ConnectionStrings["XTPMetaData"] != null && !string.IsNullOrEmpty(ConfigurationManager.ConnectionStrings["XTPMetaData"].ConnectionString))
                {
                    return ConfigurationManager.ConnectionStrings["XTPMetaData"].ConnectionString;
                }

                return string.Empty;
            }
        }

        /// <summary>
        /// Gets App SMTP Host.
        /// </summary>
        /// <value>App SMTP Host.</value>
        public static SmtpNetworkElement SMTPHost
        {
            get
            {
                if (ConfigurationManager.GetSection(@"system.net/mailSettings") != null)
                {
                    MailSettingsSectionGroup mailSettings = ConfigurationManager.GetSection(@"system.net/mailSettings") as MailSettingsSectionGroup;
                    return mailSettings.Smtp.Network;
                }

                return null;
            }
        }



        ///// <summary>
        ///// Gets App Cache Enabled.
        ///// </summary>
        ///// <value>App Cache Enabled.</value>
        //public static bool IsCacheEnabled
        //{
        //    get
        //    {
        //        if (!string.IsNullOrEmpty(ConfigurationManager.AppSettings.Get("IsCacheble")))
        //        {
        //            return ConfigurationManager.AppSettings.Get("IsCacheble").ToBool();
        //        }

        //        return false;
        //    }
        //}

        /// <summary>
        /// Gets Mail Configuration.
        /// </summary>
        /// <value>App Master Database.</value>
        public static string MailInstance
        {
            get
            {
                return BeanSection("mailinstance");
            }
        }

        /// Beans the section.
        /// </summary>
        /// <param name="key">The BeanSection key.</param>
        /// <returns>Returns value.</returns>
        private static string BeanSection(string key)
        {
            try
            {
                NameValueCollection beansection = ConfigurationManager.GetSection("beans") as NameValueCollection;
                if (beansection == null)
                {
                    return null;
                }

                var beanasm = beansection[key.Trim()];
                return beanasm;
            }
            catch (Exception ex)
            {
                Log.Error(ex);
                return string.Empty;
            }
        }
    }
}
