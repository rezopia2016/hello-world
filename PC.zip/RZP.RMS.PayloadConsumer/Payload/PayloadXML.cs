﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using XTP.Framework;

namespace XTP.Framework.Media
{
    public class PayloadXML
    {
        public string document { get; set; }
        public string payloadPath { get; set; }
        public bool savePayload { get; set; }
        public string path { get; set; }
    }
}

