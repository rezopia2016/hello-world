﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace RZP.RMS.PayloadConsumer.Payload
{
    public class PayloadProcess
    {

        internal void Execute(object obj)
        {
            // Call file system context class for inserting into database.
            throw new NotImplementedException();
        }
    }
}
