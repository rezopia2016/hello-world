﻿using RZP.RMS.Helper;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading.Tasks;
using log4net;
using RZP.RMS.PayloadConsumer.Config;

namespace RZP.RMS.PayloadConsumer
{
    public partial class PayloadConsumerService : ServiceBase
    {
        /// <summary>
        /// Represents ILog Property.
        /// </summary>
        private static readonly ILog Log = LogManager.GetLogger(typeof(PayloadConsumerService));

        /// <summary>
        /// Represents ILog Property.
        /// </summary>
        private RMSTenantInvoker tenantInvoker = new RMSTenantInvoker();

        /// <summary>
        /// Initializes a new instance of the <see cref="VoucherConsumerService"/> class.
        /// </summary>
        public PayloadConsumerService()
        {
            this.InitializeComponent();
            this.tenantInvoker.RMSClusterId = AppSetting.RMSClusterId;
            this.tenantInvoker.RMSClusterName = AppSetting.RMSClusterName;
            this.tenantInvoker.ServiceName = AppSetting.ServiceName;
        }

#if DEBUG
        /// <summary>
        /// Starts up.
        /// </summary>
        public void StartUp()
        {
            try
            {
                if (AppSetting.EnableAllTenants.ToLower() != "true")
                {
                    this.tenantInvoker.Start<PayloadConsumer>(AppSetting.RMSConfigurationServiceURL, AppSetting.RMSSystemUrl, AppSetting.TenantCodes);
                }
                else
                {
                    this.tenantInvoker.Start<PayloadConsumer>(AppSetting.RMSConfigurationServiceURL, AppSetting.RMSSystemUrl);
                }

            }
            catch (Exception ex)
            {
                Log.Error(ex);
            }
        }

        /// <summary>
        /// Shuts down.
        /// </summary>
        public void ShutDown()
        {
            this.tenantInvoker.Stop();
        }

        /// <summary>
        /// When implemented in a derived class, executes when a Stop command is sent to the service by the Service Control Manager (SCM). Specifies actions to take when a service stops running.
        /// </summary>
        protected override void OnStop()
        {
            this.tenantInvoker.Stop();
        }

#endif


        protected override void OnStart(string[] args)
        {
            try
            {

                if (AppSetting.EnableAllTenants.ToLower() != "true")
                {
                    this.tenantInvoker.Start<PayloadConsumer>(AppSetting.RMSConfigurationServiceURL, AppSetting.RMSSystemUrl, AppSetting.TenantCodes);
                }
                else
                {
                    this.tenantInvoker.Start<PayloadConsumer>(AppSetting.RMSConfigurationServiceURL, AppSetting.RMSSystemUrl);
                }

            }
            catch (Exception ex)
            {
                Log.Error(ex);
            }
        }
    }
}
